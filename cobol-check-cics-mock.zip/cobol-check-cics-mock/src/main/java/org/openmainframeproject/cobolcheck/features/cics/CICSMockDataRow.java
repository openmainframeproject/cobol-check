package org.openmainframeproject.cobolcheck.features.cics;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

/**
 * Represents a single row of mock data for CICS command responses.
 * Used for commands that return data (READ, READNEXT, RECEIVE, etc.)
 * 
 * Supports:
 * - Field value assignments for INTO/SET areas
 * - Row-specific RESP codes (e.g., for browse end conditions)
 * - LENGTH return values
 */
public class CICSMockDataRow {
    
    private final Map<String, String> fieldValues;
    private CICSResponseCode rowResp;
    private int rowResp2;
    private boolean hasRowResp;
    private int returnLength;
    private boolean hasReturnLength;
    
    /**
     * Creates a new empty data row with NORMAL response.
     */
    public CICSMockDataRow() {
        this.fieldValues = new LinkedHashMap<>();
        this.rowResp = CICSResponseCode.NORMAL;
        this.rowResp2 = 0;
        this.hasRowResp = false;
        this.returnLength = 0;
        this.hasReturnLength = false;
    }
    
    /**
     * Creates a data row with a specific response code.
     * Useful for end-of-browse or error conditions.
     * 
     * @param resp The CICS response code for this row
     */
    public CICSMockDataRow(CICSResponseCode resp) {
        this();
        this.rowResp = resp;
        this.hasRowResp = true;
    }
    
    /**
     * Sets a field value for this row.
     * Field names correspond to fields in the INTO/SET area.
     * 
     * @param fieldName  The field name (e.g., "CUST-ID")
     * @param fieldValue The value to assign
     */
    public void setFieldValue(String fieldName, String fieldValue) {
        if (fieldName == null || fieldName.trim().isEmpty()) {
            throw new IllegalArgumentException("Field name cannot be null or empty");
        }
        fieldValues.put(normalizeFieldName(fieldName), fieldValue);
    }
    
    /**
     * Gets a field value from this row.
     * 
     * @param fieldName The field name
     * @return The field value, or null if not set
     */
    public String getFieldValue(String fieldName) {
        return fieldValues.get(normalizeFieldName(fieldName));
    }
    
    /**
     * Checks if a field exists in this row.
     * 
     * @param fieldName The field name
     * @return true if the field has a value
     */
    public boolean hasField(String fieldName) {
        return fieldValues.containsKey(normalizeFieldName(fieldName));
    }
    
    /**
     * Gets all field names in this row.
     * 
     * @return Set of field names in insertion order
     */
    public Set<String> getFieldNames() {
        return fieldValues.keySet();
    }
    
    /**
     * Gets the number of fields in this row.
     * 
     * @return The field count
     */
    public int getFieldCount() {
        return fieldValues.size();
    }
    
    /**
     * Gets all field values as a map.
     * 
     * @return Unmodifiable map of field names to values
     */
    public Map<String, String> getAllFieldValues() {
        return Map.copyOf(fieldValues);
    }
    
    /**
     * Gets the RESP code for this specific row.
     * 
     * @return The row-specific response code
     */
    public CICSResponseCode getRowResp() {
        return rowResp;
    }
    
    /**
     * Sets the RESP code for this specific row.
     * 
     * @param resp The response code
     */
    public void setRowResp(CICSResponseCode resp) {
        this.rowResp = resp;
        this.hasRowResp = true;
    }
    
    /**
     * Sets the RESP code from a string (numeric or name).
     * 
     * @param respValue The response code as string
     */
    public void setRowResp(String respValue) {
        this.rowResp = CICSResponseCode.parse(respValue);
        this.hasRowResp = true;
    }
    
    /**
     * Checks if this row has a specific RESP code set.
     * 
     * @return true if a row-specific RESP was set
     */
    public boolean hasRowResp() {
        return hasRowResp;
    }
    
    /**
     * Gets the RESP2 code for this specific row.
     * 
     * @return The row-specific RESP2 value
     */
    public int getRowResp2() {
        return rowResp2;
    }
    
    /**
     * Sets the RESP2 code for this specific row.
     * 
     * @param resp2 The RESP2 value
     */
    public void setRowResp2(int resp2) {
        this.rowResp2 = resp2;
    }
    
    /**
     * Gets the return LENGTH for this row.
     * Used when the actual length differs from the buffer length.
     * 
     * @return The return length
     */
    public int getReturnLength() {
        return returnLength;
    }
    
    /**
     * Sets the return LENGTH for this row.
     * 
     * @param length The return length
     */
    public void setReturnLength(int length) {
        this.returnLength = length;
        this.hasReturnLength = true;
    }
    
    /**
     * Checks if this row has a specific return length.
     * 
     * @return true if a return length was set
     */
    public boolean hasReturnLength() {
        return hasReturnLength;
    }
    
    /**
     * Checks if this row represents an end condition (ENDFILE, QZERO, etc.)
     * 
     * @return true if RESP indicates no more data
     */
    public boolean isEndCondition() {
        return hasRowResp && rowResp.isNotFound();
    }
    
    /**
     * Checks if this row represents an error condition.
     * 
     * @return true if RESP indicates an error
     */
    public boolean isError() {
        return hasRowResp && !rowResp.isSuccess() && !rowResp.isNotFound();
    }
    
    /**
     * Normalizes a field name for consistent lookup.
     */
    private String normalizeFieldName(String fieldName) {
        return fieldName.trim().toUpperCase();
    }
    
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("CICSMockDataRow{");
        if (hasRowResp) {
            sb.append("resp=").append(rowResp.name());
            if (rowResp2 != 0) {
                sb.append(", resp2=").append(rowResp2);
            }
            sb.append(", ");
        }
        if (hasReturnLength) {
            sb.append("length=").append(returnLength).append(", ");
        }
        sb.append("fields=").append(fieldValues);
        sb.append("}");
        return sb.toString();
    }
}
