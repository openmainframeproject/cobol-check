package org.openmainframeproject.cobolcheck.features.cics;

/**
 * Enumeration of CICS command types that can be mocked.
 * Organized by functional category for clarity.
 */
public enum CICSCommandType {
    
    // =========================================================================
    // FILE CONTROL
    // =========================================================================
    
    /** Read a record from a file */
    READ("READ", CICSCategory.FILE_CONTROL, true),
    
    /** Write a new record to a file */
    WRITE("WRITE", CICSCategory.FILE_CONTROL, false),
    
    /** Rewrite an existing record */
    REWRITE("REWRITE", CICSCategory.FILE_CONTROL, false),
    
    /** Delete a record from a file */
    DELETE("DELETE", CICSCategory.FILE_CONTROL, false),
    
    /** Unlock a record */
    UNLOCK("UNLOCK", CICSCategory.FILE_CONTROL, false),
    
    /** Start a browse operation */
    STARTBR("STARTBR", CICSCategory.FILE_CONTROL, false),
    
    /** Read next record in browse */
    READNEXT("READNEXT", CICSCategory.FILE_CONTROL, true),
    
    /** Read previous record in browse */
    READPREV("READPREV", CICSCategory.FILE_CONTROL, true),
    
    /** Reset browse position */
    RESETBR("RESETBR", CICSCategory.FILE_CONTROL, false),
    
    /** End browse operation */
    ENDBR("ENDBR", CICSCategory.FILE_CONTROL, false),
    
    // =========================================================================
    // PROGRAM CONTROL
    // =========================================================================
    
    /** Link to another program (returns control) */
    LINK("LINK", CICSCategory.PROGRAM_CONTROL, true),
    
    /** Transfer control to another program (no return) */
    XCTL("XCTL", CICSCategory.PROGRAM_CONTROL, false),
    
    /** Return to calling program or CICS */
    RETURN("RETURN", CICSCategory.PROGRAM_CONTROL, false),
    
    /** Load a program or table */
    LOAD("LOAD", CICSCategory.PROGRAM_CONTROL, true),
    
    /** Release a loaded program */
    RELEASE("RELEASE", CICSCategory.PROGRAM_CONTROL, false),
    
    // =========================================================================
    // TERMINAL CONTROL
    // =========================================================================
    
    /** Send data to terminal */
    SEND("SEND", CICSCategory.TERMINAL_CONTROL, false),
    
    /** Receive data from terminal */
    RECEIVE("RECEIVE", CICSCategory.TERMINAL_CONTROL, true),
    
    /** Send BMS map to terminal */
    SEND_MAP("SEND MAP", CICSCategory.TERMINAL_CONTROL, false),
    
    /** Receive BMS map from terminal */
    RECEIVE_MAP("RECEIVE MAP", CICSCategory.TERMINAL_CONTROL, true),
    
    /** Send control characters */
    SEND_CONTROL("SEND CONTROL", CICSCategory.TERMINAL_CONTROL, false),
    
    /** Send text to terminal */
    SEND_TEXT("SEND TEXT", CICSCategory.TERMINAL_CONTROL, false),
    
    /** Converse - send and receive */
    CONVERSE("CONVERSE", CICSCategory.TERMINAL_CONTROL, true),
    
    // =========================================================================
    // TEMPORARY STORAGE
    // =========================================================================
    
    /** Write to temporary storage queue */
    WRITEQ_TS("WRITEQ TS", CICSCategory.TEMPORARY_STORAGE, false),
    
    /** Read from temporary storage queue */
    READQ_TS("READQ TS", CICSCategory.TEMPORARY_STORAGE, true),
    
    /** Delete temporary storage queue */
    DELETEQ_TS("DELETEQ TS", CICSCategory.TEMPORARY_STORAGE, false),
    
    // =========================================================================
    // TRANSIENT DATA
    // =========================================================================
    
    /** Write to transient data queue */
    WRITEQ_TD("WRITEQ TD", CICSCategory.TRANSIENT_DATA, false),
    
    /** Read from transient data queue */
    READQ_TD("READQ TD", CICSCategory.TRANSIENT_DATA, true),
    
    /** Delete transient data queue */
    DELETEQ_TD("DELETEQ TD", CICSCategory.TRANSIENT_DATA, false),
    
    // =========================================================================
    // STORAGE CONTROL
    // =========================================================================
    
    /** Acquire main storage */
    GETMAIN("GETMAIN", CICSCategory.STORAGE_CONTROL, true),
    
    /** Release main storage */
    FREEMAIN("FREEMAIN", CICSCategory.STORAGE_CONTROL, false),
    
    // =========================================================================
    // INTERVAL CONTROL
    // =========================================================================
    
    /** Start a task at specified time/interval */
    START("START", CICSCategory.INTERVAL_CONTROL, false),
    
    /** Retrieve data passed by START */
    RETRIEVE("RETRIEVE", CICSCategory.INTERVAL_CONTROL, true),
    
    /** Cancel a started task */
    CANCEL("CANCEL", CICSCategory.INTERVAL_CONTROL, false),
    
    /** Delay task execution */
    DELAY("DELAY", CICSCategory.INTERVAL_CONTROL, false),
    
    /** Get current time/date */
    ASKTIME("ASKTIME", CICSCategory.INTERVAL_CONTROL, true),
    
    /** Format time for display */
    FORMATTIME("FORMATTIME", CICSCategory.INTERVAL_CONTROL, true),
    
    // =========================================================================
    // CONTAINER/CHANNEL
    // =========================================================================
    
    /** Put data into a container */
    PUT_CONTAINER("PUT CONTAINER", CICSCategory.CONTAINER, false),
    
    /** Get data from a container */
    GET_CONTAINER("GET CONTAINER", CICSCategory.CONTAINER, true),
    
    /** Delete a container */
    DELETE_CONTAINER("DELETE CONTAINER", CICSCategory.CONTAINER, false),
    
    /** Move a container */
    MOVE_CONTAINER("MOVE CONTAINER", CICSCategory.CONTAINER, false),
    
    // =========================================================================
    // SYNCPOINT
    // =========================================================================
    
    /** Commit changes */
    SYNCPOINT("SYNCPOINT", CICSCategory.SYNCPOINT, false),
    
    /** Rollback changes */
    SYNCPOINT_ROLLBACK("SYNCPOINT ROLLBACK", CICSCategory.SYNCPOINT, false),
    
    // =========================================================================
    // EXCEPTION HANDLING
    // =========================================================================
    
    /** Handle exception conditions */
    HANDLE_CONDITION("HANDLE CONDITION", CICSCategory.EXCEPTION, false),
    
    /** Handle abend conditions */
    HANDLE_ABEND("HANDLE ABEND", CICSCategory.EXCEPTION, false),
    
    /** Ignore exception conditions */
    IGNORE_CONDITION("IGNORE CONDITION", CICSCategory.EXCEPTION, false),
    
    /** Force an abend */
    ABEND("ABEND", CICSCategory.EXCEPTION, false),
    
    // =========================================================================
    // INQUIRY
    // =========================================================================
    
    /** Assign EIB/system values */
    ASSIGN("ASSIGN", CICSCategory.INQUIRY, true),
    
    /** Address system areas */
    ADDRESS("ADDRESS", CICSCategory.INQUIRY, true),
    
    /** Inquire about resources */
    INQUIRE("INQUIRE", CICSCategory.INQUIRY, true),
    
    // =========================================================================
    // UNKNOWN
    // =========================================================================
    
    /** Unrecognized command */
    UNKNOWN("UNKNOWN", CICSCategory.UNKNOWN, false);
    
    private final String keyword;
    private final CICSCategory category;
    private final boolean returnsData;
    
    CICSCommandType(String keyword, CICSCategory category, boolean returnsData) {
        this.keyword = keyword;
        this.category = category;
        this.returnsData = returnsData;
    }
    
    public String getKeyword() {
        return keyword;
    }
    
    public CICSCategory getCategory() {
        return category;
    }
    
    public boolean returnsData() {
        return returnsData;
    }
    
    /**
     * Determines the CICS command type from a command string.
     * 
     * @param command The CICS command string (after EXEC CICS)
     * @return The corresponding CICSCommandType
     */
    public static CICSCommandType fromCommand(String command) {
        if (command == null || command.trim().isEmpty()) {
            return UNKNOWN;
        }
        
        String normalized = command.trim().toUpperCase();
        
        // Handle two-word commands first
        if (normalized.startsWith("SEND MAP")) return SEND_MAP;
        if (normalized.startsWith("RECEIVE MAP")) return RECEIVE_MAP;
        if (normalized.startsWith("SEND CONTROL")) return SEND_CONTROL;
        if (normalized.startsWith("SEND TEXT")) return SEND_TEXT;
        if (normalized.startsWith("WRITEQ TS")) return WRITEQ_TS;
        if (normalized.startsWith("READQ TS")) return READQ_TS;
        if (normalized.startsWith("DELETEQ TS")) return DELETEQ_TS;
        if (normalized.startsWith("WRITEQ TD")) return WRITEQ_TD;
        if (normalized.startsWith("READQ TD")) return READQ_TD;
        if (normalized.startsWith("DELETEQ TD")) return DELETEQ_TD;
        if (normalized.startsWith("PUT CONTAINER")) return PUT_CONTAINER;
        if (normalized.startsWith("GET CONTAINER")) return GET_CONTAINER;
        if (normalized.startsWith("DELETE CONTAINER")) return DELETE_CONTAINER;
        if (normalized.startsWith("MOVE CONTAINER")) return MOVE_CONTAINER;
        if (normalized.startsWith("SYNCPOINT ROLLBACK")) return SYNCPOINT_ROLLBACK;
        if (normalized.startsWith("HANDLE CONDITION")) return HANDLE_CONDITION;
        if (normalized.startsWith("HANDLE ABEND")) return HANDLE_ABEND;
        if (normalized.startsWith("IGNORE CONDITION")) return IGNORE_CONDITION;
        
        // Handle single-word commands
        String firstWord = normalized.split("\\s+")[0];
        
        for (CICSCommandType type : values()) {
            if (type.keyword.equals(firstWord)) {
                return type;
            }
        }
        
        return UNKNOWN;
    }
    
    /**
     * Gets the primary option name for this command type.
     * This is the main identifier used for matching mocks.
     */
    public String getPrimaryOption() {
        switch (this) {
            case READ:
            case WRITE:
            case REWRITE:
            case DELETE:
            case UNLOCK:
            case STARTBR:
            case READNEXT:
            case READPREV:
            case RESETBR:
            case ENDBR:
                return "FILE";
                
            case LINK:
            case XCTL:
            case LOAD:
            case RELEASE:
                return "PROGRAM";
                
            case WRITEQ_TS:
            case READQ_TS:
            case DELETEQ_TS:
            case WRITEQ_TD:
            case READQ_TD:
            case DELETEQ_TD:
                return "QUEUE";
                
            case SEND_MAP:
            case RECEIVE_MAP:
                return "MAP";
                
            case PUT_CONTAINER:
            case GET_CONTAINER:
            case DELETE_CONTAINER:
            case MOVE_CONTAINER:
                return "CONTAINER";
                
            case START:
            case CANCEL:
                return "TRANSID";
                
            default:
                return null;
        }
    }
    
    /**
     * Checks if this command type is a browse operation.
     */
    public boolean isBrowseOperation() {
        return this == STARTBR || this == READNEXT || this == READPREV ||
               this == RESETBR || this == ENDBR;
    }
    
    /**
     * Checks if this command type modifies data.
     */
    public boolean modifiesData() {
        return this == WRITE || this == REWRITE || this == DELETE ||
               this == WRITEQ_TS || this == WRITEQ_TD ||
               this == PUT_CONTAINER;
    }
    
    /**
     * Functional category for CICS commands.
     */
    public enum CICSCategory {
        FILE_CONTROL,
        PROGRAM_CONTROL,
        TERMINAL_CONTROL,
        TEMPORARY_STORAGE,
        TRANSIENT_DATA,
        STORAGE_CONTROL,
        INTERVAL_CONTROL,
        CONTAINER,
        SYNCPOINT,
        EXCEPTION,
        INQUIRY,
        UNKNOWN
    }
}
