package org.openmainframeproject.cobolcheck.features.cics;

import java.util.*;
import java.util.regex.Pattern;

/**
 * Represents a complete CICS mock definition parsed from a test suite.
 * Contains all information needed to match EXEC CICS commands and generate
 * mock COBOL code.
 * 
 * Example usage in test suite:
 * <pre>
 * MOCK EXEC CICS READ FILE('CUSTFILE') INTO(WS-CUST-REC) RIDFLD(WS-KEY)
 *     RETURNS RESP(DFHRESP(NORMAL))
 *     WITH DATA
 *         CUST-ID = "C00001"
 *         CUST-NAME = "ACME CORP"
 *     END-DATA
 * END-MOCK
 * </pre>
 */
public class CICSMockDefinition {
    
    private final String id;
    private final CICSCommandType commandType;
    private final String rawCommand;
    private final Map<String, String> options;
    private final Set<String> flags;
    private final List<CICSMockDataRow> dataRows;
    
    private CICSResponseCode resp;
    private int resp2;
    private int returnLength;
    private int returnItem;
    private int invocationCount;
    
    // Source location for error reporting
    private String sourceFile;
    private int sourceLine;
    
    /**
     * Creates a new CICS mock definition.
     * 
     * @param id         Unique identifier (e.g., "CICS-MOCK-001")
     * @param rawCommand The raw CICS command string
     */
    public CICSMockDefinition(String id, String rawCommand) {
        if (id == null || id.trim().isEmpty()) {
            throw new IllegalArgumentException("Mock ID cannot be null or empty");
        }
        if (rawCommand == null || rawCommand.trim().isEmpty()) {
            throw new IllegalArgumentException("CICS command cannot be null or empty");
        }
        
        this.id = id;
        this.rawCommand = normalizeCommand(rawCommand);
        this.commandType = CICSCommandType.fromCommand(this.rawCommand);
        this.options = new LinkedHashMap<>();
        this.flags = new HashSet<>();
        this.dataRows = new ArrayList<>();
        this.resp = CICSResponseCode.NORMAL;
        this.resp2 = 0;
        this.returnLength = -1;
        this.returnItem = -1;
        this.invocationCount = 0;
        
        parseOptions(this.rawCommand);
    }
    
    /**
     * Gets the unique identifier for this mock.
     */
    public String getId() {
        return id;
    }
    
    /**
     * Gets the CICS command type.
     */
    public CICSCommandType getCommandType() {
        return commandType;
    }
    
    /**
     * Gets the raw command string.
     */
    public String getRawCommand() {
        return rawCommand;
    }
    
    /**
     * Gets an option value.
     * 
     * @param optionName The option name (e.g., "FILE", "PROGRAM")
     * @return The option value, or null if not set
     */
    public String getOption(String optionName) {
        return options.get(optionName.toUpperCase());
    }
    
    /**
     * Sets an option value.
     * 
     * @param optionName  The option name
     * @param optionValue The option value
     */
    public void setOption(String optionName, String optionValue) {
        options.put(optionName.toUpperCase(), optionValue);
    }
    
    /**
     * Gets all options.
     */
    public Map<String, String> getOptions() {
        return Collections.unmodifiableMap(options);
    }
    
    /**
     * Checks if a flag option is set.
     * 
     * @param flagName The flag name (e.g., "UPDATE", "NOSUSPEND")
     * @return true if the flag is set
     */
    public boolean hasFlag(String flagName) {
        return flags.contains(flagName.toUpperCase());
    }
    
    /**
     * Adds a flag option.
     * 
     * @param flagName The flag name
     */
    public void addFlag(String flagName) {
        flags.add(flagName.toUpperCase());
    }
    
    /**
     * Gets all flags.
     */
    public Set<String> getFlags() {
        return Collections.unmodifiableSet(flags);
    }
    
    /**
     * Gets the primary identifier for matching.
     * For FILE commands this is the file name, for LINK it's the program name, etc.
     */
    public String getPrimaryIdentifier() {
        String primaryOption = commandType.getPrimaryOption();
        if (primaryOption != null) {
            return getOption(primaryOption);
        }
        return null;
    }
    
    /**
     * Gets the RESP code to return.
     */
    public CICSResponseCode getResp() {
        return resp;
    }
    
    /**
     * Sets the RESP code to return.
     */
    public void setResp(CICSResponseCode resp) {
        this.resp = resp != null ? resp : CICSResponseCode.NORMAL;
    }
    
    /**
     * Sets the RESP code from a string.
     */
    public void setResp(String respValue) {
        this.resp = CICSResponseCode.parse(respValue);
    }
    
    /**
     * Gets the RESP2 code to return.
     */
    public int getResp2() {
        return resp2;
    }
    
    /**
     * Sets the RESP2 code to return.
     */
    public void setResp2(int resp2) {
        this.resp2 = resp2;
    }
    
    /**
     * Gets the LENGTH to return (for RECEIVE, READQ, etc.)
     */
    public int getReturnLength() {
        return returnLength;
    }
    
    /**
     * Sets the LENGTH to return.
     */
    public void setReturnLength(int length) {
        this.returnLength = length;
    }
    
    /**
     * Gets the ITEM number to return (for WRITEQ TS).
     */
    public int getReturnItem() {
        return returnItem;
    }
    
    /**
     * Sets the ITEM number to return.
     */
    public void setReturnItem(int item) {
        this.returnItem = item;
    }
    
    /**
     * Adds a data row to the mock.
     */
    public void addDataRow(CICSMockDataRow row) {
        if (row != null) {
            dataRows.add(row);
        }
    }
    
    /**
     * Gets all data rows.
     */
    public List<CICSMockDataRow> getDataRows() {
        return new ArrayList<>(dataRows);
    }
    
    /**
     * Gets a specific data row.
     */
    public CICSMockDataRow getDataRow(int index) {
        if (index >= 0 && index < dataRows.size()) {
            return dataRows.get(index);
        }
        return null;
    }
    
    /**
     * Gets the number of data rows.
     */
    public int getRowCount() {
        return dataRows.size();
    }
    
    /**
     * Checks if an actual CICS command matches this mock.
     * 
     * @param actualCommand The CICS command from the program being tested
     * @return true if the command matches this mock
     */
    public boolean matches(String actualCommand) {
        if (actualCommand == null || actualCommand.trim().isEmpty()) {
            return false;
        }
        
        String normalizedActual = normalizeCommand(actualCommand);
        CICSCommandType actualType = CICSCommandType.fromCommand(normalizedActual);
        
        // Command type must match
        if (actualType != commandType) {
            return false;
        }
        
        // Primary identifier must match (if applicable)
        String primaryOption = commandType.getPrimaryOption();
        if (primaryOption != null) {
            String expectedValue = getOption(primaryOption);
            String actualValue = extractOptionValue(normalizedActual, primaryOption);
            
            if (expectedValue != null && !matchOptionValue(expectedValue, actualValue)) {
                return false;
            }
        }
        
        // For more specific matching, check additional options
        // This allows multiple mocks for the same file but different keys
        return true;
    }
    
    /**
     * Records that this mock was invoked.
     */
    public void recordInvocation() {
        invocationCount++;
    }
    
    /**
     * Gets the invocation count.
     */
    public int getInvocationCount() {
        return invocationCount;
    }
    
    /**
     * Resets the invocation count.
     */
    public void resetInvocationCount() {
        invocationCount = 0;
    }
    
    /**
     * Sets the source file for error reporting.
     */
    public void setSourceFile(String sourceFile) {
        this.sourceFile = sourceFile;
    }
    
    /**
     * Sets the source line for error reporting.
     */
    public void setSourceLine(int sourceLine) {
        this.sourceLine = sourceLine;
    }
    
    /**
     * Gets a descriptive source location string.
     */
    public String getSourceLocation() {
        if (sourceFile != null) {
            return sourceFile + ":" + sourceLine;
        }
        return "line " + sourceLine;
    }
    
    /**
     * Normalizes a CICS command string.
     */
    private String normalizeCommand(String command) {
        String normalized = command.toUpperCase()
            .replaceAll("\\s+", " ")
            .trim();
        
        // Remove EXEC CICS wrapper if present
        if (normalized.startsWith("EXEC CICS ")) {
            normalized = normalized.substring(10);
        }
        
        // Remove END-EXEC if present
        if (normalized.endsWith(" END-EXEC")) {
            normalized = normalized.substring(0, normalized.length() - 9);
        }
        if (normalized.endsWith("END-EXEC")) {
            normalized = normalized.substring(0, normalized.length() - 8);
        }
        
        return normalized.trim();
    }
    
    /**
     * Parses options from the command string.
     */
    private void parseOptions(String command) {
        // Pattern to match OPTION(value) or OPTION('value') or just OPTION
        Pattern optionPattern = Pattern.compile(
            "([A-Z][A-Z0-9]*)(?:\\(([^)]+)\\)|(?=\\s|$))");
        
        var matcher = optionPattern.matcher(command);
        boolean isFirst = true;
        
        while (matcher.find()) {
            String name = matcher.group(1);
            String value = matcher.group(2);
            
            // Skip the command type itself
            if (isFirst) {
                isFirst = false;
                // Check for two-word commands
                if (command.startsWith(name + " ")) {
                    String secondWord = command.substring(name.length() + 1).split("\\s+")[0];
                    if (!secondWord.contains("(")) {
                        continue; // Skip second word of two-word command
                    }
                }
                continue;
            }
            
            if (value != null) {
                // Remove quotes if present
                value = value.replaceAll("^['\"]|['\"]$", "");
                options.put(name, value);
            } else {
                // Flag option
                flags.add(name);
            }
        }
    }
    
    /**
     * Extracts an option value from a command string.
     */
    private String extractOptionValue(String command, String optionName) {
        Pattern pattern = Pattern.compile(
            optionName + "\\s*\\(\\s*([^)]+)\\s*\\)",
            Pattern.CASE_INSENSITIVE);
        var matcher = pattern.matcher(command);
        if (matcher.find()) {
            return matcher.group(1).replaceAll("^['\"]|['\"]$", "").trim();
        }
        return null;
    }
    
    /**
     * Compares option values, handling quotes and case.
     */
    private boolean matchOptionValue(String expected, String actual) {
        if (expected == null && actual == null) return true;
        if (expected == null || actual == null) return false;
        
        String e = expected.replaceAll("^['\"]|['\"]$", "").toUpperCase();
        String a = actual.replaceAll("^['\"]|['\"]$", "").toUpperCase();
        
        return e.equals(a);
    }
    
    @Override
    public String toString() {
        return String.format("CICSMockDefinition{id='%s', type=%s, primary='%s', resp=%s, rows=%d}",
            id, commandType, getPrimaryIdentifier(), resp.name(), dataRows.size());
    }
}
