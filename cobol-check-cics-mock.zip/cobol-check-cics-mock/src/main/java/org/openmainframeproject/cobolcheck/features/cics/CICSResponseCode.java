package org.openmainframeproject.cobolcheck.features.cics;

import java.util.HashMap;
import java.util.Map;

/**
 * CICS response codes (DFHRESP values).
 * These are the standard EIBRESP values returned by CICS commands.
 */
public enum CICSResponseCode {
    
    // =========================================================================
    // NORMAL COMPLETION
    // =========================================================================
    
    NORMAL(0, "Normal completion"),
    
    // =========================================================================
    // GENERAL CONDITIONS
    // =========================================================================
    
    ERROR(1, "General error condition"),
    RDATT(2, "Read attention identifier (3270)"),
    WRBRK(3, "Write break (3270)"),
    EOF(4, "End of file"),
    EODS(5, "End of data set"),
    EOC(6, "End of chain"),
    INBFMH(7, "Inbound FMH received"),
    ENDINPT(8, "End of input"),
    NONVAL(9, "Non-valid request"),
    NOSTART(10, "No start"),
    TERMIDERR(11, "Terminal ID error"),
    FILENOTFOUND(12, "File not found"),
    NOTFND(13, "Record not found"),
    DUPREC(14, "Duplicate record"),
    DUPKEY(15, "Duplicate key"),
    INVREQ(16, "Invalid request"),
    IOERR(17, "I/O error"),
    NOSPACE(18, "No space"),
    NOTOPEN(19, "File not open"),
    ENDFILE(20, "End of file during browse"),
    ILLOGIC(21, "VSAM logical error"),
    LENGERR(22, "Length error"),
    QZERO(23, "Queue is empty (TS/TD)"),
    SIGNAL(24, "Signal received"),
    QBUSY(25, "Queue busy"),
    ITEMERR(26, "Item number error"),
    PGMIDERR(27, "Program not found"),
    TRANSIDERR(28, "Transaction ID error"),
    ENDDATA(29, "End of data"),
    INVTSREQ(30, "Invalid TS request"),
    EXPIRED(31, "Expired"),
    RETPAGE(32, "Return page"),
    RTEFAIL(33, "Route failed"),
    RTESOME(34, "Route some"),
    TSIOERR(35, "TS I/O error"),
    MAPFAIL(36, "Map failure"),
    INVERRTERM(37, "Invalid error term"),
    INVMPSZ(38, "Invalid map size"),
    IGREQID(39, "IG request ID error"),
    OVERFLOW(40, "Overflow"),
    INVLDC(41, "Invalid LDC"),
    NOSTG(42, "No storage"),
    JIDERR(43, "Journal ID error"),
    QIDERR(44, "Queue ID error"),
    NOJBUFSP(45, "No journal buffer space"),
    DSSTAT(46, "Data set status error"),
    SELNERR(47, "Select error"),
    FUNCERR(48, "Function error"),
    UNEXPIN(49, "Unexpected input"),
    NOPASSBKRD(50, "No pass back read"),
    NOPASSBKWR(51, "No pass back write"),
    SEGIDERR(52, "Segment ID error"),
    SYSIDERR(53, "System ID error"),
    ISCINVREQ(54, "ISC invalid request"),
    ENQBUSY(55, "ENQ busy"),
    ENVDEFERR(56, "Environment definition error"),
    IGREQCD(57, "IG request code"),
    SESSIONERR(58, "Session error"),
    SYSBUSY(59, "System busy"),
    SESSBUSY(60, "Session busy"),
    NOTALLOC(61, "Not allocated"),
    CBIDERR(62, "CB ID error"),
    INVEXITREQ(63, "Invalid exit request"),
    INVPARTNSET(64, "Invalid partner set"),
    INVPARTN(65, "Invalid partner"),
    PARTNFAIL(66, "Partner failure"),
    
    // =========================================================================
    // SECURITY AND AUTHORIZATION
    // =========================================================================
    
    NOTAUTH(70, "Not authorized"),
    
    // =========================================================================
    // RESOURCE STATUS
    // =========================================================================
    
    VOTEFAIL(72, "Vote failure"),
    NOTFINISHED(73, "Not finished"),
    
    // =========================================================================
    // LOADING AND PROCESSING
    // =========================================================================
    
    LOADING(82, "Program being loaded"),
    SUPPRESSED(83, "Suppressed"),
    DISABLED(84, "Resource disabled"),
    
    // =========================================================================
    // MISCELLANEOUS
    // =========================================================================
    
    ALLOCERR(85, "Allocation error"),
    STRELERR(86, "String element error"),
    OPENERR(87, "Open error"),
    SPOLBUSY(88, "Spool busy"),
    SPOLERR(89, "Spool error"),
    NODEIDERR(90, "Node ID error"),
    TASKIDERR(91, "Task ID error"),
    TABORERR(92, "Table error"),
    DABORERR(93, "Data error"),
    TCIDERR(94, "TC ID error"),
    DSIDERR(95, "DS ID error"),
    TERMERR(96, "Terminal error"),
    ROLLEDBACK(100, "Transaction rolled back"),
    END(101, "End"),
    
    // =========================================================================
    // CHANNEL/CONTAINER
    // =========================================================================
    
    CHANNELERR(110, "Channel error"),
    CONTAINERERR(111, "Container error"),
    CCSIDERR(112, "CCSID error"),
    TIMEDOUT(113, "Timed out"),
    CODEPAGEERR(114, "Code page error"),
    INCOMPLETE(115, "Incomplete"),
    
    // =========================================================================
    // WEB SERVICES
    // =========================================================================
    
    TOKENERR(120, "Token error"),
    ACTIVITYERR(121, "Activity error"),
    PROCESSERR(122, "Process error"),
    
    // =========================================================================
    // SPECIAL
    // =========================================================================
    
    UNKNOWN(-1, "Unknown response code");
    
    private final int value;
    private final String description;
    
    private static final Map<Integer, CICSResponseCode> BY_VALUE = new HashMap<>();
    private static final Map<String, CICSResponseCode> BY_NAME = new HashMap<>();
    
    static {
        for (CICSResponseCode code : values()) {
            BY_VALUE.put(code.value, code);
            BY_NAME.put(code.name(), code);
        }
    }
    
    CICSResponseCode(int value, String description) {
        this.value = value;
        this.description = description;
    }
    
    /**
     * Gets the numeric value of this response code.
     */
    public int getValue() {
        return value;
    }
    
    /**
     * Gets a description of this response code.
     */
    public String getDescription() {
        return description;
    }
    
    /**
     * Gets a response code by its numeric value.
     * 
     * @param value The numeric response code value
     * @return The corresponding CICSResponseCode, or UNKNOWN if not found
     */
    public static CICSResponseCode fromValue(int value) {
        return BY_VALUE.getOrDefault(value, UNKNOWN);
    }
    
    /**
     * Gets a response code by its name.
     * Handles DFHRESP(name) format.
     * 
     * @param name The response code name (e.g., "NORMAL", "NOTFND", "DFHRESP(NORMAL)")
     * @return The corresponding CICSResponseCode, or UNKNOWN if not found
     */
    public static CICSResponseCode fromName(String name) {
        if (name == null || name.trim().isEmpty()) {
            return UNKNOWN;
        }
        
        String normalized = name.trim().toUpperCase();
        
        // Handle DFHRESP(name) format
        if (normalized.startsWith("DFHRESP(") && normalized.endsWith(")")) {
            normalized = normalized.substring(8, normalized.length() - 1);
        }
        
        return BY_NAME.getOrDefault(normalized, UNKNOWN);
    }
    
    /**
     * Parses a response code from either a numeric value or name.
     * 
     * @param value String that is either a number or a DFHRESP name
     * @return The corresponding CICSResponseCode
     */
    public static CICSResponseCode parse(String value) {
        if (value == null || value.trim().isEmpty()) {
            return UNKNOWN;
        }
        
        String trimmed = value.trim();
        
        // Try parsing as number first
        try {
            int numericValue = Integer.parseInt(trimmed);
            return fromValue(numericValue);
        } catch (NumberFormatException e) {
            // Not a number, try as name
            return fromName(trimmed);
        }
    }
    
    /**
     * Checks if this response code indicates success.
     */
    public boolean isSuccess() {
        return this == NORMAL;
    }
    
    /**
     * Checks if this response code indicates a "not found" condition.
     */
    public boolean isNotFound() {
        return this == NOTFND || this == ENDFILE || this == QZERO;
    }
    
    /**
     * Checks if this response code indicates a duplicate error.
     */
    public boolean isDuplicate() {
        return this == DUPREC || this == DUPKEY;
    }
    
    /**
     * Checks if this response code indicates an authorization error.
     */
    public boolean isAuthError() {
        return this == NOTAUTH;
    }
    
    /**
     * Generates COBOL code for DFHRESP constant definitions.
     * 
     * @return List of COBOL lines defining all DFHRESP values
     */
    public static String generateDFHRESPCopybook() {
        StringBuilder sb = new StringBuilder();
        sb.append("      * DFHRESP VALUES - GENERATED BY COBOL-CHECK\n");
        sb.append("       01  DFHRESP-VALUES.\n");
        
        for (CICSResponseCode code : values()) {
            if (code != UNKNOWN) {
                String name = String.format("%-18s", "DFHRESP-" + code.name());
                sb.append(String.format("           05  %s PIC S9(8) COMP VALUE %d.\n",
                    name, code.value));
            }
        }
        
        return sb.toString();
    }
    
    @Override
    public String toString() {
        return String.format("DFHRESP(%s) [%d: %s]", name(), value, description);
    }
}
