package org.openmainframeproject.cobolcheck.features.cics;

import java.util.*;

/**
 * Parser for CICS mock syntax in COBOL Check test suites.
 * 
 * Parses mock definitions in the format:
 * <pre>
 * MOCK EXEC CICS <command> <options>
 *     [RETURNS RESP(<value>)]
 *     [RETURNS RESP2(<value>)]
 *     [RETURNS LENGTH(<value>)]
 *     [RETURNS ITEM(<value>)]
 *     [WITH DATA
 *         [ROW <n>]
 *         <field> = <value>
 *         [RESP = <value>]
 *         [END-ROW]
 *     END-DATA]
 * END-MOCK
 * </pre>
 */
public class CICSMockParser {
    
    private static final Set<String> KEYWORDS = new HashSet<>(Arrays.asList(
        "MOCK", "EXEC", "CICS", "RETURNS", "RESP", "RESP2", "LENGTH", "ITEM",
        "WITH", "DATA", "END-DATA", "ROW", "END-ROW", "END-MOCK",
        "VERIFY", "HAPPENED", "TIMES", "ONCE", "TWICE", "NEVER", "AT", "LEAST", "MOST"
    ));
    
    private final CICSMockRepository repository;
    private List<String> tokens;
    private int currentIndex;
    private String currentTestFile;
    private int currentLine;
    
    /**
     * Creates a new CICS mock parser.
     * 
     * @param repository The repository to store parsed mocks
     */
    public CICSMockParser(CICSMockRepository repository) {
        this.repository = repository;
    }
    
    /**
     * Sets the current source file for error reporting.
     */
    public void setCurrentTestFile(String testFile) {
        this.currentTestFile = testFile;
    }
    
    /**
     * Sets the current line number for error reporting.
     */
    public void setCurrentLine(int line) {
        this.currentLine = line;
    }
    
    /**
     * Checks if tokens indicate a CICS mock start.
     */
    public boolean isCICSMockStart(List<String> tokens, int index) {
        if (index + 2 >= tokens.size()) return false;
        return "MOCK".equalsIgnoreCase(tokens.get(index)) &&
               "EXEC".equalsIgnoreCase(tokens.get(index + 1)) &&
               "CICS".equalsIgnoreCase(tokens.get(index + 2));
    }
    
    /**
     * Checks if tokens indicate a CICS verification.
     */
    public boolean isCICSVerify(List<String> tokens, int index) {
        if (index + 2 >= tokens.size()) return false;
        return "VERIFY".equalsIgnoreCase(tokens.get(index)) &&
               "EXEC".equalsIgnoreCase(tokens.get(index + 1)) &&
               "CICS".equalsIgnoreCase(tokens.get(index + 2));
    }
    
    /**
     * Parses a CICS mock block from the token stream.
     * 
     * @param tokens     The complete token list
     * @param startIndex Index of the MOCK token
     * @return ParseResult containing the mock and end index
     * @throws CICSMockParseException if parsing fails
     */
    public ParseResult parseMock(List<String> tokens, int startIndex)
            throws CICSMockParseException {
        this.tokens = tokens;
        this.currentIndex = startIndex;
        
        // Verify MOCK EXEC CICS
        expect("MOCK");
        expect("EXEC");
        expect("CICS");
        
        // Parse CICS command (everything until RETURNS, WITH, or END-MOCK)
        String cicsCommand = parseCICSCommand();
        
        // Create mock definition
        String mockId = repository.generateMockId();
        CICSMockDefinition mock = new CICSMockDefinition(mockId, cicsCommand);
        mock.setSourceFile(currentTestFile);
        mock.setSourceLine(currentLine);
        
        // Parse optional clauses
        while (currentIndex < tokens.size()) {
            String token = peekToken();
            
            if ("RETURNS".equalsIgnoreCase(token)) {
                parseReturns(mock);
            } else if ("WITH".equalsIgnoreCase(token)) {
                parseWithData(mock);
            } else if ("END-MOCK".equalsIgnoreCase(token)) {
                consumeToken();
                break;
            } else {
                throw new CICSMockParseException(
                    "Unexpected token '" + token + "' in CICS mock at " + getLocation());
            }
        }
        
        repository.addMock(mock);
        return new ParseResult(mock, currentIndex);
    }
    
    /**
     * Parses a CICS verification statement.
     */
    public VerifyParseResult parseVerify(List<String> tokens, int startIndex)
            throws CICSMockParseException {
        this.tokens = tokens;
        this.currentIndex = startIndex;
        
        expect("VERIFY");
        expect("EXEC");
        expect("CICS");
        
        // Parse command pattern
        String commandPattern = parseCICSCommand();
        
        // Parse HAPPENED clause
        int expectedCount = 1;
        CICSMockRepository.VerificationComparison comparison =
            CICSMockRepository.VerificationComparison.EXACTLY;
        
        if (matchToken("HAPPENED")) {
            if (matchToken("NEVER")) {
                expectedCount = 0;
                comparison = CICSMockRepository.VerificationComparison.NEVER;
            } else if (matchToken("ONCE")) {
                expectedCount = 1;
            } else if (matchToken("TWICE")) {
                expectedCount = 2;
            } else if (matchToken("AT")) {
                if (matchToken("LEAST")) {
                    comparison = CICSMockRepository.VerificationComparison.AT_LEAST;
                } else if (matchToken("MOST")) {
                    comparison = CICSMockRepository.VerificationComparison.AT_MOST;
                }
                expectedCount = parseNumber();
                matchToken("TIMES");
            } else {
                expectedCount = parseNumber();
                matchToken("TIMES");
            }
        }
        
        return new VerifyParseResult(commandPattern, expectedCount, comparison, currentIndex);
    }
    
    /**
     * Parses the CICS command portion.
     */
    private String parseCICSCommand() throws CICSMockParseException {
        StringBuilder command = new StringBuilder();
        int parenDepth = 0;
        
        while (currentIndex < tokens.size()) {
            String token = peekToken();
            
            // Track parentheses depth
            if (token.contains("(")) {
                parenDepth += countChar(token, '(');
            }
            if (token.contains(")")) {
                parenDepth -= countChar(token, ')');
            }
            
            // Stop at keywords (only if not inside parentheses)
            if (parenDepth == 0 && isStopKeyword(token)) {
                break;
            }
            
            if (command.length() > 0) {
                command.append(" ");
            }
            command.append(consumeToken());
        }
        
        if (command.length() == 0) {
            throw new CICSMockParseException(
                "Empty CICS command in mock at " + getLocation());
        }
        
        return command.toString();
    }
    
    /**
     * Parses RETURNS clause.
     */
    private void parseReturns(CICSMockDefinition mock) throws CICSMockParseException {
        expect("RETURNS");
        String returnType = consumeToken().toUpperCase();
        
        switch (returnType) {
            case "RESP":
                expect("(");
                String respValue = parseRespValue();
                expect(")");
                mock.setResp(respValue);
                break;
                
            case "RESP2":
                expect("(");
                int resp2 = parseNumber();
                expect(")");
                mock.setResp2(resp2);
                break;
                
            case "LENGTH":
                expect("(");
                int length = parseNumber();
                expect(")");
                mock.setReturnLength(length);
                break;
                
            case "ITEM":
                expect("(");
                int item = parseNumber();
                expect(")");
                mock.setReturnItem(item);
                break;
                
            default:
                throw new CICSMockParseException(
                    "Unknown RETURNS type '" + returnType + "' at " + getLocation());
        }
    }
    
    /**
     * Parses a RESP value (can be DFHRESP(name) or number).
     */
    private String parseRespValue() throws CICSMockParseException {
        StringBuilder value = new StringBuilder();
        
        String token = consumeToken();
        value.append(token);
        
        // Handle DFHRESP(name)
        if (token.equalsIgnoreCase("DFHRESP")) {
            expect("(");
            value.append("(").append(consumeToken()).append(")");
            expect(")");
        }
        
        return value.toString();
    }
    
    /**
     * Parses WITH DATA block.
     */
    private void parseWithData(CICSMockDefinition mock) throws CICSMockParseException {
        expect("WITH");
        expect("DATA");
        
        CICSMockDataRow currentRow = new CICSMockDataRow();
        boolean inRow = false;
        
        while (currentIndex < tokens.size()) {
            String token = peekToken();
            
            if ("END-DATA".equalsIgnoreCase(token)) {
                consumeToken();
                // Add last row if it has data
                if (currentRow.getFieldCount() > 0 || currentRow.hasRowResp()) {
                    mock.addDataRow(currentRow);
                }
                break;
            }
            
            if ("ROW".equalsIgnoreCase(token)) {
                // Save previous row if exists
                if (inRow && (currentRow.getFieldCount() > 0 || currentRow.hasRowResp())) {
                    mock.addDataRow(currentRow);
                }
                
                consumeToken(); // ROW
                parseNumber();  // Row number (informational)
                currentRow = new CICSMockDataRow();
                inRow = true;
                continue;
            }
            
            if ("END-ROW".equalsIgnoreCase(token)) {
                consumeToken();
                if (currentRow.getFieldCount() > 0 || currentRow.hasRowResp()) {
                    mock.addDataRow(currentRow);
                }
                currentRow = new CICSMockDataRow();
                inRow = false;
                continue;
            }
            
            if ("RESP".equalsIgnoreCase(token)) {
                consumeToken();
                expect("=");
                String respValue = parseRespValue();
                currentRow.setRowResp(respValue);
                continue;
            }
            
            if ("LENGTH".equalsIgnoreCase(token)) {
                consumeToken();
                expect("=");
                int length = parseNumber();
                currentRow.setReturnLength(length);
                continue;
            }
            
            // Field assignment: FIELD-NAME = value
            String fieldName = consumeToken();
            expect("=");
            String fieldValue = parseFieldValue();
            currentRow.setFieldValue(fieldName, fieldValue);
        }
    }
    
    /**
     * Parses a field value.
     */
    private String parseFieldValue() throws CICSMockParseException {
        String token = peekToken();
        
        // Handle DFHRESP for inline response codes
        if ("DFHRESP".equalsIgnoreCase(token)) {
            return parseRespValue();
        }
        
        // String value
        if (token.startsWith("\"") || token.startsWith("'")) {
            return parseStringValue();
        }
        
        // Numeric value
        if (token.equals("-") || token.matches("-?\\d.*")) {
            return parseNumericValue();
        }
        
        return consumeToken();
    }
    
    /**
     * Parses a quoted string value.
     */
    private String parseStringValue() throws CICSMockParseException {
        String token = consumeToken();
        
        if (token.startsWith("\"") || token.startsWith("'")) {
            char quote = token.charAt(0);
            
            if (token.length() > 1 && token.endsWith(String.valueOf(quote))) {
                return token.substring(1, token.length() - 1);
            }
            
            // Multi-token string
            StringBuilder sb = new StringBuilder(token.substring(1));
            while (currentIndex < tokens.size()) {
                String next = consumeToken();
                if (next.endsWith(String.valueOf(quote))) {
                    sb.append(" ").append(next, 0, next.length() - 1);
                    break;
                }
                sb.append(" ").append(next);
            }
            return sb.toString();
        }
        
        return token;
    }
    
    /**
     * Parses a numeric value.
     */
    private String parseNumericValue() throws CICSMockParseException {
        StringBuilder sb = new StringBuilder();
        
        if (peekToken().equals("-")) {
            sb.append(consumeToken());
        }
        
        sb.append(consumeToken());
        return sb.toString();
    }
    
    /**
     * Parses an integer number.
     */
    private int parseNumber() throws CICSMockParseException {
        String token = consumeToken();
        try {
            return Integer.parseInt(token);
        } catch (NumberFormatException e) {
            throw new CICSMockParseException(
                "Expected number, got '" + token + "' at " + getLocation());
        }
    }
    
    /**
     * Checks if token is a stop keyword.
     */
    private boolean isStopKeyword(String token) {
        String upper = token.toUpperCase();
        return upper.equals("RETURNS") || upper.equals("WITH") ||
               upper.equals("END-MOCK") || upper.equals("END-DATA") ||
               upper.equals("HAPPENED");
    }
    
    /**
     * Counts occurrences of a character in a string.
     */
    private int countChar(String str, char c) {
        int count = 0;
        for (char ch : str.toCharArray()) {
            if (ch == c) count++;
        }
        return count;
    }
    
    /**
     * Expects and consumes a specific token.
     */
    private void expect(String expected) throws CICSMockParseException {
        String actual = consumeToken();
        if (expected.equals("(") || expected.equals(")")) {
            if (!actual.equals(expected)) {
                throw new CICSMockParseException(
                    "Expected '" + expected + "', got '" + actual + "' at " + getLocation());
            }
        } else if (!expected.equalsIgnoreCase(actual)) {
            throw new CICSMockParseException(
                "Expected '" + expected + "', got '" + actual + "' at " + getLocation());
        }
    }
    
    /**
     * Tries to match and consume a token.
     */
    private boolean matchToken(String expected) {
        if (currentIndex < tokens.size() &&
            expected.equalsIgnoreCase(peekToken())) {
            consumeToken();
            return true;
        }
        return false;
    }
    
    /**
     * Peeks at the current token.
     */
    private String peekToken() {
        if (currentIndex >= tokens.size()) {
            return "";
        }
        return tokens.get(currentIndex);
    }
    
    /**
     * Consumes and returns the current token.
     */
    private String consumeToken() throws CICSMockParseException {
        if (currentIndex >= tokens.size()) {
            throw new CICSMockParseException(
                "Unexpected end of input at " + getLocation());
        }
        return tokens.get(currentIndex++);
    }
    
    /**
     * Gets current location string.
     */
    private String getLocation() {
        if (currentTestFile != null) {
            return currentTestFile + ":" + currentLine;
        }
        return "line " + currentLine;
    }
    
    // =========================================================================
    // RESULT CLASSES
    // =========================================================================
    
    /**
     * Result of parsing a mock definition.
     */
    public static class ParseResult {
        private final CICSMockDefinition mock;
        private final int endIndex;
        
        public ParseResult(CICSMockDefinition mock, int endIndex) {
            this.mock = mock;
            this.endIndex = endIndex;
        }
        
        public CICSMockDefinition getMock() { return mock; }
        public int getEndIndex() { return endIndex; }
    }
    
    /**
     * Result of parsing a verification statement.
     */
    public static class VerifyParseResult {
        private final String commandPattern;
        private final int expectedCount;
        private final CICSMockRepository.VerificationComparison comparison;
        private final int endIndex;
        
        public VerifyParseResult(String commandPattern, int expectedCount,
                                  CICSMockRepository.VerificationComparison comparison,
                                  int endIndex) {
            this.commandPattern = commandPattern;
            this.expectedCount = expectedCount;
            this.comparison = comparison;
            this.endIndex = endIndex;
        }
        
        public String getCommandPattern() { return commandPattern; }
        public int getExpectedCount() { return expectedCount; }
        public CICSMockRepository.VerificationComparison getComparison() { return comparison; }
        public int getEndIndex() { return endIndex; }
    }
    
    /**
     * Exception thrown when CICS mock parsing fails.
     */
    public static class CICSMockParseException extends Exception {
        public CICSMockParseException(String message) {
            super(message);
        }
    }
}
