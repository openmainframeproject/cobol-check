package org.openmainframeproject.cobolcheck.features.cics;

import java.util.*;

/**
 * Repository for managing CICS mock definitions.
 * Provides storage, lookup, and verification capabilities.
 * 
 * Features:
 * - Stores mock definitions with unique IDs
 * - Matches EXEC CICS commands to mock definitions
 * - Tracks browse states for file browsing operations
 * - Supports mock verification
 * - Handles TS queue item numbers
 */
public class CICSMockRepository {
    
    private final List<CICSMockDefinition> mocks;
    private final Map<String, BrowseState> browseStates;
    private final Map<String, TSQueueState> tsQueueStates;
    private final Map<String, Integer> unmockedCommands;
    private int mockIdCounter;
    private boolean strictMatching;
    private boolean logUnmocked;
    
    /**
     * Creates a new empty CICS mock repository.
     */
    public CICSMockRepository() {
        this.mocks = new ArrayList<>();
        this.browseStates = new HashMap<>();
        this.tsQueueStates = new HashMap<>();
        this.unmockedCommands = new LinkedHashMap<>();
        this.mockIdCounter = 0;
        this.strictMatching = false;
        this.logUnmocked = true;
    }
    
    /**
     * Generates a unique ID for a new mock.
     * 
     * @return A unique mock ID (e.g., "CICS-MOCK-001")
     */
    public String generateMockId() {
        mockIdCounter++;
        return String.format("CICS-MOCK-%03d", mockIdCounter);
    }
    
    /**
     * Adds a mock definition to the repository.
     * 
     * @param mock The mock definition to add
     */
    public void addMock(CICSMockDefinition mock) {
        if (mock != null) {
            mocks.add(mock);
            
            // Initialize browse state if needed
            if (mock.getCommandType().isBrowseOperation()) {
                String fileName = mock.getOption("FILE");
                if (fileName != null && !browseStates.containsKey(fileName)) {
                    browseStates.put(fileName, new BrowseState(fileName));
                }
            }
            
            // Initialize TS queue state if needed
            if (mock.getCommandType() == CICSCommandType.WRITEQ_TS ||
                mock.getCommandType() == CICSCommandType.READQ_TS) {
                String queueName = mock.getOption("QUEUE");
                if (queueName != null && !tsQueueStates.containsKey(queueName)) {
                    tsQueueStates.put(queueName, new TSQueueState(queueName));
                }
            }
        }
    }
    
    /**
     * Finds a mock definition that matches the given CICS command.
     * 
     * @param actualCommand The CICS command from the program being tested
     * @return The matching mock definition, or null if no match
     */
    public CICSMockDefinition findMock(String actualCommand) {
        if (actualCommand == null || actualCommand.trim().isEmpty()) {
            return null;
        }
        
        // Search in reverse order so later definitions override earlier ones
        for (int i = mocks.size() - 1; i >= 0; i--) {
            CICSMockDefinition mock = mocks.get(i);
            if (mock.matches(actualCommand)) {
                return mock;
            }
        }
        
        // Track unmocked commands
        if (logUnmocked) {
            String normalized = normalizeForLogging(actualCommand);
            unmockedCommands.merge(normalized, 1, Integer::sum);
        }
        
        return null;
    }
    
    /**
     * Gets all mock definitions.
     */
    public List<CICSMockDefinition> getAllMocks() {
        return Collections.unmodifiableList(mocks);
    }
    
    /**
     * Gets the number of mock definitions.
     */
    public int getMockCount() {
        return mocks.size();
    }
    
    /**
     * Finds a mock by its ID.
     */
    public CICSMockDefinition findById(String id) {
        return mocks.stream()
            .filter(m -> m.getId().equals(id))
            .findFirst()
            .orElse(null);
    }
    
    // =========================================================================
    // BROWSE STATE MANAGEMENT
    // =========================================================================
    
    /**
     * Gets the browse state for a file.
     */
    public BrowseState getBrowseState(String fileName) {
        return browseStates.get(fileName.toUpperCase());
    }
    
    /**
     * Starts a browse on a file.
     */
    public void startBrowse(String fileName, int totalRows) {
        String name = fileName.toUpperCase();
        BrowseState state = browseStates.get(name);
        if (state == null) {
            state = new BrowseState(name);
            browseStates.put(name, state);
        }
        state.start(totalRows);
    }
    
    /**
     * Gets the next row in a browse and advances position.
     * 
     * @return Current row index, or -1 if at end
     */
    public int browseNext(String fileName) {
        BrowseState state = browseStates.get(fileName.toUpperCase());
        if (state != null && state.isActive()) {
            return state.next();
        }
        return -1;
    }
    
    /**
     * Gets the previous row in a browse.
     * 
     * @return Current row index, or -1 if at start
     */
    public int browsePrev(String fileName) {
        BrowseState state = browseStates.get(fileName.toUpperCase());
        if (state != null && state.isActive()) {
            return state.prev();
        }
        return -1;
    }
    
    /**
     * Ends a browse on a file.
     */
    public void endBrowse(String fileName) {
        BrowseState state = browseStates.get(fileName.toUpperCase());
        if (state != null) {
            state.end();
        }
    }
    
    /**
     * Resets browse position.
     */
    public void resetBrowse(String fileName) {
        BrowseState state = browseStates.get(fileName.toUpperCase());
        if (state != null) {
            state.reset();
        }
    }
    
    // =========================================================================
    // TS QUEUE STATE MANAGEMENT
    // =========================================================================
    
    /**
     * Gets the next item number for a TS queue write.
     */
    public int getNextTSQueueItem(String queueName) {
        String name = queueName.toUpperCase();
        TSQueueState state = tsQueueStates.get(name);
        if (state == null) {
            state = new TSQueueState(name);
            tsQueueStates.put(name, state);
        }
        return state.nextItem();
    }
    
    /**
     * Gets the current item count for a TS queue.
     */
    public int getTSQueueItemCount(String queueName) {
        TSQueueState state = tsQueueStates.get(queueName.toUpperCase());
        return state != null ? state.getItemCount() : 0;
    }
    
    // =========================================================================
    // VERIFICATION
    // =========================================================================
    
    /**
     * Verifies that a mock was invoked the expected number of times.
     * 
     * @param commandPattern The command pattern to verify
     * @param expectedCount  The expected invocation count
     * @param comparison     The comparison type
     * @return VerificationResult with success status and message
     */
    public VerificationResult verify(String commandPattern, int expectedCount,
                                      VerificationComparison comparison) {
        CICSMockDefinition mock = findMockByPattern(commandPattern);
        
        if (mock == null) {
            return new VerificationResult(false,
                "No mock found for pattern: " + commandPattern);
        }
        
        int actualCount = mock.getInvocationCount();
        boolean passed;
        
        switch (comparison) {
            case EXACTLY:
                passed = actualCount == expectedCount;
                break;
            case AT_LEAST:
                passed = actualCount >= expectedCount;
                break;
            case AT_MOST:
                passed = actualCount <= expectedCount;
                break;
            case NEVER:
                passed = actualCount == 0;
                break;
            default:
                passed = actualCount == expectedCount;
        }
        
        String message;
        if (passed) {
            message = String.format("PASS: CICS mock '%s' was invoked %d time(s)",
                mock.getId(), actualCount);
        } else {
            message = String.format("FAIL: CICS mock '%s' expected %s %d, actual %d",
                mock.getId(), comparison.getDescription(), expectedCount, actualCount);
        }
        
        return new VerificationResult(passed, message);
    }
    
    /**
     * Finds a mock by command pattern.
     */
    private CICSMockDefinition findMockByPattern(String pattern) {
        String normalizedPattern = pattern.toUpperCase().trim();
        
        // Try exact raw command match first
        for (CICSMockDefinition mock : mocks) {
            if (mock.getRawCommand().contains(normalizedPattern)) {
                return mock;
            }
        }
        
        // Try matching by command type and primary identifier
        CICSCommandType type = CICSCommandType.fromCommand(normalizedPattern);
        String primaryOption = type.getPrimaryOption();
        
        if (primaryOption != null) {
            // Extract primary value from pattern
            String primaryValue = extractOptionValue(normalizedPattern, primaryOption);
            
            for (CICSMockDefinition mock : mocks) {
                if (mock.getCommandType() == type) {
                    String mockPrimary = mock.getOption(primaryOption);
                    if (matchValues(primaryValue, mockPrimary)) {
                        return mock;
                    }
                }
            }
        }
        
        // Fall back to command type only
        for (CICSMockDefinition mock : mocks) {
            if (mock.getCommandType() == type) {
                return mock;
            }
        }
        
        return null;
    }
    
    private String extractOptionValue(String command, String optionName) {
        int start = command.indexOf(optionName + "(");
        if (start < 0) {
            start = command.indexOf(optionName + " (");
        }
        if (start < 0) return null;
        
        int parenStart = command.indexOf("(", start);
        int parenEnd = command.indexOf(")", parenStart);
        if (parenStart >= 0 && parenEnd > parenStart) {
            return command.substring(parenStart + 1, parenEnd)
                .replaceAll("^['\"]|['\"]$", "").trim();
        }
        return null;
    }
    
    private boolean matchValues(String v1, String v2) {
        if (v1 == null && v2 == null) return true;
        if (v1 == null || v2 == null) return false;
        return v1.equalsIgnoreCase(v2);
    }
    
    // =========================================================================
    // RESET AND CLEAR
    // =========================================================================
    
    /**
     * Resets all mock invocation counts.
     */
    public void resetInvocationCounts() {
        mocks.forEach(CICSMockDefinition::resetInvocationCount);
    }
    
    /**
     * Resets all browse and queue states.
     */
    public void resetStates() {
        browseStates.values().forEach(BrowseState::reset);
        tsQueueStates.values().forEach(TSQueueState::reset);
    }
    
    /**
     * Clears all mocks and states.
     */
    public void clearAll() {
        mocks.clear();
        browseStates.clear();
        tsQueueStates.clear();
        unmockedCommands.clear();
        mockIdCounter = 0;
    }
    
    /**
     * Gets report of unmocked commands.
     */
    public Map<String, Integer> getUnmockedCommandsReport() {
        return Collections.unmodifiableMap(unmockedCommands);
    }
    
    /**
     * Checks if any unmocked commands were encountered.
     */
    public boolean hasUnmockedCommands() {
        return !unmockedCommands.isEmpty();
    }
    
    public void setStrictMatching(boolean strict) {
        this.strictMatching = strict;
    }
    
    public void setLogUnmocked(boolean log) {
        this.logUnmocked = log;
    }
    
    private String normalizeForLogging(String command) {
        return command.toUpperCase()
            .replaceAll("\\s+", " ")
            .trim()
            .substring(0, Math.min(command.length(), 60));
    }
    
    // =========================================================================
    // INNER CLASSES
    // =========================================================================
    
    /**
     * State for browse operations.
     */
    public static class BrowseState {
        private final String fileName;
        private boolean active;
        private int currentRow;
        private int totalRows;
        private int direction; // 1 = forward, -1 = backward
        
        public BrowseState(String fileName) {
            this.fileName = fileName;
            reset();
        }
        
        public void start(int rows) {
            this.active = true;
            this.currentRow = -1;
            this.totalRows = rows;
            this.direction = 1;
        }
        
        public void end() {
            this.active = false;
        }
        
        public void reset() {
            this.active = false;
            this.currentRow = -1;
            this.totalRows = 0;
            this.direction = 1;
        }
        
        public int next() {
            if (!active) return -1;
            currentRow++;
            direction = 1;
            return currentRow < totalRows ? currentRow : -1;
        }
        
        public int prev() {
            if (!active) return -1;
            currentRow--;
            direction = -1;
            return currentRow >= 0 ? currentRow : -1;
        }
        
        public boolean isActive() { return active; }
        public int getCurrentRow() { return currentRow; }
        public int getTotalRows() { return totalRows; }
        public String getFileName() { return fileName; }
        public boolean hasMoreRows() { 
            return active && currentRow < totalRows - 1; 
        }
    }
    
    /**
     * State for TS queues.
     */
    public static class TSQueueState {
        private final String queueName;
        private int itemCount;
        
        public TSQueueState(String queueName) {
            this.queueName = queueName;
            this.itemCount = 0;
        }
        
        public int nextItem() {
            return ++itemCount;
        }
        
        public int getItemCount() {
            return itemCount;
        }
        
        public void reset() {
            itemCount = 0;
        }
        
        public String getQueueName() {
            return queueName;
        }
    }
    
    /**
     * Verification comparison types.
     */
    public enum VerificationComparison {
        EXACTLY("exactly"),
        AT_LEAST("at least"),
        AT_MOST("at most"),
        NEVER("never");
        
        private final String description;
        
        VerificationComparison(String description) {
            this.description = description;
        }
        
        public String getDescription() {
            return description;
        }
    }
    
    /**
     * Verification result.
     */
    public static class VerificationResult {
        private final boolean passed;
        private final String message;
        
        public VerificationResult(boolean passed, String message) {
            this.passed = passed;
            this.message = message;
        }
        
        public boolean passed() { return passed; }
        public String getMessage() { return message; }
    }
}
