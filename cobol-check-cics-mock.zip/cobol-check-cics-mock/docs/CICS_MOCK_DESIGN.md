# CICS Mock Framework for COBOL Check

## Executive Summary

This document describes the design and implementation of CICS mocking capabilities for the COBOL Check testing framework. The CICS mock feature enables developers to unit test COBOL programs that contain EXEC CICS commands without requiring a live CICS region.

## 1. Overview

### 1.1 Problem Statement

CICS (Customer Information Control System) programs interact with various CICS services:
- File Control (READ, WRITE, REWRITE, DELETE, BROWSE)
- Program Control (LINK, XCTL, RETURN)
- Terminal Control (SEND, RECEIVE)
- Temporary Storage (READQ TS, WRITEQ TS, DELETEQ TS)
- Transient Data (READQ TD, WRITEQ TD)
- Storage Control (GETMAIN, FREEMAIN)
- Interval Control (START, RETRIEVE, CANCEL)
- Exception Handling (HANDLE CONDITION, HANDLE ABEND)

Testing these programs traditionally requires a running CICS region, making unit testing difficult.

### 1.2 Solution

The CICS Mock Framework intercepts EXEC CICS commands during test execution and:
- Returns predefined data for READ operations
- Simulates WRITE, REWRITE, DELETE operations
- Provides configurable RESP/RESP2 responses
- Supports container and channel operations
- Enables verification of CICS command execution

## 2. CICS Response Codes

### 2.1 Common DFHRESP Values

| Name | Value | Description |
|------|-------|-------------|
| NORMAL | 0 | Successful completion |
| ERROR | 1 | General error |
| RDATT | 2 | Read attention |
| WRBRK | 3 | Write break |
| EOF | 4 | End of file |
| EODS | 5 | End of data set |
| EOC | 6 | End of chain |
| INBFMH | 7 | Inbound FMH |
| ENDINPT | 8 | End of input |
| NONVAL | 9 | Non-valid request |
| NOTFND | 13 | Record not found |
| DUPREC | 14 | Duplicate record |
| DUPKEY | 15 | Duplicate key |
| INVREQ | 16 | Invalid request |
| IOERR | 17 | I/O error |
| NOSPACE | 18 | No space |
| NOTOPEN | 19 | File not open |
| ENDFILE | 20 | End of file (browse) |
| ILLOGIC | 21 | VSAM logical error |
| LENGERR | 22 | Length error |
| QZERO | 23 | Queue zero (TS/TD empty) |
| ITEMERR | 26 | Item error |
| PGMIDERR | 27 | Program not found |
| NOTAUTH | 70 | Not authorized |
| DISABLED | 84 | File/program disabled |

## 3. Syntax Design

### 3.1 Basic CICS Mock Syntax

```cobol
MOCK EXEC CICS <command> <options>
    [RETURNS RESP(<value>)]
    [RETURNS RESP2(<value>)]
    [WITH DATA
        <field-assignments>
    END-DATA]
END-MOCK
```

### 3.2 File Control Examples

#### 3.2.1 Mock READ Command

```cobol
MOCK EXEC CICS READ
              FILE('CUSTFILE')
              INTO(WS-CUSTOMER-REC)
              RIDFLD(WS-CUST-KEY)
    RETURNS RESP(DFHRESP(NORMAL))
    WITH DATA
        CUST-ID = "C00001"
        CUST-NAME = "ACME CORPORATION"
        CUST-BALANCE = 15000.50
    END-DATA
END-MOCK
```

#### 3.2.2 Mock READ with NOT FOUND

```cobol
MOCK EXEC CICS READ
              FILE('CUSTFILE')
              INTO(WS-CUSTOMER-REC)
              RIDFLD(WS-CUST-KEY)
    RETURNS RESP(DFHRESP(NOTFND))
END-MOCK
```

#### 3.2.3 Mock WRITE Command

```cobol
MOCK EXEC CICS WRITE
              FILE('CUSTFILE')
              FROM(WS-CUSTOMER-REC)
              RIDFLD(WS-CUST-KEY)
    RETURNS RESP(DFHRESP(NORMAL))
END-MOCK
```

#### 3.2.4 Mock REWRITE Command

```cobol
MOCK EXEC CICS REWRITE
              FILE('CUSTFILE')
              FROM(WS-CUSTOMER-REC)
    RETURNS RESP(DFHRESP(NORMAL))
END-MOCK
```

#### 3.2.5 Mock DELETE Command

```cobol
MOCK EXEC CICS DELETE
              FILE('CUSTFILE')
              RIDFLD(WS-CUST-KEY)
    RETURNS RESP(DFHRESP(NORMAL))
END-MOCK
```

#### 3.2.6 Mock BROWSE Operations

```cobol
MOCK EXEC CICS STARTBR
              FILE('CUSTFILE')
              RIDFLD(WS-CUST-KEY)
    RETURNS RESP(DFHRESP(NORMAL))
END-MOCK

MOCK EXEC CICS READNEXT
              FILE('CUSTFILE')
              INTO(WS-CUSTOMER-REC)
              RIDFLD(WS-CUST-KEY)
    RETURNS RESP(DFHRESP(NORMAL))
    WITH DATA
        ROW 1
            CUST-ID = "C00001"
            CUST-NAME = "ACME"
        END-ROW
        ROW 2
            CUST-ID = "C00002"
            CUST-NAME = "BETA"
        END-ROW
        ROW 3
            RESP = DFHRESP(ENDFILE)
        END-ROW
    END-DATA
END-MOCK

MOCK EXEC CICS ENDBR
              FILE('CUSTFILE')
    RETURNS RESP(DFHRESP(NORMAL))
END-MOCK
```

### 3.3 Program Control Examples

#### 3.3.1 Mock LINK Command

```cobol
MOCK EXEC CICS LINK
              PROGRAM('SUBPGM01')
              COMMAREA(WS-COMMAREA)
              LENGTH(WS-COMM-LEN)
    RETURNS RESP(DFHRESP(NORMAL))
    WITH DATA
        COMM-RETURN-CODE = "00"
        COMM-MESSAGE = "SUCCESS"
    END-DATA
END-MOCK
```

#### 3.3.2 Mock LINK with Program Not Found

```cobol
MOCK EXEC CICS LINK
              PROGRAM('BADPGM')
    RETURNS RESP(DFHRESP(PGMIDERR))
END-MOCK
```

### 3.4 Temporary Storage Examples

#### 3.4.1 Mock WRITEQ TS

```cobol
MOCK EXEC CICS WRITEQ TS
              QUEUE('MYQUEUE')
              FROM(WS-TS-DATA)
              LENGTH(WS-TS-LEN)
    RETURNS RESP(DFHRESP(NORMAL))
    RETURNS ITEM(1)
END-MOCK
```

#### 3.4.2 Mock READQ TS

```cobol
MOCK EXEC CICS READQ TS
              QUEUE('MYQUEUE')
              INTO(WS-TS-DATA)
              ITEM(1)
    RETURNS RESP(DFHRESP(NORMAL))
    WITH DATA
        WS-TS-DATA = "QUEUE ITEM DATA"
    END-DATA
END-MOCK
```

#### 3.4.3 Mock READQ TS with Queue Empty

```cobol
MOCK EXEC CICS READQ TS
              QUEUE('EMPTYQ')
    RETURNS RESP(DFHRESP(QZERO))
END-MOCK
```

### 3.5 Terminal Control Examples

#### 3.5.1 Mock RECEIVE

```cobol
MOCK EXEC CICS RECEIVE
              INTO(WS-INPUT-DATA)
              LENGTH(WS-INPUT-LEN)
    RETURNS RESP(DFHRESP(NORMAL))
    RETURNS LENGTH(80)
    WITH DATA
        WS-INPUT-DATA = "USER INPUT DATA"
    END-DATA
END-MOCK
```

#### 3.5.2 Mock SEND

```cobol
MOCK EXEC CICS SEND
              FROM(WS-OUTPUT-DATA)
              LENGTH(WS-OUTPUT-LEN)
    RETURNS RESP(DFHRESP(NORMAL))
END-MOCK
```

#### 3.5.3 Mock SEND MAP (BMS)

```cobol
MOCK EXEC CICS SEND MAP('CUSTMAP')
              MAPSET('CUSTSET')
              FROM(CUSTMAPO)
    RETURNS RESP(DFHRESP(NORMAL))
END-MOCK
```

#### 3.5.4 Mock RECEIVE MAP

```cobol
MOCK EXEC CICS RECEIVE MAP('CUSTMAP')
              MAPSET('CUSTSET')
              INTO(CUSTMAPI)
    RETURNS RESP(DFHRESP(NORMAL))
    WITH DATA
        CUSTIDI = "C00001"
        CUSTNAMEI = "JOHN DOE"
    END-DATA
END-MOCK
```

### 3.6 Storage Control Examples

#### 3.6.1 Mock GETMAIN

```cobol
MOCK EXEC CICS GETMAIN
              SET(WS-POINTER)
              FLENGTH(WS-LENGTH)
    RETURNS RESP(DFHRESP(NORMAL))
END-MOCK
```

### 3.7 Container/Channel Examples

#### 3.7.1 Mock PUT CONTAINER

```cobol
MOCK EXEC CICS PUT CONTAINER('MYCONTAINER')
              CHANNEL('MYCHANNEL')
              FROM(WS-CONTAINER-DATA)
    RETURNS RESP(DFHRESP(NORMAL))
END-MOCK
```

#### 3.7.2 Mock GET CONTAINER

```cobol
MOCK EXEC CICS GET CONTAINER('MYCONTAINER')
              CHANNEL('MYCHANNEL')
              INTO(WS-CONTAINER-DATA)
    RETURNS RESP(DFHRESP(NORMAL))
    WITH DATA
        WS-CONTAINER-DATA = "CONTAINER CONTENTS"
    END-DATA
END-MOCK
```

### 3.8 Verification Syntax

```cobol
VERIFY EXEC CICS READ FILE('CUSTFILE') HAPPENED ONCE

VERIFY EXEC CICS LINK PROGRAM('SUBPGM01') HAPPENED 2 TIMES

VERIFY EXEC CICS WRITEQ TS QUEUE('MYQUEUE') NEVER HAPPENED
```

## 4. Architecture

### 4.1 Component Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                      Test Suite Parser                          │
│  (Existing cobol-check component)                               │
└──────────────────────────┬──────────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────────┐
│                    CICSMockParser                               │
│  - Parses MOCK EXEC CICS blocks                                 │
│  - Extracts commands, options, return values                    │
│  - Creates CICSMockDefinition objects                           │
└──────────────────────────┬──────────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────────┐
│                  CICSMockRepository                             │
│  - Stores all CICS mock definitions                             │
│  - Matches EXEC CICS commands to mocks                          │
│  - Tracks browse states and invocation counts                   │
└──────────────────────────┬──────────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────────┐
│                  CICSMockCodeGenerator                          │
│  - Generates COBOL replacement code                             │
│  - Creates WORKING-STORAGE entries for mock data                │
│  - Creates DFHRESP copybook equivalent                          │
└─────────────────────────────────────────────────────────────────┘
```

### 4.2 Class Diagram

```
┌───────────────────────────────┐
│      CICSCommandType          │
├───────────────────────────────┤
│ READ, WRITE, REWRITE, DELETE  │
│ STARTBR, READNEXT, READPREV   │
│ RESETBR, ENDBR                │
│ LINK, XCTL, RETURN            │
│ SEND, RECEIVE                 │
│ SEND_MAP, RECEIVE_MAP         │
│ WRITEQ_TS, READQ_TS, DELETEQ  │
│ WRITEQ_TD, READQ_TD           │
│ GETMAIN, FREEMAIN             │
│ PUT_CONTAINER, GET_CONTAINER  │
│ START, RETRIEVE, CANCEL       │
└───────────────────────────────┘

┌───────────────────────────────┐
│      CICSMockDefinition       │
├───────────────────────────────┤
│ - id: String                  │
│ - commandType: CICSCommandType│
│ - options: Map<String,String> │
│ - resp: int                   │
│ - resp2: int                  │
│ - mockDataRows: List          │
│ - invocationCount: int        │
├───────────────────────────────┤
│ + matches(cmd): boolean       │
│ + getNextRow(): Map           │
│ + recordInvocation(): void    │
└───────────────────────────────┘

┌───────────────────────────────┐
│      CICSMockRepository       │
├───────────────────────────────┤
│ - mocks: List<CICSMockDef>    │
│ - browseStates: Map           │
├───────────────────────────────┤
│ + addMock(def): void          │
│ + findMock(cmd): CICSMockDef  │
│ + verify(pattern, count)      │
└───────────────────────────────┘
```

## 5. Implementation Notes

### 5.1 CICS Command Parsing

CICS commands have a complex syntax with many optional parameters:

```cobol
EXEC CICS READ
    FILE(name)           - Required
    INTO(data-area)      - Optional (or SET)
    SET(pointer)         - Optional (or INTO)
    RIDFLD(data-area)    - Required for keyed
    KEYLENGTH(value)     - Optional
    LENGTH(data-area)    - Optional
    SYSID(name)          - Optional (remote)
    UPDATE               - Optional flag
    RESP(data-area)      - Optional
    RESP2(data-area)     - Optional
END-EXEC
```

The parser extracts:
1. Command type (first word after EXEC CICS)
2. Options with values: `OPTION(value)`
3. Flag options: `OPTION` (no value)
4. RESP/RESP2 fields

### 5.2 Pattern Matching

For mock matching, we use a hierarchical approach:
1. Command type must match exactly
2. Primary identifier must match (FILE, PROGRAM, QUEUE, etc.)
3. Other options are used for disambiguation if needed

Example: Two mocks for READ FILE('CUSTFILE'):
- One with RIDFLD value starting with 'A' → returns customer A
- One with RIDFLD value starting with 'B' → returns customer B

### 5.3 Browse State Management

Browse operations (STARTBR, READNEXT, READPREV, ENDBR) require state:

```java
public class BrowseState {
    private String fileName;
    private boolean active;
    private int currentRow;
    private int direction; // 1=forward, -1=backward
    
    public void start() { active = true; currentRow = 0; direction = 1; }
    public void end() { active = false; }
    public void setDirection(int dir) { direction = dir; }
    public int next() { currentRow += direction; return currentRow; }
}
```

### 5.4 DFHRESP Generation

Generate a copybook-style set of 88-levels:

```cobol
       01  CCHK-CICS-RESP-CODES.
           05  CCHK-DFHRESP-NORMAL     PIC S9(8) COMP VALUE 0.
           05  CCHK-DFHRESP-ERROR      PIC S9(8) COMP VALUE 1.
           05  CCHK-DFHRESP-NOTFND     PIC S9(8) COMP VALUE 13.
           05  CCHK-DFHRESP-DUPREC     PIC S9(8) COMP VALUE 14.
           ...
```

## 6. Generated COBOL Structure

### 6.1 WORKING-STORAGE

```cobol
      * CICS MOCK WORKING STORAGE
       01  CCHK-CICS-MOCK-AREA.
           05  CCHK-CICS-RESP          PIC S9(8) COMP VALUE 0.
           05  CCHK-CICS-RESP2         PIC S9(8) COMP VALUE 0.
           05  CCHK-CICS-MOCK-COUNT-001 PIC 9(4) VALUE 0.
           05  CCHK-CICS-ROW-IDX-001   PIC 9(4) VALUE 1.
           ...
       
       01  CCHK-CICS-MOCK-DATA-001.
           05  CCHK-CICS-ROW-001 OCCURS 10.
               10  CCHK-FIELD-001      PIC X(50).
               10  CCHK-FIELD-002      PIC S9(9)V99.
               10  CCHK-ROW-RESP       PIC S9(8) COMP.
```

### 6.2 Mock Handler Paragraph

```cobol
       CCHK-CICS-HANDLER-001.
           ADD 1 TO CCHK-CICS-MOCK-COUNT-001
           MOVE CCHK-CICS-RESP-001 TO EIBRESP
           MOVE CCHK-CICS-RESP2-001 TO EIBRESP2
           IF EIBRESP = DFHRESP(NORMAL)
               PERFORM CCHK-CICS-DATA-001
           END-IF.
       
       CCHK-CICS-DATA-001.
           MOVE CCHK-FIELD-001(CCHK-CICS-ROW-IDX-001)
               TO CUST-NAME
           ADD 1 TO CCHK-CICS-ROW-IDX-001.
```

## 7. Configuration

```properties
# CICS Mock Configuration
cics.mock.enabled=true
cics.mock.default.resp=0
cics.mock.log.unmatched=true
cics.mock.strict.matching=false
```

## 8. Future Enhancements

1. **HANDLE CONDITION**: Mock exception handling
2. **ABEND**: Simulate abend conditions
3. **ENQ/DEQ**: Resource locking simulation
4. **JOURNAL**: Journal write mocking
5. **WEB commands**: HTTP client mocking
6. **DOCUMENT commands**: Document template mocking
