# CICS Mock Framework for COBOL Check

[![License](https://img.shields.io/badge/license-Apache%202.0-blue.svg)](LICENSE)

This extension adds CICS mocking capabilities to [COBOL Check](https://github.com/openmainframeproject/cobol-check), enabling developers to unit test CICS programs without requiring a live CICS region.

## Features

- **File Control**: READ, WRITE, REWRITE, DELETE, STARTBR, READNEXT, READPREV, ENDBR
- **Program Control**: LINK, XCTL, RETURN
- **Terminal Control**: SEND, RECEIVE, SEND MAP, RECEIVE MAP
- **Temporary Storage**: WRITEQ TS, READQ TS, DELETEQ TS
- **Transient Data**: WRITEQ TD, READQ TD
- **Storage Control**: GETMAIN, FREEMAIN
- **Container/Channel**: PUT CONTAINER, GET CONTAINER
- **Full DFHRESP Support**: All standard CICS response codes

## Quick Start

### Example Test Suite

```cobol
TESTSUITE "Customer File Operations"

TESTCASE "Should read customer successfully"

* Mock the READ command
MOCK EXEC CICS READ
       FILE('CUSTFILE')
       INTO(WS-CUSTOMER-REC)
       RIDFLD(WS-CUST-KEY)
    RETURNS RESP(DFHRESP(NORMAL))
    WITH DATA
        CUST-ID = "C00001"
        CUST-NAME = "ACME CORPORATION"
        CUST-BALANCE = 15000.50
    END-DATA
END-MOCK

* Execute the paragraph
MOVE "C00001" TO WS-CUST-KEY
PERFORM 2000-READ-CUSTOMER

* Verify results
EXPECT WS-CUST-NAME TO BE "ACME CORPORATION"
VERIFY EXEC CICS READ FILE('CUSTFILE') HAPPENED ONCE
```

## Syntax Reference

### Basic Mock

```cobol
MOCK EXEC CICS <command> <options>
    [RETURNS RESP(<dfhresp-value>)]
    [RETURNS RESP2(<value>)]
    [RETURNS LENGTH(<value>)]
    [RETURNS ITEM(<value>)]
    [WITH DATA
        <field> = <value>
        ...
    END-DATA]
END-MOCK
```

### File Control Examples

```cobol
* READ with data
MOCK EXEC CICS READ FILE('MYFILE') INTO(WS-REC) RIDFLD(WS-KEY)
    RETURNS RESP(DFHRESP(NORMAL))
    WITH DATA
        FIELD1 = "VALUE1"
        FIELD2 = 12345
    END-DATA
END-MOCK

* READ not found
MOCK EXEC CICS READ FILE('MYFILE')
    RETURNS RESP(DFHRESP(NOTFND))
END-MOCK

* Browse with multiple rows
MOCK EXEC CICS READNEXT FILE('MYFILE')
    WITH DATA
        ROW 1
            KEY-FIELD = "K001"
        END-ROW
        ROW 2
            KEY-FIELD = "K002"
        END-ROW
        ROW 3
            RESP = DFHRESP(ENDFILE)
        END-ROW
    END-DATA
END-MOCK
```

### Program Control

```cobol
* LINK with COMMAREA update
MOCK EXEC CICS LINK PROGRAM('SUBPGM') COMMAREA(WS-COMM)
    RETURNS RESP(DFHRESP(NORMAL))
    WITH DATA
        COMM-RETURN-CODE = "00"
        COMM-MESSAGE = "SUCCESS"
    END-DATA
END-MOCK

* LINK program not found
MOCK EXEC CICS LINK PROGRAM('BADPGM')
    RETURNS RESP(DFHRESP(PGMIDERR))
END-MOCK
```

### Terminal Control

```cobol
* RECEIVE MAP with input data
MOCK EXEC CICS RECEIVE MAP('CUSTMAP') MAPSET('CUSTSET')
    RETURNS RESP(DFHRESP(NORMAL))
    WITH DATA
        CUSTIDI = "C00001"
        CUSTNAMEI = "JOHN DOE"
    END-DATA
END-MOCK
```

### Temporary Storage

```cobol
* WRITEQ TS
MOCK EXEC CICS WRITEQ TS QUEUE('MYQUEUE') FROM(WS-DATA)
    RETURNS RESP(DFHRESP(NORMAL))
    RETURNS ITEM(1)
END-MOCK

* READQ TS with data
MOCK EXEC CICS READQ TS QUEUE('MYQUEUE') INTO(WS-DATA) ITEM(1)
    RETURNS RESP(DFHRESP(NORMAL))
    WITH DATA
        WS-DATA = "QUEUE CONTENT"
    END-DATA
END-MOCK
```

### Verification

```cobol
VERIFY EXEC CICS READ FILE('CUSTFILE') HAPPENED ONCE
VERIFY EXEC CICS LINK PROGRAM('SUBPGM') HAPPENED 2 TIMES
VERIFY EXEC CICS WRITEQ TS QUEUE('AUDITQ') NEVER HAPPENED
VERIFY EXEC CICS DELETE FILE('CUSTFILE') HAPPENED AT LEAST 1 TIMES
```

## Common DFHRESP Values

| DFHRESP | Value | Description |
|---------|-------|-------------|
| NORMAL | 0 | Successful completion |
| NOTFND | 13 | Record not found |
| DUPREC | 14 | Duplicate record |
| DUPKEY | 15 | Duplicate key |
| INVREQ | 16 | Invalid request |
| IOERR | 17 | I/O error |
| NOSPACE | 18 | No space available |
| NOTOPEN | 19 | File not open |
| ENDFILE | 20 | End of file (browse) |
| LENGERR | 22 | Length error |
| QZERO | 23 | Queue is empty |
| ITEMERR | 26 | Item number error |
| PGMIDERR | 27 | Program not found |
| NOTAUTH | 70 | Not authorized |
| DISABLED | 84 | Resource disabled |

## Project Structure

```
cobol-check-cics-mock/
├── docs/
│   └── CICS_MOCK_DESIGN.md
├── examples/
│   ├── CUSTINQ.CBL          # Sample CICS program
│   └── CUSTINQ.cut          # Sample test suite
└── src/main/java/.../cics/
    ├── CICSCommandType.java
    ├── CICSResponseCode.java
    ├── CICSMockDataRow.java
    ├── CICSMockDefinition.java
    ├── CICSMockRepository.java
    ├── CICSMockParser.java
    └── CICSMockCodeGenerator.java
```

## Supported Commands

| Category | Commands |
|----------|----------|
| File Control | READ, WRITE, REWRITE, DELETE, UNLOCK, STARTBR, READNEXT, READPREV, RESETBR, ENDBR |
| Program Control | LINK, XCTL, RETURN, LOAD, RELEASE |
| Terminal Control | SEND, RECEIVE, SEND MAP, RECEIVE MAP, SEND CONTROL, SEND TEXT, CONVERSE |
| Temp Storage | WRITEQ TS, READQ TS, DELETEQ TS |
| Transient Data | WRITEQ TD, READQ TD, DELETEQ TD |
| Storage | GETMAIN, FREEMAIN |
| Interval | START, RETRIEVE, CANCEL, DELAY, ASKTIME, FORMATTIME |
| Container | PUT CONTAINER, GET CONTAINER, DELETE CONTAINER |
| Syncpoint | SYNCPOINT, SYNCPOINT ROLLBACK |

## Installation

See the integration guide in `docs/CICS_MOCK_DESIGN.md` for detailed instructions.

## License

Apache License 2.0

## Contributing

Contributions welcome! Please follow [COBOL Check contribution guidelines](https://github.com/openmainframeproject/cobol-check/blob/main/CONTRIBUTING.md).
