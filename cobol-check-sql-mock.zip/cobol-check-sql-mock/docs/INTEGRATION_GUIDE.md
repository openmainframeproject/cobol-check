# Integration Guide: SQL Mock Framework for COBOL Check

This document describes how to integrate the SQL Mock Framework into the existing COBOL Check codebase.

## 1. File Placement

Copy the following files to the cobol-check source tree:

```
cobol-check/
├── src/main/java/org/openmainframeproject/cobolcheck/
│   └── features/
│       └── sql/                          # NEW DIRECTORY
│           ├── SQLStatementType.java
│           ├── SQLMockDataRow.java
│           ├── SQLMockDefinition.java
│           ├── SQLMockRepository.java
│           ├── SQLMockParser.java
│           └── SQLMockCodeGenerator.java
└── src/test/java/org/openmainframeproject/cobolcheck/
    └── features/
        └── sql/                          # NEW DIRECTORY
            ├── SQLStatementTypeTest.java
            └── SQLMockDefinitionTest.java
```

## 2. TestSuiteParser Integration

### 2.1 Add SQL Mock Import

In `TestSuiteParser.java`, add:

```java
import org.openmainframeproject.cobolcheck.features.sql.*;
```

### 2.2 Add SQL Mock Repository Field

```java
public class TestSuiteParser {
    // Existing fields...
    
    private SQLMockRepository sqlMockRepository;
    private SQLMockParser sqlMockParser;
    
    public TestSuiteParser(/* existing params */) {
        // Existing initialization...
        
        this.sqlMockRepository = new SQLMockRepository();
        this.sqlMockParser = new SQLMockParser(sqlMockRepository);
    }
}
```

### 2.3 Add SQL Mock Keyword Recognition

In the keyword constants section:

```java
private static final String MOCK_TOKEN = "MOCK";
private static final String EXEC_TOKEN = "EXEC";
private static final String SQL_TOKEN = "SQL";
private static final String VERIFY_TOKEN = "VERIFY";
```

### 2.4 Modify Parse Loop

In the main parsing loop (likely `parseTestSuite()` or similar):

```java
private void parseTokens(List<String> tokens) {
    int index = 0;
    while (index < tokens.size()) {
        String token = tokens.get(index);
        
        // Existing keyword handling...
        
        // NEW: Check for SQL mock
        if (sqlMockParser.isExecSQL(tokens, index)) {
            try {
                SQLMockParser.ParseResult result = 
                    sqlMockParser.parseMock(tokens, index);
                index = result.getEndIndex();
                continue;
            } catch (SQLMockParser.SQLMockParseException e) {
                throw new TestSuiteParseException(e.getMessage());
            }
        }
        
        // NEW: Check for SQL verify
        if (sqlMockParser.isSQLVerify(token) && 
            index + 2 < tokens.size() &&
            "EXEC".equalsIgnoreCase(tokens.get(index + 1)) &&
            "SQL".equalsIgnoreCase(tokens.get(index + 2))) {
            try {
                SQLMockParser.VerifyParseResult result =
                    sqlMockParser.parseVerify(tokens, index);
                // Store verification for later code generation
                storeVerification(result);
                index = result.getEndIndex();
                continue;
            } catch (SQLMockParser.SQLMockParseException e) {
                throw new TestSuiteParseException(e.getMessage());
            }
        }
        
        // Continue with existing parsing...
        index++;
    }
}
```

### 2.5 Add Getter for SQL Repository

```java
public SQLMockRepository getSQLMockRepository() {
    return sqlMockRepository;
}
```

## 3. Generator Integration

### 3.1 Add Import and Field

In `Generator.java`:

```java
import org.openmainframeproject.cobolcheck.features.sql.*;

public class Generator {
    // Existing fields...
    
    private SQLMockCodeGenerator sqlMockCodeGenerator;
    
    public Generator(/* existing params */) {
        // After getting SQL repository from parser:
        this.sqlMockCodeGenerator = new SQLMockCodeGenerator(
            testSuiteParser.getSQLMockRepository());
    }
}
```

### 3.2 Modify WORKING-STORAGE Generation

In the method that generates WORKING-STORAGE:

```java
private void writeWorkingStorageSection(Writer writer) {
    // Existing WORKING-STORAGE generation...
    
    // NEW: Add SQL mock working storage
    List<String> sqlMockWS = sqlMockCodeGenerator.generateWorkingStorageEntries();
    for (String line : sqlMockWS) {
        writer.writeLine(line);
    }
}
```

### 3.3 Modify PROCEDURE DIVISION Generation

In the method that processes PROCEDURE DIVISION:

```java
private void processProcedureDivision(Reader reader, Writer writer) {
    String line;
    while ((line = reader.readLine()) != null) {
        
        // NEW: Check for EXEC SQL
        if (isExecSQLStart(line)) {
            String fullSQL = accumulateExecSQL(reader, line);
            SQLMockDefinition mock = sqlMockRepository.findMock(fullSQL);
            
            if (mock != null) {
                // Replace EXEC SQL with mock handler call
                mock.recordInvocation();
                writer.writeLine(sqlMockCodeGenerator.generateMockCall(mock));
            } else {
                // No mock - write original SQL
                // Optionally log warning about unmocked SQL
                writer.writeLine(line);
                // Write remaining SQL lines...
            }
            continue;
        }
        
        // Existing line processing...
        writer.writeLine(line);
    }
}

private boolean isExecSQLStart(String line) {
    String trimmed = line.trim().toUpperCase();
    return trimmed.contains("EXEC") && trimmed.contains("SQL");
}

private String accumulateExecSQL(Reader reader, String firstLine) {
    StringBuilder sql = new StringBuilder(firstLine);
    String line;
    while ((line = reader.readLine()) != null) {
        sql.append(" ").append(line.trim());
        if (line.trim().toUpperCase().contains("END-EXEC")) {
            break;
        }
    }
    return sql.toString();
}
```

### 3.4 Add Mock Handler Paragraphs

At the end of PROCEDURE DIVISION generation:

```java
private void writeMockHandlerParagraphs(Writer writer) {
    List<String> handlers = sqlMockCodeGenerator.generateAllMockHandlers();
    for (String line : handlers) {
        writer.writeLine(line);
    }
}
```

## 4. Configuration

### 4.1 Add to config.properties

```properties
# SQL Mock Configuration
sql.mock.enabled=true
sql.mock.default.sqlcode=0
sql.mock.max.rows.per.mock=100
sql.mock.strict.matching=false
sql.mock.log.unmatched=true
```

### 4.2 Add Configuration Constants

In `Config.java` or equivalent:

```java
public static final String SQL_MOCK_ENABLED = "sql.mock.enabled";
public static final String SQL_MOCK_DEFAULT_SQLCODE = "sql.mock.default.sqlcode";
public static final String SQL_MOCK_MAX_ROWS = "sql.mock.max.rows.per.mock";
public static final String SQL_MOCK_STRICT_MATCHING = "sql.mock.strict.matching";
public static final String SQL_MOCK_LOG_UNMATCHED = "sql.mock.log.unmatched";
```

## 5. Test Case Reset

### 5.1 Reset Between Test Cases

In the code that handles `TESTCASE` boundaries:

```java
private void startNewTestCase() {
    // Existing reset logic...
    
    // NEW: Reset SQL mock state
    sqlMockRepository.resetInvocationCounts();
    sqlMockRepository.resetCursorStates();
}
```

### 5.2 Reset Between Test Suites

In the code that handles `TESTSUITE` boundaries:

```java
private void startNewTestSuite() {
    // Existing reset logic...
    
    // NEW: Clear all SQL mocks
    sqlMockRepository.clearAll();
}
```

## 6. Error Handling

### 6.1 Add SQL Mock Exceptions

Create `SQLMockException.java`:

```java
package org.openmainframeproject.cobolcheck.features.sql;

public class SQLMockException extends RuntimeException {
    public SQLMockException(String message) {
        super(message);
    }
    
    public SQLMockException(String message, Throwable cause) {
        super(message, cause);
    }
}
```

### 6.2 Handle Unmocked SQL

Add warning/error for unmocked SQL statements:

```java
if (mock == null && config.getBoolean(SQL_MOCK_LOG_UNMATCHED)) {
    log.warn("Unmocked SQL statement encountered: " + 
             truncate(fullSQL, 80));
}
```

## 7. Messages

### 7.1 Add to Messages.properties

```properties
# SQL Mock Messages
sql.mock.parse.error=Error parsing SQL mock at {0}: {1}
sql.mock.no.match=No mock found for SQL statement: {0}
sql.mock.verify.pass=PASS: Verified SQL mock {0} was invoked {1} time(s)
sql.mock.verify.fail=FAIL: SQL mock {0} expected {1} {2}, actual {3}
sql.mock.unmocked.warning=WARNING: Unmocked SQL statement: {0}
sql.mock.cursor.not.open=Cursor {0} is not open
sql.mock.row.overflow=Row index {0} exceeds maximum {1} for mock {2}
```

## 8. Build Configuration

### 8.1 Maven (pom.xml)

No additional dependencies required - uses standard Java features.

### 8.2 Gradle (build.gradle)

No additional dependencies required.

## 9. Testing the Integration

### 9.1 Unit Tests

Run the provided unit tests:

```bash
mvn test -Dtest=SQLStatementTypeTest,SQLMockDefinitionTest
```

### 9.2 Integration Test

Create an integration test using the provided example:

```bash
# Copy examples to test resources
cp examples/CUSTMGMT.CBL src/test/resources/
cp examples/CUSTMGMT.cut src/test/resources/

# Run cobol-check
./cobol-check -p CUSTMGMT
```

## 10. Verification Checklist

- [ ] All Java files compile without errors
- [ ] Unit tests pass
- [ ] Test suite parser recognizes `MOCK EXEC SQL` blocks
- [ ] Test suite parser recognizes `VERIFY EXEC SQL` blocks
- [ ] Generator produces valid COBOL WORKING-STORAGE
- [ ] Generator produces valid mock handler paragraphs
- [ ] EXEC SQL statements are replaced with PERFORM mock handlers
- [ ] Verification code is generated correctly
- [ ] Mock state resets between test cases
- [ ] Configuration options work correctly
- [ ] Error messages are helpful

## 11. Known Limitations

1. **Host Variable Matching**: The current implementation uses simplified pattern matching for host variables. Complex expressions in host variable positions may not match correctly.

2. **INTO Clause Mapping**: The generator includes TODO comments for mapping mock data to INTO clause fields. This requires parsing the original SQL's INTO clause to determine target fields.

3. **Indicator Variables**: Null indicator variables (e.g., `:VAR:IND`) are not fully supported.

4. **Dynamic SQL**: PREPARE/EXECUTE for dynamic SQL is recognized but not fully implemented.

5. **Array Host Variables**: Arrays as host variables are not supported.

## 12. Future Enhancements

1. Parse INTO clause to automatically map mock data to target fields
2. Support indicator variables
3. Add conditional mocks (different responses based on input values)
4. Support array host variables
5. Add SQLCA field support beyond SQLCODE
6. Generate HTML report of mock coverage
