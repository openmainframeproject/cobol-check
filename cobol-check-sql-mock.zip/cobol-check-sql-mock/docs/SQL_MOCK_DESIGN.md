# SQL Mock Framework for COBOL Check

## Executive Summary

This document describes the design and implementation of SQL mocking capabilities for the COBOL Check testing framework. The SQL mock feature enables developers to unit test COBOL programs that contain embedded SQL (EXEC SQL) statements without requiring a live database connection.

## 1. Overview

### 1.1 Problem Statement

Enterprise COBOL programs typically interact with DB2 or other relational databases through embedded SQL statements. Testing these programs traditionally requires:
- A live database connection
- Test data setup and teardown
- Complex environment configuration

This creates barriers to effective unit testing and slows down the development feedback loop.

### 1.2 Solution

The SQL Mock Framework intercepts EXEC SQL statements during test execution and:
- Returns predefined result sets for SELECT statements
- Simulates INSERT, UPDATE, DELETE operations
- Provides configurable SQLCODE responses
- Supports cursor operations (OPEN, FETCH, CLOSE)
- Enables verification of SQL statement execution

## 2. Syntax Design

### 2.1 Basic SQL Mock Syntax

```cobol
MOCK EXEC SQL <sql-statement-pattern>
    [RETURNS SQLCODE(<value>)]
    [WITH DATA
        <field-assignments>
    END-DATA]
END-MOCK
```

### 2.2 Syntax Examples

#### 2.2.1 Mock a SELECT Statement

```cobol
MOCK EXEC SQL SELECT * FROM CUSTOMERS
              WHERE CUST-ID = :WS-CUST-ID
    RETURNS SQLCODE(0)
    WITH DATA
        CUST-NAME = "ACME CORPORATION"
        CUST-ADDR = "123 MAIN STREET"
        CUST-BALANCE = 15000.50
    END-DATA
END-MOCK
```

#### 2.2.2 Mock a SELECT with Multiple Rows (Cursor)

```cobol
MOCK EXEC SQL FETCH CUSTOMER-CURSOR
    RETURNS SQLCODE(0)
    WITH DATA
        ROW 1
            CUST-ID = "C001"
            CUST-NAME = "ACME CORP"
        END-ROW
        ROW 2
            CUST-ID = "C002"
            CUST-NAME = "BETA INC"
        END-ROW
        ROW 3
            SQLCODE = 100
        END-ROW
    END-DATA
END-MOCK
```

#### 2.2.3 Mock an INSERT Statement

```cobol
MOCK EXEC SQL INSERT INTO CUSTOMERS
    RETURNS SQLCODE(0)
END-MOCK
```

#### 2.2.4 Mock with Error Condition

```cobol
MOCK EXEC SQL UPDATE CUSTOMERS
              SET BALANCE = :WS-NEW-BALANCE
              WHERE CUST-ID = :WS-CUST-ID
    RETURNS SQLCODE(-803)
    RETURNS SQLERRMC("DUPLICATE KEY")
END-MOCK
```

#### 2.2.5 Mock CURSOR Operations

```cobol
MOCK EXEC SQL OPEN CUSTOMER-CURSOR
    RETURNS SQLCODE(0)
END-MOCK

MOCK EXEC SQL CLOSE CUSTOMER-CURSOR
    RETURNS SQLCODE(0)
END-MOCK
```

### 2.3 Verification Syntax

```cobol
VERIFY EXEC SQL INSERT INTO CUSTOMERS HAPPENED ONCE

VERIFY EXEC SQL UPDATE CUSTOMERS HAPPENED 3 TIMES

VERIFY EXEC SQL DELETE FROM CUSTOMERS NEVER HAPPENED
```

## 3. Architecture

### 3.1 Component Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                      Test Suite Parser                          │
│  (Existing cobol-check component - TestSuiteParser.java)        │
└──────────────────────────┬──────────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────────┐
│                    SQLMockParser                                │
│  - Parses MOCK EXEC SQL blocks                                  │
│  - Extracts SQL patterns, return values, data                   │
│  - Creates SQLMockDefinition objects                            │
└──────────────────────────┬──────────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────────┐
│                  SQLMockRepository                              │
│  - Stores all SQL mock definitions                              │
│  - Matches SQL statements to mocks                              │
│  - Tracks invocation counts                                     │
└──────────────────────────┬──────────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────────┐
│                  SQLMockCodeGenerator                           │
│  - Generates COBOL replacement code                             │
│  - Creates WORKING-STORAGE entries for mock data                │
│  - Inserts mock paragraphs into merged source                   │
└──────────────────────────┬──────────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────────┐
│                  Merged COBOL Program                           │
│  - Original program with SQL replaced by mock calls             │
│  - Mock data structures in WORKING-STORAGE                      │
│  - Mock handler paragraphs                                      │
└─────────────────────────────────────────────────────────────────┘
```

### 3.2 Class Diagram

```
┌──────────────────────────────┐
│      SQLMockDefinition       │
├──────────────────────────────┤
│ - sqlPattern: String         │
│ - sqlType: SQLStatementType  │
│ - sqlcode: int               │
│ - sqlerrmc: String           │
│ - mockDataRows: List<Map>    │
│ - invocationCount: int       │
├──────────────────────────────┤
│ + matches(sql): boolean      │
│ + getNextRow(): Map          │
│ + incrementCount(): void     │
└──────────────────────────────┘
           △
           │
           │ uses
           │
┌──────────────────────────────┐     ┌──────────────────────────────┐
│       SQLMockParser          │────▶│      SQLMockRepository       │
├──────────────────────────────┤     ├──────────────────────────────┤
│ - keywords: List<String>     │     │ - mocks: List<SQLMockDef>    │
├──────────────────────────────┤     │ - cursorStates: Map          │
│ + parse(tokens): SQLMockDef  │     ├──────────────────────────────┤
│ + isSQL(token): boolean      │     │ + addMock(def): void         │
│ + extractPattern(): String   │     │ + findMock(sql): SQLMockDef  │
└──────────────────────────────┘     │ + verify(pattern, count)     │
                                     └──────────────────────────────┘
                                                  │
                                                  │ uses
                                                  ▼
                                     ┌──────────────────────────────┐
                                     │   SQLMockCodeGenerator       │
                                     ├──────────────────────────────┤
                                     │ - mockPrefix: String         │
                                     │ - wsCounter: int             │
                                     ├──────────────────────────────┤
                                     │ + generateWSEntries(): List  │
                                     │ + generateMockParagraph()    │
                                     │ + replaceExecSQL(): String   │
                                     └──────────────────────────────┘
```

### 3.3 Enum: SQLStatementType

```java
public enum SQLStatementType {
    SELECT,
    INSERT,
    UPDATE,
    DELETE,
    OPEN_CURSOR,
    FETCH_CURSOR,
    CLOSE_CURSOR,
    COMMIT,
    ROLLBACK,
    CALL,
    UNKNOWN
}
```

## 4. Implementation Details

### 4.1 SQL Pattern Matching

The SQL mock framework uses a flexible pattern matching approach:

1. **Exact Match**: The SQL in the mock exactly matches the SQL in the program
2. **Keyword Match**: Match based on SQL keywords (SELECT, INSERT, table names)
3. **Wildcard Match**: Support for `*` wildcards in patterns

Pattern matching algorithm:
```
1. Normalize both mock pattern and actual SQL (remove extra spaces, uppercase)
2. Extract SQL type (SELECT, INSERT, etc.)
3. Extract table/cursor name
4. If wildcard present, match prefix and suffix
5. If host variables present, ignore variable names in comparison
```

### 4.2 Generated COBOL Code Structure

For each mocked SQL statement, the generator produces:

#### 4.2.1 WORKING-STORAGE Additions

```cobol
      * SQL MOCK WORKING STORAGE - GENERATED BY COBOL-CHECK
       01  CCHK-SQL-MOCK-AREA.
           05  CCHK-SQL-MOCK-COUNT-001     PIC 9(4) VALUE 0.
           05  CCHK-SQL-MOCK-SQLCODE-001   PIC S9(9) COMP VALUE 0.
           05  CCHK-SQL-MOCK-ROW-IDX-001   PIC 9(4) VALUE 1.
           05  CCHK-SQL-MOCK-MAX-ROWS-001  PIC 9(4) VALUE 2.
       
       01  CCHK-SQL-MOCK-DATA-001.
           05  CCHK-SQL-ROW-001 OCCURS 10.
               10  CCHK-CUST-NAME          PIC X(30).
               10  CCHK-CUST-ADDR          PIC X(50).
               10  CCHK-CUST-BALANCE       PIC S9(9)V99.
               10  CCHK-ROW-SQLCODE        PIC S9(9) COMP.
```

#### 4.2.2 Mock Handler Paragraph

```cobol
       CCHK-SQL-MOCK-HANDLER-001.
           ADD 1 TO CCHK-SQL-MOCK-COUNT-001
           IF CCHK-SQL-MOCK-ROW-IDX-001 > CCHK-SQL-MOCK-MAX-ROWS-001
               MOVE 100 TO SQLCODE
           ELSE
               MOVE CCHK-ROW-SQLCODE(CCHK-SQL-MOCK-ROW-IDX-001)
                   TO SQLCODE
               IF SQLCODE = 0
                   MOVE CCHK-CUST-NAME(CCHK-SQL-MOCK-ROW-IDX-001)
                       TO CUST-NAME
                   MOVE CCHK-CUST-ADDR(CCHK-SQL-MOCK-ROW-IDX-001)
                       TO CUST-ADDR
                   MOVE CCHK-CUST-BALANCE(CCHK-SQL-MOCK-ROW-IDX-001)
                       TO CUST-BALANCE
               END-IF
               ADD 1 TO CCHK-SQL-MOCK-ROW-IDX-001
           END-IF.
```

#### 4.2.3 SQL Replacement

Original:
```cobol
           EXEC SQL
               SELECT CUST-NAME, CUST-ADDR, CUST-BALANCE
               INTO :CUST-NAME, :CUST-ADDR, :CUST-BALANCE
               FROM CUSTOMERS
               WHERE CUST-ID = :WS-CUST-ID
           END-EXEC.
```

Replaced with:
```cobol
           PERFORM CCHK-SQL-MOCK-HANDLER-001.
```

### 4.3 Cursor State Management

Cursors require special handling to maintain state across OPEN/FETCH/CLOSE:

```java
public class CursorState {
    private String cursorName;
    private boolean isOpen;
    private int currentRow;
    private int totalRows;
    
    public void open() { isOpen = true; currentRow = 0; }
    public void close() { isOpen = false; }
    public boolean hasMoreRows() { return currentRow < totalRows; }
    public void advance() { currentRow++; }
}
```

## 5. Integration Points

### 5.1 TestSuiteParser Integration

Add to keyword recognition:
```java
private static final List<String> SQL_MOCK_KEYWORDS = Arrays.asList(
    "MOCK", "EXEC", "SQL", "RETURNS", "SQLCODE", "SQLERRMC",
    "WITH", "DATA", "END-DATA", "ROW", "END-ROW", "END-MOCK",
    "VERIFY", "HAPPENED", "TIMES", "ONCE", "NEVER"
);
```

### 5.2 Generator Integration

In the main Generator class:
```java
// After parsing test suite
SQLMockRepository sqlMocks = testSuiteParser.getSQLMocks();

// During PROCEDURE DIVISION processing
if (isExecSQL(currentLine)) {
    String replacement = sqlMockCodeGenerator.replaceExecSQL(
        currentLine, sqlMocks);
    writer.writeLine(replacement);
}

// Before writing WORKING-STORAGE
List<String> mockWSEntries = sqlMockCodeGenerator.generateWSEntries(sqlMocks);
for (String entry : mockWSEntries) {
    writer.writeLine(entry);
}
```

## 6. Configuration

### 6.1 config.properties Additions

```properties
# SQL Mock Configuration
sql.mock.enabled=true
sql.mock.default.sqlcode=0
sql.mock.max.rows.per.mock=100
sql.mock.strict.matching=false
sql.mock.log.unmatched=true
```

## 7. Error Handling

### 7.1 Parsing Errors

- Missing END-MOCK
- Invalid SQLCODE value
- Malformed WITH DATA block
- Unknown SQL statement type

### 7.2 Runtime Errors (in generated COBOL)

- Unmocked SQL statement encountered
- Cursor not opened before FETCH
- Row index out of bounds

## 8. Testing Strategy

### 8.1 Unit Tests

- SQLMockParser parsing various SQL patterns
- SQLMockRepository matching algorithms
- SQLMockCodeGenerator output validation

### 8.2 Integration Tests

- End-to-end test with sample COBOL program
- Cursor operation sequences
- Error condition handling

## 9. Future Enhancements

1. **Dynamic Data**: Support for expressions in mock data
2. **Conditional Mocks**: Different responses based on input values
3. **SQL Validation**: Syntax checking of mock patterns
4. **Bulk Operations**: Support for multi-row INSERT
5. **Stored Procedures**: CALL statement mocking
6. **SQLCA Fields**: Full SQLCA structure support

## 10. Appendix: SQLCA Structure Reference

```cobol
       01  SQLCA.
           05  SQLCAID        PIC X(8) VALUE "SQLCA   ".
           05  SQLCABC        PIC S9(9) COMP-5 VALUE 136.
           05  SQLCODE        PIC S9(9) COMP-5 VALUE 0.
           05  SQLERRM.
               49  SQLERRML   PIC S9(4) COMP-5 VALUE 0.
               49  SQLERRMC   PIC X(70) VALUE SPACES.
           05  SQLERRP        PIC X(8) VALUE SPACES.
           05  SQLERRD OCCURS 6 PIC S9(9) COMP-5.
           05  SQLWARN.
               10  SQLWARN0   PIC X VALUE SPACE.
               10  SQLWARN1   PIC X VALUE SPACE.
               10  SQLWARN2   PIC X VALUE SPACE.
               10  SQLWARN3   PIC X VALUE SPACE.
               10  SQLWARN4   PIC X VALUE SPACE.
               10  SQLWARN5   PIC X VALUE SPACE.
               10  SQLWARN6   PIC X VALUE SPACE.
               10  SQLWARN7   PIC X VALUE SPACE.
           05  SQLEXT.
               10  SQLWARN8   PIC X VALUE SPACE.
               10  SQLWARN9   PIC X VALUE SPACE.
               10  SQLWARNA   PIC X VALUE SPACE.
               10  SQLSTATE   PIC X(5) VALUE SPACES.
```
