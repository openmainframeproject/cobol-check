# SQL Mock Framework for COBOL Check

[![License](https://img.shields.io/badge/license-Apache%202.0-blue.svg)](LICENSE)

This extension adds SQL mocking capabilities to [COBOL Check](https://github.com/openmainframeproject/cobol-check), enabling developers to unit test COBOL programs with embedded SQL without requiring a live database connection.

## Features

- **Mock SQL Statements**: SELECT, INSERT, UPDATE, DELETE
- **Cursor Support**: OPEN, FETCH, CLOSE cursor operations  
- **Multi-row Result Sets**: Define multiple rows for cursor fetches
- **Error Simulation**: Return specific SQLCODE, SQLERRMC, SQLSTATE values
- **Verification**: Assert that SQL statements were executed expected number of times
- **Transaction Control**: Mock COMMIT and ROLLBACK

## Quick Start

### Example Test Suite

```cobol
TESTSUITE "Customer Operations"

TESTCASE "Should find customer by ID"

* Mock the SELECT statement
MOCK EXEC SQL SELECT CUST_ID, CUST_NAME, CUST_BALANCE
             INTO :WS-CUST-ID, :WS-CUST-NAME, :WS-CUST-BALANCE
             FROM CUSTOMERS
             WHERE CUST_ID = :WS-SEARCH-ID
    RETURNS SQLCODE(0)
    WITH DATA
        WS-CUST-ID = "C00001"
        WS-CUST-NAME = "ACME CORPORATION"
        WS-CUST-BALANCE = 15000.50
    END-DATA
END-MOCK

* Set up and execute
MOVE "C00001" TO WS-SEARCH-ID
PERFORM 2100-GET-CUSTOMER

* Verify
EXPECT WS-CUST-NAME TO BE "ACME CORPORATION"
VERIFY EXEC SQL SELECT FROM CUSTOMERS HAPPENED ONCE
```

## Syntax Reference

### Basic Mock

```cobol
MOCK EXEC SQL <sql-statement>
    RETURNS SQLCODE(<value>)
    [RETURNS SQLERRMC("<message>")]
    [RETURNS SQLSTATE("<state>")]
    [WITH DATA
        <field> = <value>
        ...
    END-DATA]
END-MOCK
```

### Multi-row Mock (for cursors)

```cobol
MOCK EXEC SQL FETCH CUSTOMER-CURSOR
    WITH DATA
        ROW 1
            CUST-ID = "C001"
            CUST-NAME = "ACME"
        END-ROW
        ROW 2
            CUST-ID = "C002"
            CUST-NAME = "BETA"
        END-ROW
        ROW 3
            SQLCODE = 100
        END-ROW
    END-DATA
END-MOCK
```

### Verification

```cobol
VERIFY EXEC SQL <pattern> HAPPENED <count> TIMES
VERIFY EXEC SQL <pattern> HAPPENED ONCE
VERIFY EXEC SQL <pattern> NEVER HAPPENED
VERIFY EXEC SQL <pattern> HAPPENED AT LEAST 2 TIMES
```

## Project Structure

```
cobol-check-sql-mock/
├── docs/
│   ├── SQL_MOCK_DESIGN.md      # Architecture documentation
│   └── INTEGRATION_GUIDE.md    # How to add to cobol-check
├── examples/
│   ├── CUSTMGMT.CBL            # Sample COBOL program
│   └── CUSTMGMT.cut            # Sample test suite
└── src/
    ├── main/java/.../sql/
    │   ├── SQLStatementType.java
    │   ├── SQLMockDataRow.java
    │   ├── SQLMockDefinition.java
    │   ├── SQLMockRepository.java
    │   ├── SQLMockParser.java
    │   └── SQLMockCodeGenerator.java
    └── test/java/.../sql/
        ├── SQLStatementTypeTest.java
        └── SQLMockDefinitionTest.java
```

## Supported SQL Statements

| Statement Type | Mock | Verify | Data Return |
|---------------|------|--------|-------------|
| SELECT        | ✅   | ✅     | ✅          |
| INSERT        | ✅   | ✅     | ❌          |
| UPDATE        | ✅   | ✅     | ❌          |
| DELETE        | ✅   | ✅     | ❌          |
| OPEN CURSOR   | ✅   | ✅     | ❌          |
| FETCH         | ✅   | ✅     | ✅          |
| CLOSE CURSOR  | ✅   | ✅     | ❌          |
| COMMIT        | ✅   | ✅     | ❌          |
| ROLLBACK      | ✅   | ✅     | ❌          |

## Common SQLCODE Values

| SQLCODE | Meaning |
|---------|---------|
| 0       | Successful execution |
| 100     | No data found / End of cursor |
| -803    | Duplicate key on unique index |
| -811    | Multiple rows returned |
| -911    | Deadlock or timeout |
| -922    | Authorization failure |

## Installation

See [INTEGRATION_GUIDE.md](docs/INTEGRATION_GUIDE.md) for detailed instructions on integrating this extension into COBOL Check.

## Requirements

- Java 11 or higher
- COBOL Check 0.2.x or higher

## Contributing

Contributions are welcome! Please see the [COBOL Check contribution guidelines](https://github.com/openmainframeproject/cobol-check/blob/main/CONTRIBUTING.md).

## License

This project is licensed under the Apache License 2.0 - see the [LICENSE](LICENSE) file for details.

## Acknowledgments

- [Open Mainframe Project](https://www.openmainframeproject.org/)
- [COBOL Check Team](https://github.com/openmainframeproject/cobol-check)
- [Bankdata](https://www.bankdata.dk/) for contributions to COBOL testing
