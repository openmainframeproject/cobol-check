package org.openmainframeproject.cobolcheck.features.sql;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for SQLStatementType enum.
 */
class SQLStatementTypeTest {

    @ParameterizedTest
    @DisplayName("Should correctly identify SELECT statements")
    @ValueSource(strings = {
        "SELECT * FROM CUSTOMERS",
        "SELECT CUST_ID, CUST_NAME FROM CUSTOMERS WHERE ID = :WS-ID",
        "SELECT\n  FIELD1,\n  FIELD2\nFROM TABLE1",
        "select * from customers"
    })
    void shouldIdentifySelectStatements(String sql) {
        assertEquals(SQLStatementType.SELECT, SQLStatementType.fromSQL(sql));
    }

    @ParameterizedTest
    @DisplayName("Should correctly identify INSERT statements")
    @ValueSource(strings = {
        "INSERT INTO CUSTOMERS VALUES (:ID, :NAME)",
        "INSERT INTO CUSTOMERS (CUST_ID, CUST_NAME) VALUES (:ID, :NAME)",
        "insert into customers values (1, 'test')"
    })
    void shouldIdentifyInsertStatements(String sql) {
        assertEquals(SQLStatementType.INSERT, SQLStatementType.fromSQL(sql));
    }

    @ParameterizedTest
    @DisplayName("Should correctly identify UPDATE statements")
    @ValueSource(strings = {
        "UPDATE CUSTOMERS SET NAME = :NAME WHERE ID = :ID",
        "UPDATE CUSTOMERS SET BALANCE = BALANCE + 100",
        "update customers set status = 'A'"
    })
    void shouldIdentifyUpdateStatements(String sql) {
        assertEquals(SQLStatementType.UPDATE, SQLStatementType.fromSQL(sql));
    }

    @ParameterizedTest
    @DisplayName("Should correctly identify DELETE statements")
    @ValueSource(strings = {
        "DELETE FROM CUSTOMERS WHERE ID = :ID",
        "DELETE FROM CUSTOMERS",
        "DELETE CUSTOMERS WHERE STATUS = 'I'"
    })
    void shouldIdentifyDeleteStatements(String sql) {
        assertEquals(SQLStatementType.DELETE, SQLStatementType.fromSQL(sql));
    }

    @ParameterizedTest
    @DisplayName("Should correctly identify OPEN CURSOR statements")
    @ValueSource(strings = {
        "OPEN CUSTOMER-CURSOR",
        "OPEN MY_CURSOR",
        "open customer_cursor"
    })
    void shouldIdentifyOpenCursor(String sql) {
        assertEquals(SQLStatementType.OPEN_CURSOR, SQLStatementType.fromSQL(sql));
    }

    @ParameterizedTest
    @DisplayName("Should correctly identify FETCH statements")
    @ValueSource(strings = {
        "FETCH CUSTOMER-CURSOR INTO :WS-ID, :WS-NAME",
        "FETCH MY_CURSOR",
        "fetch cursor1 into :var1"
    })
    void shouldIdentifyFetchCursor(String sql) {
        assertEquals(SQLStatementType.FETCH_CURSOR, SQLStatementType.fromSQL(sql));
    }

    @ParameterizedTest
    @DisplayName("Should correctly identify CLOSE CURSOR statements")
    @ValueSource(strings = {
        "CLOSE CUSTOMER-CURSOR",
        "CLOSE MY_CURSOR",
        "close cursor1"
    })
    void shouldIdentifyCloseCursor(String sql) {
        assertEquals(SQLStatementType.CLOSE_CURSOR, SQLStatementType.fromSQL(sql));
    }

    @ParameterizedTest
    @DisplayName("Should correctly identify DECLARE CURSOR statements")
    @ValueSource(strings = {
        "DECLARE CUSTOMER-CURSOR CURSOR FOR SELECT * FROM CUSTOMERS",
        "DECLARE MY_CURSOR CURSOR WITH HOLD FOR SELECT ID FROM TABLE1"
    })
    void shouldIdentifyDeclareCursor(String sql) {
        assertEquals(SQLStatementType.DECLARE_CURSOR, SQLStatementType.fromSQL(sql));
    }

    @Test
    @DisplayName("Should identify COMMIT statement")
    void shouldIdentifyCommit() {
        assertEquals(SQLStatementType.COMMIT, SQLStatementType.fromSQL("COMMIT"));
        assertEquals(SQLStatementType.COMMIT, SQLStatementType.fromSQL("commit"));
    }

    @Test
    @DisplayName("Should identify ROLLBACK statement")
    void shouldIdentifyRollback() {
        assertEquals(SQLStatementType.ROLLBACK, SQLStatementType.fromSQL("ROLLBACK"));
        assertEquals(SQLStatementType.ROLLBACK, SQLStatementType.fromSQL("rollback"));
    }

    @Test
    @DisplayName("Should identify CALL statement")
    void shouldIdentifyCall() {
        assertEquals(SQLStatementType.CALL, SQLStatementType.fromSQL("CALL MYPROC(:PARAM1)"));
        assertEquals(SQLStatementType.CALL, SQLStatementType.fromSQL("call sp_update_balance"));
    }

    @Test
    @DisplayName("Should return UNKNOWN for null or empty input")
    void shouldReturnUnknownForInvalidInput() {
        assertEquals(SQLStatementType.UNKNOWN, SQLStatementType.fromSQL(null));
        assertEquals(SQLStatementType.UNKNOWN, SQLStatementType.fromSQL(""));
        assertEquals(SQLStatementType.UNKNOWN, SQLStatementType.fromSQL("   "));
    }

    @Test
    @DisplayName("Should return UNKNOWN for unrecognized SQL")
    void shouldReturnUnknownForUnrecognizedSql() {
        assertEquals(SQLStatementType.UNKNOWN, SQLStatementType.fromSQL("CREATE TABLE TEST"));
        assertEquals(SQLStatementType.UNKNOWN, SQLStatementType.fromSQL("ALTER TABLE CUSTOMERS"));
        assertEquals(SQLStatementType.UNKNOWN, SQLStatementType.fromSQL("GRANT SELECT ON TABLE"));
    }

    @ParameterizedTest
    @DisplayName("returnsData should return true for data-returning types")
    @CsvSource({
        "SELECT, true",
        "FETCH_CURSOR, true",
        "CALL, true",
        "INSERT, false",
        "UPDATE, false",
        "DELETE, false",
        "OPEN_CURSOR, false",
        "CLOSE_CURSOR, false",
        "COMMIT, false"
    })
    void shouldCorrectlyIdentifyDataReturningTypes(SQLStatementType type, boolean expected) {
        assertEquals(expected, type.returnsData());
    }

    @ParameterizedTest
    @DisplayName("modifiesData should return true for data-modifying types")
    @CsvSource({
        "SELECT, false",
        "INSERT, true",
        "UPDATE, true",
        "DELETE, true",
        "COMMIT, false"
    })
    void shouldCorrectlyIdentifyDataModifyingTypes(SQLStatementType type, boolean expected) {
        assertEquals(expected, type.modifiesData());
    }

    @ParameterizedTest
    @DisplayName("isCursorOperation should return true for cursor types")
    @CsvSource({
        "SELECT, false",
        "OPEN_CURSOR, true",
        "FETCH_CURSOR, true",
        "CLOSE_CURSOR, true",
        "DECLARE_CURSOR, true",
        "INSERT, false"
    })
    void shouldCorrectlyIdentifyCursorOperations(SQLStatementType type, boolean expected) {
        assertEquals(expected, type.isCursorOperation());
    }

    @ParameterizedTest
    @DisplayName("isTransactionControl should return true for transaction types")
    @CsvSource({
        "COMMIT, true",
        "ROLLBACK, true",
        "SELECT, false",
        "INSERT, false"
    })
    void shouldCorrectlyIdentifyTransactionControl(SQLStatementType type, boolean expected) {
        assertEquals(expected, type.isTransactionControl());
    }

    @Test
    @DisplayName("getKeyword should return the correct keyword")
    void shouldReturnCorrectKeyword() {
        assertEquals("SELECT", SQLStatementType.SELECT.getKeyword());
        assertEquals("INSERT", SQLStatementType.INSERT.getKeyword());
        assertEquals("UPDATE", SQLStatementType.UPDATE.getKeyword());
        assertEquals("DELETE", SQLStatementType.DELETE.getKeyword());
        assertEquals("OPEN", SQLStatementType.OPEN_CURSOR.getKeyword());
        assertEquals("FETCH", SQLStatementType.FETCH_CURSOR.getKeyword());
        assertEquals("CLOSE", SQLStatementType.CLOSE_CURSOR.getKeyword());
    }
}
