package org.openmainframeproject.cobolcheck.features.sql;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for SQLMockDefinition class.
 */
class SQLMockDefinitionTest {

    private SQLMockDefinition mock;

    @BeforeEach
    void setUp() {
        mock = new SQLMockDefinition("SQL-MOCK-001", 
            "SELECT * FROM CUSTOMERS WHERE CUST_ID = :WS-ID");
    }

    @Test
    @DisplayName("Constructor should initialize with correct values")
    void constructorShouldInitialize() {
        assertEquals("SQL-MOCK-001", mock.getId());
        assertEquals(SQLStatementType.SELECT, mock.getStatementType());
        assertEquals(0, mock.getSqlcode());
        assertEquals("", mock.getSqlerrmc());
        assertEquals("00000", mock.getSqlstate());
        assertEquals(0, mock.getInvocationCount());
        assertEquals(0, mock.getRowCount());
    }

    @Test
    @DisplayName("Constructor should throw for null ID")
    void constructorShouldThrowForNullId() {
        assertThrows(IllegalArgumentException.class, 
            () -> new SQLMockDefinition(null, "SELECT * FROM TEST"));
    }

    @Test
    @DisplayName("Constructor should throw for null SQL pattern")
    void constructorShouldThrowForNullSql() {
        assertThrows(IllegalArgumentException.class, 
            () -> new SQLMockDefinition("SQL-MOCK-001", null));
    }

    @Test
    @DisplayName("Should normalize SQL pattern")
    void shouldNormalizeSqlPattern() {
        SQLMockDefinition m = new SQLMockDefinition("SQL-MOCK-001",
            "  select  *  from   customers  ");
        // Pattern should be normalized (uppercase, single spaces)
        assertTrue(m.getSqlPattern().contains("SELECT"));
        assertTrue(m.getSqlPattern().contains("FROM"));
        assertTrue(m.getSqlPattern().contains("CUSTOMERS"));
    }

    @Test
    @DisplayName("Should strip EXEC SQL wrapper")
    void shouldStripExecSqlWrapper() {
        SQLMockDefinition m = new SQLMockDefinition("SQL-MOCK-001",
            "EXEC SQL SELECT * FROM TEST END-EXEC");
        assertEquals("SELECT * FROM TEST", m.getSqlPattern());
    }

    @Test
    @DisplayName("Should set and get SQLCODE")
    void shouldSetAndGetSqlcode() {
        mock.setSqlcode(-803);
        assertEquals(-803, mock.getSqlcode());
        
        mock.setSqlcode(100);
        assertEquals(100, mock.getSqlcode());
    }

    @Test
    @DisplayName("Should set and get SQLERRMC")
    void shouldSetAndGetSqlerrmc() {
        mock.setSqlerrmc("DUPLICATE KEY ERROR");
        assertEquals("DUPLICATE KEY ERROR", mock.getSqlerrmc());
        
        mock.setSqlerrmc(null);
        assertEquals("", mock.getSqlerrmc());
    }

    @Test
    @DisplayName("Should set and get SQLSTATE")
    void shouldSetAndGetSqlstate() {
        mock.setSqlstate("23505");
        assertEquals("23505", mock.getSqlstate());
        
        // Should not accept invalid length
        mock.setSqlstate("123");
        assertEquals("23505", mock.getSqlstate()); // Unchanged
    }

    @Test
    @DisplayName("Should add and retrieve data rows")
    void shouldAddAndRetrieveDataRows() {
        SQLMockDataRow row1 = new SQLMockDataRow();
        row1.setFieldValue("CUST-ID", "C001");
        row1.setFieldValue("CUST-NAME", "ACME");
        
        SQLMockDataRow row2 = new SQLMockDataRow();
        row2.setFieldValue("CUST-ID", "C002");
        row2.setFieldValue("CUST-NAME", "BETA");
        
        mock.addDataRow(row1);
        mock.addDataRow(row2);
        
        assertEquals(2, mock.getRowCount());
        assertEquals(row1, mock.getDataRow(0));
        assertEquals(row2, mock.getDataRow(1));
        assertNull(mock.getDataRow(5)); // Out of bounds
    }

    @Test
    @DisplayName("Should ignore null data row")
    void shouldIgnoreNullDataRow() {
        mock.addDataRow(null);
        assertEquals(0, mock.getRowCount());
    }

    @Test
    @DisplayName("Should track invocation count")
    void shouldTrackInvocationCount() {
        assertEquals(0, mock.getInvocationCount());
        
        mock.recordInvocation();
        assertEquals(1, mock.getInvocationCount());
        
        mock.recordInvocation();
        mock.recordInvocation();
        assertEquals(3, mock.getInvocationCount());
        
        mock.resetInvocationCount();
        assertEquals(0, mock.getInvocationCount());
    }

    @Test
    @DisplayName("Should match exact SQL")
    void shouldMatchExactSql() {
        assertTrue(mock.matches("SELECT * FROM CUSTOMERS WHERE CUST_ID = :WS-ID"));
        assertTrue(mock.matches("select * from customers where cust_id = :ws-id"));
        assertTrue(mock.matches("  SELECT  *  FROM  CUSTOMERS  WHERE  CUST_ID = :WS-ID  "));
    }

    @Test
    @DisplayName("Should match SQL with different host variables")
    void shouldMatchSqlWithDifferentHostVariables() {
        // Pattern uses :WS-ID, actual uses :WS-CUST-ID - should still match
        assertTrue(mock.matches(
            "SELECT * FROM CUSTOMERS WHERE CUST_ID = :WS-CUST-ID"));
    }

    @Test
    @DisplayName("Should not match different SQL")
    void shouldNotMatchDifferentSql() {
        assertFalse(mock.matches("SELECT * FROM ORDERS WHERE ORDER_ID = :ID"));
        assertFalse(mock.matches("INSERT INTO CUSTOMERS VALUES (:ID)"));
        assertFalse(mock.matches("UPDATE CUSTOMERS SET NAME = :NAME"));
    }

    @Test
    @DisplayName("Should not match null or empty SQL")
    void shouldNotMatchNullOrEmpty() {
        assertFalse(mock.matches(null));
        assertFalse(mock.matches(""));
        assertFalse(mock.matches("   "));
    }

    @Test
    @DisplayName("Should extract cursor name for cursor operations")
    void shouldExtractCursorName() {
        SQLMockDefinition openMock = new SQLMockDefinition("SQL-MOCK-002",
            "OPEN CUSTOMER-CURSOR");
        assertEquals(SQLStatementType.OPEN_CURSOR, openMock.getStatementType());
        assertEquals("CUSTOMER-CURSOR", openMock.getCursorName());
        
        SQLMockDefinition fetchMock = new SQLMockDefinition("SQL-MOCK-003",
            "FETCH MY_CURSOR INTO :VAR1, :VAR2");
        assertEquals(SQLStatementType.FETCH_CURSOR, fetchMock.getStatementType());
        assertEquals("MY_CURSOR", fetchMock.getCursorName());
    }

    @Test
    @DisplayName("Should track source location")
    void shouldTrackSourceLocation() {
        mock.setSourceFile("TEST.cut");
        mock.setSourceLine(42);
        
        assertEquals("TEST.cut:42", mock.getSourceLocation());
    }

    @Test
    @DisplayName("Should return copy of data rows list")
    void shouldReturnCopyOfDataRows() {
        SQLMockDataRow row = new SQLMockDataRow();
        mock.addDataRow(row);
        
        var rows = mock.getDataRows();
        rows.clear(); // Modifying returned list
        
        assertEquals(1, mock.getRowCount()); // Original unchanged
    }

    @Test
    @DisplayName("toString should include key information")
    void toStringShouldIncludeKeyInfo() {
        String str = mock.toString();
        assertTrue(str.contains("SQL-MOCK-001"));
        assertTrue(str.contains("SELECT"));
        assertTrue(str.contains("CUSTOMERS"));
    }

    @Test
    @DisplayName("Should match INSERT statement by table name")
    void shouldMatchInsertByTable() {
        SQLMockDefinition insertMock = new SQLMockDefinition("SQL-MOCK-004",
            "INSERT INTO CUSTOMERS (ID, NAME) VALUES (:ID, :NAME)");
        
        assertTrue(insertMock.matches(
            "INSERT INTO CUSTOMERS (CUST_ID, CUST_NAME) VALUES (:WS-ID, :WS-NAME)"));
        assertFalse(insertMock.matches(
            "INSERT INTO ORDERS (ID) VALUES (:ID)"));
    }

    @Test
    @DisplayName("Should match UPDATE statement by table name")
    void shouldMatchUpdateByTable() {
        SQLMockDefinition updateMock = new SQLMockDefinition("SQL-MOCK-005",
            "UPDATE CUSTOMERS SET BALANCE = :BAL WHERE ID = :ID");
        
        assertTrue(updateMock.matches(
            "UPDATE CUSTOMERS SET BALANCE = :WS-BAL WHERE ID = :WS-ID"));
        assertFalse(updateMock.matches(
            "UPDATE ORDERS SET STATUS = :STAT"));
    }

    @Test
    @DisplayName("Should match DELETE statement by table name")
    void shouldMatchDeleteByTable() {
        SQLMockDefinition deleteMock = new SQLMockDefinition("SQL-MOCK-006",
            "DELETE FROM CUSTOMERS WHERE ID = :ID");
        
        assertTrue(deleteMock.matches(
            "DELETE FROM CUSTOMERS WHERE CUST_ID = :WS-CUST-ID"));
        assertFalse(deleteMock.matches(
            "DELETE FROM ORDERS WHERE ORDER_ID = :ID"));
    }
}
