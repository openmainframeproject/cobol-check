package org.openmainframeproject.cobolcheck.features.sql;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

/**
 * Represents a single row of mock data for SQL result sets.
 * Maintains field values and an optional row-specific SQLCODE.
 * 
 * Field order is preserved using LinkedHashMap to ensure consistent
 * COBOL code generation.
 */
public class SQLMockDataRow {
    
    private final Map<String, String> fieldValues;
    private int rowSqlcode;
    private boolean hasRowSqlcode;
    
    /**
     * Creates a new empty data row with default SQLCODE of 0.
     */
    public SQLMockDataRow() {
        this.fieldValues = new LinkedHashMap<>();
        this.rowSqlcode = 0;
        this.hasRowSqlcode = false;
    }
    
    /**
     * Creates a new data row with specified SQLCODE.
     * 
     * @param sqlcode The SQLCODE for this specific row
     */
    public SQLMockDataRow(int sqlcode) {
        this.fieldValues = new LinkedHashMap<>();
        this.rowSqlcode = sqlcode;
        this.hasRowSqlcode = true;
    }
    
    /**
     * Sets a field value for this row.
     * 
     * @param fieldName  The COBOL field name (e.g., "CUST-NAME")
     * @param fieldValue The value to assign (e.g., "ACME CORP")
     */
    public void setFieldValue(String fieldName, String fieldValue) {
        if (fieldName == null || fieldName.trim().isEmpty()) {
            throw new IllegalArgumentException("Field name cannot be null or empty");
        }
        fieldValues.put(normalizeFieldName(fieldName), fieldValue);
    }
    
    /**
     * Gets a field value from this row.
     * 
     * @param fieldName The COBOL field name
     * @return The field value, or null if not set
     */
    public String getFieldValue(String fieldName) {
        return fieldValues.get(normalizeFieldName(fieldName));
    }
    
    /**
     * Checks if a field exists in this row.
     * 
     * @param fieldName The COBOL field name
     * @return true if the field has a value
     */
    public boolean hasField(String fieldName) {
        return fieldValues.containsKey(normalizeFieldName(fieldName));
    }
    
    /**
     * Gets all field names in this row.
     * 
     * @return Set of field names in insertion order
     */
    public Set<String> getFieldNames() {
        return fieldValues.keySet();
    }
    
    /**
     * Gets the number of fields in this row.
     * 
     * @return The field count
     */
    public int getFieldCount() {
        return fieldValues.size();
    }
    
    /**
     * Gets the SQLCODE for this specific row.
     * Used for simulating end-of-data (SQLCODE 100) or errors.
     * 
     * @return The row-specific SQLCODE
     */
    public int getRowSqlcode() {
        return rowSqlcode;
    }
    
    /**
     * Sets the SQLCODE for this specific row.
     * 
     * @param sqlcode The SQLCODE value
     */
    public void setRowSqlcode(int sqlcode) {
        this.rowSqlcode = sqlcode;
        this.hasRowSqlcode = true;
    }
    
    /**
     * Checks if this row has a specific SQLCODE set.
     * 
     * @return true if a row-specific SQLCODE was set
     */
    public boolean hasRowSqlcode() {
        return hasRowSqlcode;
    }
    
    /**
     * Checks if this row represents end-of-data (SQLCODE 100).
     * 
     * @return true if SQLCODE indicates no more rows
     */
    public boolean isEndOfData() {
        return hasRowSqlcode && rowSqlcode == 100;
    }
    
    /**
     * Checks if this row represents an error condition.
     * 
     * @return true if SQLCODE indicates an error (negative value)
     */
    public boolean isError() {
        return hasRowSqlcode && rowSqlcode < 0;
    }
    
    /**
     * Gets all field values as a map.
     * 
     * @return Unmodifiable map of field names to values
     */
    public Map<String, String> getAllFieldValues() {
        return Map.copyOf(fieldValues);
    }
    
    /**
     * Normalizes a COBOL field name for consistent lookup.
     * Converts to uppercase and trims whitespace.
     * 
     * @param fieldName The field name to normalize
     * @return Normalized field name
     */
    private String normalizeFieldName(String fieldName) {
        return fieldName.trim().toUpperCase();
    }
    
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("SQLMockDataRow{");
        if (hasRowSqlcode) {
            sb.append("sqlcode=").append(rowSqlcode).append(", ");
        }
        sb.append("fields=").append(fieldValues);
        sb.append("}");
        return sb.toString();
    }
}
