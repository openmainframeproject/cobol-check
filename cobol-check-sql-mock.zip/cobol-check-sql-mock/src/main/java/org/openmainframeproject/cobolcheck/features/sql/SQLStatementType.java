package org.openmainframeproject.cobolcheck.features.sql;

/**
 * Enumeration of SQL statement types that can be mocked.
 * Used to categorize EXEC SQL statements for appropriate handling.
 */
public enum SQLStatementType {
    
    /**
     * SELECT statement - retrieves data from database
     */
    SELECT("SELECT"),
    
    /**
     * INSERT statement - adds new rows to a table
     */
    INSERT("INSERT"),
    
    /**
     * UPDATE statement - modifies existing rows
     */
    UPDATE("UPDATE"),
    
    /**
     * DELETE statement - removes rows from a table
     */
    DELETE("DELETE"),
    
    /**
     * OPEN CURSOR - opens a cursor for fetching
     */
    OPEN_CURSOR("OPEN"),
    
    /**
     * FETCH - retrieves next row from cursor
     */
    FETCH_CURSOR("FETCH"),
    
    /**
     * CLOSE CURSOR - closes an open cursor
     */
    CLOSE_CURSOR("CLOSE"),
    
    /**
     * COMMIT - commits current transaction
     */
    COMMIT("COMMIT"),
    
    /**
     * ROLLBACK - rolls back current transaction
     */
    ROLLBACK("ROLLBACK"),
    
    /**
     * CALL - calls a stored procedure
     */
    CALL("CALL"),
    
    /**
     * DECLARE CURSOR - declares a cursor (doesn't execute)
     */
    DECLARE_CURSOR("DECLARE"),
    
    /**
     * PREPARE - prepares a dynamic SQL statement
     */
    PREPARE("PREPARE"),
    
    /**
     * EXECUTE - executes a prepared statement
     */
    EXECUTE("EXECUTE"),
    
    /**
     * Unknown or unsupported SQL statement type
     */
    UNKNOWN("UNKNOWN");
    
    private final String keyword;
    
    SQLStatementType(String keyword) {
        this.keyword = keyword;
    }
    
    public String getKeyword() {
        return keyword;
    }
    
    /**
     * Determines the SQL statement type from a SQL string.
     * 
     * @param sql The SQL statement to analyze
     * @return The corresponding SQLStatementType
     */
    public static SQLStatementType fromSQL(String sql) {
        if (sql == null || sql.trim().isEmpty()) {
            return UNKNOWN;
        }
        
        String normalizedSQL = sql.trim().toUpperCase();
        
        // Handle cursor operations first (they have specific patterns)
        if (normalizedSQL.startsWith("OPEN ")) {
            return OPEN_CURSOR;
        }
        if (normalizedSQL.startsWith("FETCH ")) {
            return FETCH_CURSOR;
        }
        if (normalizedSQL.startsWith("CLOSE ")) {
            return CLOSE_CURSOR;
        }
        if (normalizedSQL.startsWith("DECLARE ") && normalizedSQL.contains("CURSOR")) {
            return DECLARE_CURSOR;
        }
        
        // Handle standard DML statements
        if (normalizedSQL.startsWith("SELECT ") || normalizedSQL.startsWith("SELECT\n")) {
            return SELECT;
        }
        if (normalizedSQL.startsWith("INSERT ") || normalizedSQL.startsWith("INSERT\n")) {
            return INSERT;
        }
        if (normalizedSQL.startsWith("UPDATE ") || normalizedSQL.startsWith("UPDATE\n")) {
            return UPDATE;
        }
        if (normalizedSQL.startsWith("DELETE ") || normalizedSQL.startsWith("DELETE\n")) {
            return DELETE;
        }
        
        // Handle transaction control
        if (normalizedSQL.startsWith("COMMIT")) {
            return COMMIT;
        }
        if (normalizedSQL.startsWith("ROLLBACK")) {
            return ROLLBACK;
        }
        
        // Handle dynamic SQL
        if (normalizedSQL.startsWith("CALL ")) {
            return CALL;
        }
        if (normalizedSQL.startsWith("PREPARE ")) {
            return PREPARE;
        }
        if (normalizedSQL.startsWith("EXECUTE ")) {
            return EXECUTE;
        }
        
        return UNKNOWN;
    }
    
    /**
     * Checks if this statement type returns data (requires WITH DATA block).
     * 
     * @return true if the statement type can return data
     */
    public boolean returnsData() {
        return this == SELECT || this == FETCH_CURSOR || this == CALL;
    }
    
    /**
     * Checks if this statement type modifies data.
     * 
     * @return true if the statement type modifies data
     */
    public boolean modifiesData() {
        return this == INSERT || this == UPDATE || this == DELETE;
    }
    
    /**
     * Checks if this statement type is a cursor operation.
     * 
     * @return true if the statement type is cursor-related
     */
    public boolean isCursorOperation() {
        return this == OPEN_CURSOR || this == FETCH_CURSOR || 
               this == CLOSE_CURSOR || this == DECLARE_CURSOR;
    }
    
    /**
     * Checks if this statement type is a transaction control statement.
     * 
     * @return true if the statement type controls transactions
     */
    public boolean isTransactionControl() {
        return this == COMMIT || this == ROLLBACK;
    }
}
