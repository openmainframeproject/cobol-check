package org.openmainframeproject.cobolcheck.features.sql;

import java.util.*;

/**
 * Parser for SQL mock syntax in COBOL Check test suites.
 * 
 * Parses mock definitions in the format:
 * <pre>
 * MOCK EXEC SQL <sql-statement>
 *     [RETURNS SQLCODE(<value>)]
 *     [RETURNS SQLERRMC("<message>")]
 *     [RETURNS SQLSTATE("<state>")]
 *     [WITH DATA
 *         [ROW <n>]
 *         <field> = <value>
 *         [END-ROW]
 *     END-DATA]
 * END-MOCK
 * </pre>
 */
public class SQLMockParser {
    
    // Keywords recognized by the parser
    private static final Set<String> KEYWORDS = new HashSet<>(Arrays.asList(
        "MOCK", "EXEC", "SQL", "RETURNS", "SQLCODE", "SQLERRMC", "SQLSTATE",
        "WITH", "DATA", "END-DATA", "ROW", "END-ROW", "END-MOCK",
        "VERIFY", "HAPPENED", "TIMES", "ONCE", "TWICE", "NEVER", "AT", "LEAST", "MOST"
    ));
    
    private final SQLMockRepository repository;
    private List<String> tokens;
    private int currentIndex;
    private String currentTestFile;
    private int currentLine;
    
    /**
     * Creates a new SQL mock parser.
     * 
     * @param repository The repository to store parsed mocks
     */
    public SQLMockParser(SQLMockRepository repository) {
        this.repository = repository;
    }
    
    /**
     * Sets the current source file for error reporting.
     * 
     * @param testFile The test suite file name
     */
    public void setCurrentTestFile(String testFile) {
        this.currentTestFile = testFile;
    }
    
    /**
     * Sets the current line number for error reporting.
     * 
     * @param line The current line number
     */
    public void setCurrentLine(int line) {
        this.currentLine = line;
    }
    
    /**
     * Checks if a token indicates the start of an SQL mock.
     * 
     * @param token The token to check
     * @return true if this starts an SQL mock block
     */
    public boolean isSQLMockStart(String token) {
        return "MOCK".equalsIgnoreCase(token);
    }
    
    /**
     * Checks if tokens indicate EXEC SQL (after MOCK).
     * 
     * @param tokens List of tokens
     * @param index  Current index
     * @return true if this is MOCK EXEC SQL
     */
    public boolean isExecSQL(List<String> tokens, int index) {
        if (index + 2 >= tokens.size()) return false;
        return "MOCK".equalsIgnoreCase(tokens.get(index)) &&
               "EXEC".equalsIgnoreCase(tokens.get(index + 1)) &&
               "SQL".equalsIgnoreCase(tokens.get(index + 2));
    }
    
    /**
     * Checks if a token indicates SQL verification.
     * 
     * @param token The token to check
     * @return true if this starts an SQL verification
     */
    public boolean isSQLVerify(String token) {
        return "VERIFY".equalsIgnoreCase(token);
    }
    
    /**
     * Parses an SQL mock block from the token stream.
     * 
     * @param tokens The complete token list
     * @param startIndex Index of the MOCK token
     * @return ParseResult containing the mock and end index
     * @throws SQLMockParseException if parsing fails
     */
    public ParseResult parseMock(List<String> tokens, int startIndex) 
            throws SQLMockParseException {
        this.tokens = tokens;
        this.currentIndex = startIndex;
        
        // Verify MOCK EXEC SQL
        expect("MOCK");
        expect("EXEC");
        expect("SQL");
        
        // Parse SQL statement until we hit a keyword
        String sqlStatement = parseSQL();
        
        // Create mock definition
        String mockId = repository.generateMockId();
        SQLMockDefinition mock = new SQLMockDefinition(mockId, sqlStatement);
        mock.setSourceFile(currentTestFile);
        mock.setSourceLine(currentLine);
        
        // Parse optional clauses
        while (currentIndex < tokens.size()) {
            String token = peekToken();
            
            if ("RETURNS".equalsIgnoreCase(token)) {
                parseReturns(mock);
            } else if ("WITH".equalsIgnoreCase(token)) {
                parseWithData(mock);
            } else if ("END-MOCK".equalsIgnoreCase(token)) {
                consumeToken(); // consume END-MOCK
                break;
            } else {
                throw new SQLMockParseException(
                    "Unexpected token '" + token + "' in SQL mock at " + getLocation());
            }
        }
        
        repository.addMock(mock);
        return new ParseResult(mock, currentIndex);
    }
    
    /**
     * Parses an SQL verification statement.
     * 
     * @param tokens The complete token list
     * @param startIndex Index of the VERIFY token
     * @return VerifyParseResult containing verification details
     */
    public VerifyParseResult parseVerify(List<String> tokens, int startIndex)
            throws SQLMockParseException {
        this.tokens = tokens;
        this.currentIndex = startIndex;
        
        expect("VERIFY");
        expect("EXEC");
        expect("SQL");
        
        // Parse SQL pattern
        String sqlPattern = parseSQL();
        
        // Parse HAPPENED clause
        int expectedCount = 1;
        SQLMockRepository.VerificationComparison comparison = 
            SQLMockRepository.VerificationComparison.EXACTLY;
        
        if (matchToken("HAPPENED")) {
            // Check for comparison modifiers
            if (matchToken("NEVER")) {
                expectedCount = 0;
                comparison = SQLMockRepository.VerificationComparison.NEVER;
            } else if (matchToken("ONCE")) {
                expectedCount = 1;
            } else if (matchToken("TWICE")) {
                expectedCount = 2;
            } else if (matchToken("AT")) {
                if (matchToken("LEAST")) {
                    comparison = SQLMockRepository.VerificationComparison.AT_LEAST;
                } else if (matchToken("MOST")) {
                    comparison = SQLMockRepository.VerificationComparison.AT_MOST;
                }
                expectedCount = parseNumber();
                matchToken("TIMES"); // optional
            } else {
                expectedCount = parseNumber();
                matchToken("TIMES"); // optional
            }
        }
        
        return new VerifyParseResult(sqlPattern, expectedCount, comparison, currentIndex);
    }
    
    /**
     * Parses the SQL statement portion.
     */
    private String parseSQL() throws SQLMockParseException {
        StringBuilder sql = new StringBuilder();
        
        while (currentIndex < tokens.size()) {
            String token = peekToken();
            
            // Stop at mock keywords
            if (isStopKeyword(token)) {
                break;
            }
            
            if (sql.length() > 0) {
                sql.append(" ");
            }
            sql.append(consumeToken());
        }
        
        if (sql.length() == 0) {
            throw new SQLMockParseException(
                "Empty SQL statement in mock at " + getLocation());
        }
        
        return sql.toString();
    }
    
    /**
     * Parses RETURNS clause.
     */
    private void parseReturns(SQLMockDefinition mock) throws SQLMockParseException {
        expect("RETURNS");
        String returnType = consumeToken().toUpperCase();
        
        switch (returnType) {
            case "SQLCODE":
                expect("(");
                int sqlcode = parseSignedNumber();
                expect(")");
                mock.setSqlcode(sqlcode);
                break;
                
            case "SQLERRMC":
                expect("(");
                String errmc = parseStringValue();
                expect(")");
                mock.setSqlerrmc(errmc);
                break;
                
            case "SQLSTATE":
                expect("(");
                String state = parseStringValue();
                expect(")");
                mock.setSqlstate(state);
                break;
                
            default:
                throw new SQLMockParseException(
                    "Unknown RETURNS type '" + returnType + "' at " + getLocation());
        }
    }
    
    /**
     * Parses WITH DATA block.
     */
    private void parseWithData(SQLMockDefinition mock) throws SQLMockParseException {
        expect("WITH");
        expect("DATA");
        
        SQLMockDataRow currentRow = new SQLMockDataRow();
        boolean inRow = false;
        int rowNumber = 0;
        
        while (currentIndex < tokens.size()) {
            String token = peekToken();
            
            if ("END-DATA".equalsIgnoreCase(token)) {
                consumeToken();
                // Add last row if it has data
                if (currentRow.getFieldCount() > 0 || currentRow.hasRowSqlcode()) {
                    mock.addDataRow(currentRow);
                }
                break;
            }
            
            if ("ROW".equalsIgnoreCase(token)) {
                // Save previous row if exists
                if (inRow && (currentRow.getFieldCount() > 0 || currentRow.hasRowSqlcode())) {
                    mock.addDataRow(currentRow);
                }
                
                consumeToken(); // ROW
                rowNumber = parseNumber();
                currentRow = new SQLMockDataRow();
                inRow = true;
                continue;
            }
            
            if ("END-ROW".equalsIgnoreCase(token)) {
                consumeToken();
                if (currentRow.getFieldCount() > 0 || currentRow.hasRowSqlcode()) {
                    mock.addDataRow(currentRow);
                }
                currentRow = new SQLMockDataRow();
                inRow = false;
                continue;
            }
            
            if ("SQLCODE".equalsIgnoreCase(token)) {
                consumeToken();
                expect("=");
                int sqlcode = parseSignedNumber();
                currentRow.setRowSqlcode(sqlcode);
                continue;
            }
            
            // Field assignment: FIELD-NAME = value
            String fieldName = consumeToken();
            expect("=");
            String fieldValue = parseFieldValue();
            currentRow.setFieldValue(fieldName, fieldValue);
        }
    }
    
    /**
     * Parses a field value (string or number).
     */
    private String parseFieldValue() throws SQLMockParseException {
        String token = peekToken();
        
        // String value
        if (token.startsWith("\"") || token.startsWith("'")) {
            return parseStringValue();
        }
        
        // Numeric value (possibly negative)
        if (token.equals("-") || token.matches("-?\\d.*")) {
            return parseNumericValue();
        }
        
        // Just consume as-is
        return consumeToken();
    }
    
    /**
     * Parses a quoted string value.
     */
    private String parseStringValue() throws SQLMockParseException {
        String token = consumeToken();
        
        // Handle quoted string
        if (token.startsWith("\"") || token.startsWith("'")) {
            char quote = token.charAt(0);
            
            // Check if string ends with same quote
            if (token.length() > 1 && token.endsWith(String.valueOf(quote))) {
                return token.substring(1, token.length() - 1);
            }
            
            // Multi-token string
            StringBuilder sb = new StringBuilder(token.substring(1));
            while (currentIndex < tokens.size()) {
                String next = consumeToken();
                if (next.endsWith(String.valueOf(quote))) {
                    sb.append(" ").append(next, 0, next.length() - 1);
                    break;
                }
                sb.append(" ").append(next);
            }
            return sb.toString();
        }
        
        return token;
    }
    
    /**
     * Parses a numeric value.
     */
    private String parseNumericValue() throws SQLMockParseException {
        StringBuilder sb = new StringBuilder();
        
        // Handle negative sign
        if (peekToken().equals("-")) {
            sb.append(consumeToken());
        }
        
        sb.append(consumeToken());
        return sb.toString();
    }
    
    /**
     * Parses an integer number.
     */
    private int parseNumber() throws SQLMockParseException {
        String token = consumeToken();
        try {
            return Integer.parseInt(token);
        } catch (NumberFormatException e) {
            throw new SQLMockParseException(
                "Expected number, got '" + token + "' at " + getLocation());
        }
    }
    
    /**
     * Parses a signed integer.
     */
    private int parseSignedNumber() throws SQLMockParseException {
        boolean negative = false;
        if (peekToken().equals("-")) {
            consumeToken();
            negative = true;
        }
        int value = parseNumber();
        return negative ? -value : value;
    }
    
    /**
     * Checks if token is a stop keyword for SQL parsing.
     */
    private boolean isStopKeyword(String token) {
        String upper = token.toUpperCase();
        return upper.equals("RETURNS") || upper.equals("WITH") || 
               upper.equals("END-MOCK") || upper.equals("END-DATA");
    }
    
    /**
     * Expects and consumes a specific token.
     */
    private void expect(String expected) throws SQLMockParseException {
        String actual = consumeToken();
        // Handle parentheses specially
        if (expected.equals("(") || expected.equals(")")) {
            if (!actual.equals(expected)) {
                throw new SQLMockParseException(
                    "Expected '" + expected + "', got '" + actual + "' at " + getLocation());
            }
        } else if (!expected.equalsIgnoreCase(actual)) {
            throw new SQLMockParseException(
                "Expected '" + expected + "', got '" + actual + "' at " + getLocation());
        }
    }
    
    /**
     * Tries to match and consume a token.
     * 
     * @return true if token matched and was consumed
     */
    private boolean matchToken(String expected) {
        if (currentIndex < tokens.size() && 
            expected.equalsIgnoreCase(peekToken())) {
            consumeToken();
            return true;
        }
        return false;
    }
    
    /**
     * Peeks at the current token without consuming.
     */
    private String peekToken() {
        if (currentIndex >= tokens.size()) {
            return "";
        }
        return tokens.get(currentIndex);
    }
    
    /**
     * Consumes and returns the current token.
     */
    private String consumeToken() throws SQLMockParseException {
        if (currentIndex >= tokens.size()) {
            throw new SQLMockParseException(
                "Unexpected end of input at " + getLocation());
        }
        return tokens.get(currentIndex++);
    }
    
    /**
     * Gets current location string for error messages.
     */
    private String getLocation() {
        if (currentTestFile != null) {
            return currentTestFile + ":" + currentLine;
        }
        return "line " + currentLine;
    }
    
    /**
     * Result of parsing a mock definition.
     */
    public static class ParseResult {
        private final SQLMockDefinition mock;
        private final int endIndex;
        
        public ParseResult(SQLMockDefinition mock, int endIndex) {
            this.mock = mock;
            this.endIndex = endIndex;
        }
        
        public SQLMockDefinition getMock() { return mock; }
        public int getEndIndex() { return endIndex; }
    }
    
    /**
     * Result of parsing a verification statement.
     */
    public static class VerifyParseResult {
        private final String sqlPattern;
        private final int expectedCount;
        private final SQLMockRepository.VerificationComparison comparison;
        private final int endIndex;
        
        public VerifyParseResult(String sqlPattern, int expectedCount,
                                  SQLMockRepository.VerificationComparison comparison,
                                  int endIndex) {
            this.sqlPattern = sqlPattern;
            this.expectedCount = expectedCount;
            this.comparison = comparison;
            this.endIndex = endIndex;
        }
        
        public String getSqlPattern() { return sqlPattern; }
        public int getExpectedCount() { return expectedCount; }
        public SQLMockRepository.VerificationComparison getComparison() { return comparison; }
        public int getEndIndex() { return endIndex; }
    }
    
    /**
     * Exception thrown when SQL mock parsing fails.
     */
    public static class SQLMockParseException extends Exception {
        public SQLMockParseException(String message) {
            super(message);
        }
    }
}
