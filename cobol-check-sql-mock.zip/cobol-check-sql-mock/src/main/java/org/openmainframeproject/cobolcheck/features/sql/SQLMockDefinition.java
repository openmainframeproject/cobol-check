package org.openmainframeproject.cobolcheck.features.sql;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/**
 * Represents a complete SQL mock definition parsed from a test suite.
 * Contains all information needed to generate COBOL mock code.
 * 
 * Example usage in test suite:
 * <pre>
 * MOCK EXEC SQL SELECT * FROM CUSTOMERS WHERE CUST-ID = :WS-ID
 *     RETURNS SQLCODE(0)
 *     WITH DATA
 *         CUST-NAME = "ACME CORP"
 *         CUST-BALANCE = 15000.50
 *     END-DATA
 * END-MOCK
 * </pre>
 */
public class SQLMockDefinition {
    
    private final String id;
    private final String sqlPattern;
    private final SQLStatementType statementType;
    private final List<SQLMockDataRow> dataRows;
    
    private int sqlcode;
    private String sqlerrmc;
    private String sqlstate;
    private String cursorName;
    private int invocationCount;
    private Pattern compiledPattern;
    
    // For tracking source location (helpful for error messages)
    private String sourceFile;
    private int sourceLine;
    
    /**
     * Creates a new SQL mock definition.
     * 
     * @param id         Unique identifier for this mock (e.g., "SQL-MOCK-001")
     * @param sqlPattern The SQL pattern to match (from test suite)
     */
    public SQLMockDefinition(String id, String sqlPattern) {
        if (id == null || id.trim().isEmpty()) {
            throw new IllegalArgumentException("Mock ID cannot be null or empty");
        }
        if (sqlPattern == null || sqlPattern.trim().isEmpty()) {
            throw new IllegalArgumentException("SQL pattern cannot be null or empty");
        }
        
        this.id = id;
        this.sqlPattern = normalizeSQL(sqlPattern);
        this.statementType = SQLStatementType.fromSQL(this.sqlPattern);
        this.dataRows = new ArrayList<>();
        this.sqlcode = 0;
        this.sqlerrmc = "";
        this.sqlstate = "00000";
        this.invocationCount = 0;
        this.compiledPattern = buildMatchPattern(this.sqlPattern);
        
        // Extract cursor name if applicable
        if (statementType.isCursorOperation()) {
            this.cursorName = extractCursorName(this.sqlPattern);
        }
    }
    
    /**
     * Gets the unique identifier for this mock.
     * 
     * @return The mock ID
     */
    public String getId() {
        return id;
    }
    
    /**
     * Gets the SQL pattern this mock matches.
     * 
     * @return The normalized SQL pattern
     */
    public String getSqlPattern() {
        return sqlPattern;
    }
    
    /**
     * Gets the type of SQL statement being mocked.
     * 
     * @return The statement type
     */
    public SQLStatementType getStatementType() {
        return statementType;
    }
    
    /**
     * Gets the SQLCODE to return when this mock is triggered.
     * 
     * @return The SQLCODE value
     */
    public int getSqlcode() {
        return sqlcode;
    }
    
    /**
     * Sets the SQLCODE to return.
     * 
     * @param sqlcode The SQLCODE value (0 = success, 100 = not found, negative = error)
     */
    public void setSqlcode(int sqlcode) {
        this.sqlcode = sqlcode;
    }
    
    /**
     * Gets the SQLERRMC (error message) to return.
     * 
     * @return The error message
     */
    public String getSqlerrmc() {
        return sqlerrmc;
    }
    
    /**
     * Sets the SQLERRMC error message.
     * 
     * @param sqlerrmc The error message (max 70 characters)
     */
    public void setSqlerrmc(String sqlerrmc) {
        this.sqlerrmc = sqlerrmc != null ? sqlerrmc : "";
    }
    
    /**
     * Gets the SQLSTATE to return.
     * 
     * @return The 5-character SQLSTATE
     */
    public String getSqlstate() {
        return sqlstate;
    }
    
    /**
     * Sets the SQLSTATE.
     * 
     * @param sqlstate The 5-character SQLSTATE code
     */
    public void setSqlstate(String sqlstate) {
        if (sqlstate != null && sqlstate.length() == 5) {
            this.sqlstate = sqlstate;
        }
    }
    
    /**
     * Gets the cursor name for cursor operations.
     * 
     * @return The cursor name, or null if not a cursor operation
     */
    public String getCursorName() {
        return cursorName;
    }
    
    /**
     * Adds a data row to the mock result set.
     * 
     * @param row The data row to add
     */
    public void addDataRow(SQLMockDataRow row) {
        if (row != null) {
            dataRows.add(row);
        }
    }
    
    /**
     * Gets all data rows for this mock.
     * 
     * @return List of data rows
     */
    public List<SQLMockDataRow> getDataRows() {
        return new ArrayList<>(dataRows);
    }
    
    /**
     * Gets the number of data rows.
     * 
     * @return Row count
     */
    public int getRowCount() {
        return dataRows.size();
    }
    
    /**
     * Gets a specific data row by index.
     * 
     * @param index Zero-based row index
     * @return The data row, or null if index out of bounds
     */
    public SQLMockDataRow getDataRow(int index) {
        if (index >= 0 && index < dataRows.size()) {
            return dataRows.get(index);
        }
        return null;
    }
    
    /**
     * Checks if an actual SQL statement matches this mock's pattern.
     * 
     * @param actualSQL The SQL statement from the program being tested
     * @return true if the SQL matches this mock
     */
    public boolean matches(String actualSQL) {
        if (actualSQL == null || actualSQL.trim().isEmpty()) {
            return false;
        }
        
        String normalizedActual = normalizeSQL(actualSQL);
        
        // First try exact match (after normalization)
        if (normalizedActual.equals(sqlPattern)) {
            return true;
        }
        
        // Try pattern matching (handles host variables and wildcards)
        if (compiledPattern != null) {
            return compiledPattern.matcher(normalizedActual).matches();
        }
        
        // Fall back to keyword-based matching
        return keywordMatch(normalizedActual);
    }
    
    /**
     * Records that this mock was invoked.
     */
    public void recordInvocation() {
        invocationCount++;
    }
    
    /**
     * Gets the number of times this mock was invoked.
     * 
     * @return The invocation count
     */
    public int getInvocationCount() {
        return invocationCount;
    }
    
    /**
     * Resets the invocation count (typically between test cases).
     */
    public void resetInvocationCount() {
        invocationCount = 0;
    }
    
    /**
     * Sets the source file location for error reporting.
     * 
     * @param sourceFile The test suite file name
     */
    public void setSourceFile(String sourceFile) {
        this.sourceFile = sourceFile;
    }
    
    /**
     * Sets the source line number for error reporting.
     * 
     * @param sourceLine The line number in the test suite
     */
    public void setSourceLine(int sourceLine) {
        this.sourceLine = sourceLine;
    }
    
    /**
     * Gets a descriptive location string for error messages.
     * 
     * @return Location description
     */
    public String getSourceLocation() {
        if (sourceFile != null) {
            return sourceFile + ":" + sourceLine;
        }
        return "line " + sourceLine;
    }
    
    /**
     * Normalizes SQL for consistent comparison.
     * - Converts to uppercase
     * - Collapses multiple whitespace to single space
     * - Trims leading/trailing whitespace
     * - Removes EXEC SQL and END-EXEC wrappers
     */
    private String normalizeSQL(String sql) {
        String normalized = sql.toUpperCase()
            .replaceAll("\\s+", " ")
            .trim();
        
        // Remove EXEC SQL wrapper if present
        if (normalized.startsWith("EXEC SQL ")) {
            normalized = normalized.substring(9);
        }
        
        // Remove END-EXEC if present
        if (normalized.endsWith(" END-EXEC")) {
            normalized = normalized.substring(0, normalized.length() - 9);
        }
        if (normalized.endsWith("END-EXEC")) {
            normalized = normalized.substring(0, normalized.length() - 8);
        }
        
        return normalized.trim();
    }
    
    /**
     * Builds a regex pattern for matching SQL with host variables.
     * Host variables (prefixed with :) are converted to wildcards.
     */
    private Pattern buildMatchPattern(String sqlPattern) {
        try {
            // Escape regex special characters except for our wildcards
            String pattern = sqlPattern
                .replace(".", "\\.")
                .replace("(", "\\(")
                .replace(")", "\\)")
                .replace("[", "\\[")
                .replace("]", "\\]")
                .replace("*", ".*");
            
            // Replace host variables with wildcards
            // Host variables are prefixed with : in COBOL SQL
            pattern = pattern.replaceAll(":[A-Z][A-Z0-9-]*", "[^,\\\\s]+");
            
            return Pattern.compile(pattern);
        } catch (Exception e) {
            // If pattern compilation fails, fall back to keyword matching
            return null;
        }
    }
    
    /**
     * Performs keyword-based matching as a fallback.
     * Matches if statement type and table/cursor name match.
     */
    private boolean keywordMatch(String actualSQL) {
        SQLStatementType actualType = SQLStatementType.fromSQL(actualSQL);
        
        // Statement types must match
        if (actualType != statementType) {
            return false;
        }
        
        // For cursor operations, cursor names must match
        if (statementType.isCursorOperation() && cursorName != null) {
            String actualCursor = extractCursorName(actualSQL);
            return cursorName.equals(actualCursor);
        }
        
        // For DML, extract and compare table names
        String patternTable = extractTableName(sqlPattern);
        String actualTable = extractTableName(actualSQL);
        
        return patternTable != null && patternTable.equals(actualTable);
    }
    
    /**
     * Extracts the cursor name from a cursor operation SQL.
     */
    private String extractCursorName(String sql) {
        String[] words = sql.split("\\s+");
        if (words.length >= 2) {
            // OPEN cursor-name, FETCH cursor-name, CLOSE cursor-name
            return words[1];
        }
        return null;
    }
    
    /**
     * Extracts the table name from a DML SQL statement.
     */
    private String extractTableName(String sql) {
        String upperSQL = sql.toUpperCase();
        
        // SELECT ... FROM table
        int fromIndex = upperSQL.indexOf(" FROM ");
        if (fromIndex > 0) {
            String afterFrom = upperSQL.substring(fromIndex + 6).trim();
            return afterFrom.split("\\s+")[0];
        }
        
        // INSERT INTO table
        int intoIndex = upperSQL.indexOf(" INTO ");
        if (intoIndex > 0) {
            String afterInto = upperSQL.substring(intoIndex + 6).trim();
            return afterInto.split("[\\s(]")[0];
        }
        
        // UPDATE table
        if (upperSQL.startsWith("UPDATE ")) {
            String afterUpdate = upperSQL.substring(7).trim();
            return afterUpdate.split("\\s+")[0];
        }
        
        // DELETE FROM table
        if (upperSQL.startsWith("DELETE FROM ")) {
            String afterDelete = upperSQL.substring(12).trim();
            return afterDelete.split("\\s+")[0];
        }
        if (upperSQL.startsWith("DELETE ")) {
            String afterDelete = upperSQL.substring(7).trim();
            return afterDelete.split("\\s+")[0];
        }
        
        return null;
    }
    
    @Override
    public String toString() {
        return "SQLMockDefinition{" +
            "id='" + id + '\'' +
            ", type=" + statementType +
            ", pattern='" + sqlPattern + '\'' +
            ", sqlcode=" + sqlcode +
            ", rows=" + dataRows.size() +
            ", invocations=" + invocationCount +
            '}';
    }
}
