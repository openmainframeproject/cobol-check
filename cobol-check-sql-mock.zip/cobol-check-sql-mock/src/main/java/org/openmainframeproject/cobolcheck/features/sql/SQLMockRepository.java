package org.openmainframeproject.cobolcheck.features.sql;

import java.util.*;

/**
 * Repository for managing SQL mock definitions.
 * Provides storage, lookup, and verification capabilities for SQL mocks.
 * 
 * Features:
 * - Stores mock definitions with unique IDs
 * - Matches actual SQL statements to mock definitions
 * - Tracks cursor states for multi-fetch scenarios
 * - Supports mock verification (happened N times)
 * - Handles scope (test case level vs test suite level)
 */
public class SQLMockRepository {
    
    private final List<SQLMockDefinition> mocks;
    private final Map<String, CursorState> cursorStates;
    private final Map<String, Integer> unmockedSQLCount;
    private int mockIdCounter;
    private boolean strictMatching;
    private boolean logUnmocked;
    
    /**
     * Creates a new empty SQL mock repository.
     */
    public SQLMockRepository() {
        this.mocks = new ArrayList<>();
        this.cursorStates = new HashMap<>();
        this.unmockedSQLCount = new LinkedHashMap<>();
        this.mockIdCounter = 0;
        this.strictMatching = false;
        this.logUnmocked = true;
    }
    
    /**
     * Generates a unique ID for a new mock.
     * 
     * @return A unique mock ID (e.g., "SQL-MOCK-001")
     */
    public String generateMockId() {
        mockIdCounter++;
        return String.format("SQL-MOCK-%03d", mockIdCounter);
    }
    
    /**
     * Adds a mock definition to the repository.
     * 
     * @param mock The mock definition to add
     */
    public void addMock(SQLMockDefinition mock) {
        if (mock != null) {
            mocks.add(mock);
            
            // Initialize cursor state if it's a cursor mock
            if (mock.getStatementType().isCursorOperation() && 
                mock.getCursorName() != null) {
                String cursorName = mock.getCursorName();
                if (!cursorStates.containsKey(cursorName)) {
                    cursorStates.put(cursorName, new CursorState(cursorName));
                }
            }
        }
    }
    
    /**
     * Finds a mock definition that matches the given SQL statement.
     * 
     * @param actualSQL The SQL statement from the program being tested
     * @return The matching mock definition, or null if no match
     */
    public SQLMockDefinition findMock(String actualSQL) {
        if (actualSQL == null || actualSQL.trim().isEmpty()) {
            return null;
        }
        
        // Search in reverse order so later definitions override earlier ones
        for (int i = mocks.size() - 1; i >= 0; i--) {
            SQLMockDefinition mock = mocks.get(i);
            if (mock.matches(actualSQL)) {
                return mock;
            }
        }
        
        // Track unmocked SQL if logging is enabled
        if (logUnmocked) {
            String normalizedSQL = normalizeForLogging(actualSQL);
            unmockedSQLCount.merge(normalizedSQL, 1, Integer::sum);
        }
        
        return null;
    }
    
    /**
     * Gets all mock definitions.
     * 
     * @return Unmodifiable list of all mocks
     */
    public List<SQLMockDefinition> getAllMocks() {
        return Collections.unmodifiableList(mocks);
    }
    
    /**
     * Gets the number of mock definitions.
     * 
     * @return Mock count
     */
    public int getMockCount() {
        return mocks.size();
    }
    
    /**
     * Finds a mock by its ID.
     * 
     * @param id The mock ID to find
     * @return The mock definition, or null if not found
     */
    public SQLMockDefinition findById(String id) {
        return mocks.stream()
            .filter(m -> m.getId().equals(id))
            .findFirst()
            .orElse(null);
    }
    
    /**
     * Gets the cursor state for a named cursor.
     * 
     * @param cursorName The cursor name
     * @return The cursor state, or null if not tracked
     */
    public CursorState getCursorState(String cursorName) {
        return cursorStates.get(cursorName.toUpperCase());
    }
    
    /**
     * Opens a cursor.
     * 
     * @param cursorName The cursor name
     * @param totalRows  The total number of rows available
     */
    public void openCursor(String cursorName, int totalRows) {
        String name = cursorName.toUpperCase();
        CursorState state = cursorStates.get(name);
        if (state == null) {
            state = new CursorState(name);
            cursorStates.put(name, state);
        }
        state.open(totalRows);
    }
    
    /**
     * Advances a cursor to the next row.
     * 
     * @param cursorName The cursor name
     * @return true if there are more rows, false if at end
     */
    public boolean fetchCursor(String cursorName) {
        CursorState state = cursorStates.get(cursorName.toUpperCase());
        if (state != null && state.isOpen()) {
            return state.fetch();
        }
        return false;
    }
    
    /**
     * Closes a cursor.
     * 
     * @param cursorName The cursor name
     */
    public void closeCursor(String cursorName) {
        CursorState state = cursorStates.get(cursorName.toUpperCase());
        if (state != null) {
            state.close();
        }
    }
    
    /**
     * Gets the current row index for a cursor.
     * 
     * @param cursorName The cursor name
     * @return Current row index (0-based), or -1 if cursor not found/not open
     */
    public int getCursorRowIndex(String cursorName) {
        CursorState state = cursorStates.get(cursorName.toUpperCase());
        if (state != null && state.isOpen()) {
            return state.getCurrentRow();
        }
        return -1;
    }
    
    /**
     * Verifies that a mock was invoked the expected number of times.
     * 
     * @param sqlPattern    The SQL pattern to verify
     * @param expectedCount The expected invocation count
     * @param comparison    The comparison type (EXACTLY, AT_LEAST, AT_MOST)
     * @return VerificationResult with success status and message
     */
    public VerificationResult verify(String sqlPattern, int expectedCount, 
                                      VerificationComparison comparison) {
        SQLMockDefinition mock = findMockByPattern(sqlPattern);
        
        if (mock == null) {
            return new VerificationResult(false, 
                "No mock found for pattern: " + sqlPattern);
        }
        
        int actualCount = mock.getInvocationCount();
        boolean passed;
        
        switch (comparison) {
            case EXACTLY:
                passed = actualCount == expectedCount;
                break;
            case AT_LEAST:
                passed = actualCount >= expectedCount;
                break;
            case AT_MOST:
                passed = actualCount <= expectedCount;
                break;
            case NEVER:
                passed = actualCount == 0;
                break;
            default:
                passed = actualCount == expectedCount;
        }
        
        String message;
        if (passed) {
            message = String.format("PASS: SQL mock '%s' was invoked %d time(s)",
                mock.getId(), actualCount);
        } else {
            message = String.format("FAIL: SQL mock '%s' expected %s %d, actual %d",
                mock.getId(), comparison.getDescription(), expectedCount, actualCount);
        }
        
        return new VerificationResult(passed, message);
    }
    
    /**
     * Finds a mock by its SQL pattern (not by actual SQL match).
     */
    private SQLMockDefinition findMockByPattern(String pattern) {
        String normalizedPattern = pattern.toUpperCase().trim();
        return mocks.stream()
            .filter(m -> m.getSqlPattern().equals(normalizedPattern) ||
                        m.getSqlPattern().contains(normalizedPattern))
            .findFirst()
            .orElse(null);
    }
    
    /**
     * Resets all mock invocation counts.
     * Called between test cases.
     */
    public void resetInvocationCounts() {
        mocks.forEach(SQLMockDefinition::resetInvocationCount);
    }
    
    /**
     * Resets cursor states.
     * Called between test cases.
     */
    public void resetCursorStates() {
        cursorStates.values().forEach(CursorState::reset);
    }
    
    /**
     * Clears all mocks.
     * Called between test suites.
     */
    public void clearAll() {
        mocks.clear();
        cursorStates.clear();
        unmockedSQLCount.clear();
        mockIdCounter = 0;
    }
    
    /**
     * Gets a report of unmocked SQL statements encountered.
     * 
     * @return Map of SQL patterns to occurrence counts
     */
    public Map<String, Integer> getUnmockedSQLReport() {
        return Collections.unmodifiableMap(unmockedSQLCount);
    }
    
    /**
     * Checks if any unmocked SQL was encountered.
     * 
     * @return true if unmocked SQL was found
     */
    public boolean hasUnmockedSQL() {
        return !unmockedSQLCount.isEmpty();
    }
    
    /**
     * Sets whether to use strict pattern matching.
     * 
     * @param strict true for exact matching only
     */
    public void setStrictMatching(boolean strict) {
        this.strictMatching = strict;
    }
    
    /**
     * Sets whether to log unmocked SQL statements.
     * 
     * @param log true to log unmocked SQL
     */
    public void setLogUnmocked(boolean log) {
        this.logUnmocked = log;
    }
    
    /**
     * Normalizes SQL for logging purposes.
     */
    private String normalizeForLogging(String sql) {
        return sql.toUpperCase()
            .replaceAll("\\s+", " ")
            .trim()
            .substring(0, Math.min(sql.length(), 80));
    }
    
    /**
     * Inner class representing cursor state.
     */
    public static class CursorState {
        private final String name;
        private boolean open;
        private int currentRow;
        private int totalRows;
        
        public CursorState(String name) {
            this.name = name;
            this.open = false;
            this.currentRow = -1;
            this.totalRows = 0;
        }
        
        public void open(int rows) {
            this.open = true;
            this.currentRow = -1;
            this.totalRows = rows;
        }
        
        public boolean fetch() {
            if (!open) return false;
            currentRow++;
            return currentRow < totalRows;
        }
        
        public void close() {
            this.open = false;
            this.currentRow = -1;
        }
        
        public void reset() {
            this.open = false;
            this.currentRow = -1;
            this.totalRows = 0;
        }
        
        public boolean isOpen() { return open; }
        public int getCurrentRow() { return currentRow; }
        public int getTotalRows() { return totalRows; }
        public String getName() { return name; }
        public boolean hasMoreRows() { return open && currentRow < totalRows - 1; }
    }
    
    /**
     * Enum for verification comparison types.
     */
    public enum VerificationComparison {
        EXACTLY("exactly"),
        AT_LEAST("at least"),
        AT_MOST("at most"),
        NEVER("never");
        
        private final String description;
        
        VerificationComparison(String description) {
            this.description = description;
        }
        
        public String getDescription() {
            return description;
        }
    }
    
    /**
     * Result of a mock verification.
     */
    public static class VerificationResult {
        private final boolean passed;
        private final String message;
        
        public VerificationResult(boolean passed, String message) {
            this.passed = passed;
            this.message = message;
        }
        
        public boolean passed() { return passed; }
        public String getMessage() { return message; }
    }
}
