# CICS Mock Framework for COBOL Check

## Overview

This framework enables unit testing of CICS programs without requiring a live CICS region.

## Supported Commands

### File Control
- READ, WRITE, REWRITE, DELETE
- STARTBR, READNEXT, READPREV, RESETBR, ENDBR

### Program Control
- LINK, XCTL, RETURN

### Terminal Control
- SEND, RECEIVE, SEND MAP, RECEIVE MAP

### Temporary Storage
- WRITEQ TS, READQ TS, DELETEQ TS

### Transient Data
- WRITEQ TD, READQ TD

## Syntax

```cobol
MOCK EXEC CICS <command> <options>
    [RETURNS RESP(<dfhresp-value>)]
    [RETURNS RESP2(<value>)]
    [WITH DATA
        <field> = <value>
    END-DATA]
END-MOCK
```

## DFHRESP Values

| Code | Value | Description |
|------|-------|-------------|
| NORMAL | 0 | Success |
| NOTFND | 13 | Not found |
| DUPREC | 14 | Duplicate |
| ENDFILE | 20 | End of browse |
| QZERO | 23 | Queue empty |
| PGMIDERR | 27 | Program not found |
