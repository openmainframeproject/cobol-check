# CICS Mock Framework for COBOL Check

Mock CICS commands in unit tests without a live CICS region.

## Features

- File Control: READ, WRITE, REWRITE, DELETE, BROWSE
- Program Control: LINK, XCTL, RETURN  
- Terminal Control: SEND/RECEIVE MAP
- Temporary Storage: WRITEQ/READQ TS
- Full DFHRESP support

## Quick Example

```cobol
MOCK EXEC CICS READ FILE('CUSTFILE') INTO(WS-REC)
    RETURNS RESP(DFHRESP(NORMAL))
    WITH DATA
        CUST-ID = "C00001"
        CUST-NAME = "ACME CORP"
    END-DATA
END-MOCK

PERFORM 2000-READ-CUSTOMER

EXPECT WS-CUST-NAME TO BE "ACME CORP"
VERIFY EXEC CICS READ FILE('CUSTFILE') HAPPENED ONCE
```

## Project Structure

```
src/main/java/.../cics/
├── CICSCommandType.java
├── CICSResponseCode.java
├── CICSMockDataRow.java
├── CICSMockDefinition.java
├── CICSMockRepository.java
├── CICSMockParser.java
└── CICSMockCodeGenerator.java
```

## License

Apache 2.0
