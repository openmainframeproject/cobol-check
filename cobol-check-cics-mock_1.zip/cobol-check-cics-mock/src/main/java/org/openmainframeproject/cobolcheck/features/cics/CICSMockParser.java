package org.openmainframeproject.cobolcheck.features.cics;

import java.util.*;

/**
 * Parser for CICS mock syntax in COBOL Check test suites.
 */
public class CICSMockParser {
    
    private final CICSMockRepository repository;
    private List<String> tokens;
    private int currentIndex;
    private String currentTestFile;
    private int currentLine;
    
    public CICSMockParser(CICSMockRepository repository) {
        this.repository = repository;
    }
    
    public void setCurrentTestFile(String testFile) { this.currentTestFile = testFile; }
    public void setCurrentLine(int line) { this.currentLine = line; }
    
    public boolean isCICSMockStart(List<String> tokens, int index) {
        if (index + 2 >= tokens.size()) return false;
        return "MOCK".equalsIgnoreCase(tokens.get(index)) &&
               "EXEC".equalsIgnoreCase(tokens.get(index + 1)) &&
               "CICS".equalsIgnoreCase(tokens.get(index + 2));
    }
    
    public boolean isCICSVerify(List<String> tokens, int index) {
        if (index + 2 >= tokens.size()) return false;
        return "VERIFY".equalsIgnoreCase(tokens.get(index)) &&
               "EXEC".equalsIgnoreCase(tokens.get(index + 1)) &&
               "CICS".equalsIgnoreCase(tokens.get(index + 2));
    }
    
    public ParseResult parseMock(List<String> tokens, int startIndex) throws CICSMockParseException {
        this.tokens = tokens;
        this.currentIndex = startIndex;
        
        expect("MOCK"); expect("EXEC"); expect("CICS");
        
        String cicsCommand = parseCICSCommand();
        String mockId = repository.generateMockId();
        CICSMockDefinition mock = new CICSMockDefinition(mockId, cicsCommand);
        mock.setSourceFile(currentTestFile);
        mock.setSourceLine(currentLine);
        
        while (currentIndex < tokens.size()) {
            String token = peekToken();
            if ("RETURNS".equalsIgnoreCase(token)) parseReturns(mock);
            else if ("WITH".equalsIgnoreCase(token)) parseWithData(mock);
            else if ("END-MOCK".equalsIgnoreCase(token)) { consumeToken(); break; }
            else throw new CICSMockParseException("Unexpected token '" + token + "' at " + getLocation());
        }
        
        repository.addMock(mock);
        return new ParseResult(mock, currentIndex);
    }
    
    public VerifyParseResult parseVerify(List<String> tokens, int startIndex) throws CICSMockParseException {
        this.tokens = tokens;
        this.currentIndex = startIndex;
        
        expect("VERIFY"); expect("EXEC"); expect("CICS");
        String commandPattern = parseCICSCommand();
        
        int expectedCount = 1;
        CICSMockRepository.VerificationComparison comparison = CICSMockRepository.VerificationComparison.EXACTLY;
        
        if (matchToken("HAPPENED")) {
            if (matchToken("NEVER")) { expectedCount = 0; comparison = CICSMockRepository.VerificationComparison.NEVER; }
            else if (matchToken("ONCE")) expectedCount = 1;
            else if (matchToken("TWICE")) expectedCount = 2;
            else if (matchToken("AT")) {
                if (matchToken("LEAST")) comparison = CICSMockRepository.VerificationComparison.AT_LEAST;
                else if (matchToken("MOST")) comparison = CICSMockRepository.VerificationComparison.AT_MOST;
                expectedCount = parseNumber();
                matchToken("TIMES");
            } else {
                expectedCount = parseNumber();
                matchToken("TIMES");
            }
        }
        return new VerifyParseResult(commandPattern, expectedCount, comparison, currentIndex);
    }
    
    private String parseCICSCommand() throws CICSMockParseException {
        StringBuilder command = new StringBuilder();
        int parenDepth = 0;
        
        while (currentIndex < tokens.size()) {
            String token = peekToken();
            parenDepth += countChar(token, '(') - countChar(token, ')');
            if (parenDepth == 0 && isStopKeyword(token)) break;
            if (command.length() > 0) command.append(" ");
            command.append(consumeToken());
        }
        if (command.length() == 0) throw new CICSMockParseException("Empty CICS command at " + getLocation());
        return command.toString();
    }
    
    private void parseReturns(CICSMockDefinition mock) throws CICSMockParseException {
        expect("RETURNS");
        String returnType = consumeToken().toUpperCase();
        
        switch (returnType) {
            case "RESP" -> { expect("("); mock.setResp(parseRespValue()); expect(")"); }
            case "RESP2" -> { expect("("); mock.setResp2(parseNumber()); expect(")"); }
            case "LENGTH" -> { expect("("); mock.setReturnLength(parseNumber()); expect(")"); }
            case "ITEM" -> { expect("("); mock.setReturnItem(parseNumber()); expect(")"); }
            default -> throw new CICSMockParseException("Unknown RETURNS type '" + returnType + "' at " + getLocation());
        }
    }
    
    private String parseRespValue() throws CICSMockParseException {
        StringBuilder value = new StringBuilder();
        String token = consumeToken();
        value.append(token);
        if (token.equalsIgnoreCase("DFHRESP")) {
            expect("("); value.append("(").append(consumeToken()).append(")"); expect(")");
        }
        return value.toString();
    }
    
    private void parseWithData(CICSMockDefinition mock) throws CICSMockParseException {
        expect("WITH"); expect("DATA");
        CICSMockDataRow currentRow = new CICSMockDataRow();
        boolean inRow = false;
        
        while (currentIndex < tokens.size()) {
            String token = peekToken();
            if ("END-DATA".equalsIgnoreCase(token)) {
                consumeToken();
                if (currentRow.getFieldCount() > 0 || currentRow.hasRowResp()) mock.addDataRow(currentRow);
                break;
            }
            if ("ROW".equalsIgnoreCase(token)) {
                if (inRow && (currentRow.getFieldCount() > 0 || currentRow.hasRowResp())) mock.addDataRow(currentRow);
                consumeToken(); parseNumber();
                currentRow = new CICSMockDataRow();
                inRow = true;
                continue;
            }
            if ("END-ROW".equalsIgnoreCase(token)) {
                consumeToken();
                if (currentRow.getFieldCount() > 0 || currentRow.hasRowResp()) mock.addDataRow(currentRow);
                currentRow = new CICSMockDataRow();
                inRow = false;
                continue;
            }
            if ("RESP".equalsIgnoreCase(token)) {
                consumeToken(); expect("=");
                currentRow.setRowResp(parseRespValue());
                continue;
            }
            String fieldName = consumeToken();
            expect("=");
            currentRow.setFieldValue(fieldName, parseFieldValue());
        }
    }
    
    private String parseFieldValue() throws CICSMockParseException {
        String token = peekToken();
        if ("DFHRESP".equalsIgnoreCase(token)) return parseRespValue();
        if (token.startsWith("\"") || token.startsWith("'")) return parseStringValue();
        if (token.equals("-") || token.matches("-?\\d.*")) return parseNumericValue();
        return consumeToken();
    }
    
    private String parseStringValue() throws CICSMockParseException {
        String token = consumeToken();
        if (token.startsWith("\"") || token.startsWith("'")) {
            char quote = token.charAt(0);
            if (token.length() > 1 && token.endsWith(String.valueOf(quote)))
                return token.substring(1, token.length() - 1);
            StringBuilder sb = new StringBuilder(token.substring(1));
            while (currentIndex < tokens.size()) {
                String next = consumeToken();
                if (next.endsWith(String.valueOf(quote))) {
                    sb.append(" ").append(next, 0, next.length() - 1);
                    break;
                }
                sb.append(" ").append(next);
            }
            return sb.toString();
        }
        return token;
    }
    
    private String parseNumericValue() throws CICSMockParseException {
        StringBuilder sb = new StringBuilder();
        if (peekToken().equals("-")) sb.append(consumeToken());
        sb.append(consumeToken());
        return sb.toString();
    }
    
    private int parseNumber() throws CICSMockParseException {
        try { return Integer.parseInt(consumeToken()); }
        catch (NumberFormatException e) { throw new CICSMockParseException("Expected number at " + getLocation()); }
    }
    
    private boolean isStopKeyword(String token) {
        String upper = token.toUpperCase();
        return upper.equals("RETURNS") || upper.equals("WITH") || upper.equals("END-MOCK") || upper.equals("HAPPENED");
    }
    
    private int countChar(String str, char c) {
        int count = 0;
        for (char ch : str.toCharArray()) if (ch == c) count++;
        return count;
    }
    
    private void expect(String expected) throws CICSMockParseException {
        String actual = consumeToken();
        if (!expected.equalsIgnoreCase(actual) && !expected.equals(actual))
            throw new CICSMockParseException("Expected '" + expected + "', got '" + actual + "' at " + getLocation());
    }
    
    private boolean matchToken(String expected) {
        if (currentIndex < tokens.size() && expected.equalsIgnoreCase(peekToken())) {
            consumeToken();
            return true;
        }
        return false;
    }
    
    private String peekToken() { return currentIndex >= tokens.size() ? "" : tokens.get(currentIndex); }
    private String consumeToken() throws CICSMockParseException {
        if (currentIndex >= tokens.size()) throw new CICSMockParseException("Unexpected end of input at " + getLocation());
        return tokens.get(currentIndex++);
    }
    private String getLocation() { return currentTestFile != null ? currentTestFile + ":" + currentLine : "line " + currentLine; }
    
    public record ParseResult(CICSMockDefinition mock, int endIndex) {}
    public record VerifyParseResult(String commandPattern, int expectedCount,
                                     CICSMockRepository.VerificationComparison comparison, int endIndex) {}
    
    public static class CICSMockParseException extends Exception {
        public CICSMockParseException(String message) { super(message); }
    }
}
