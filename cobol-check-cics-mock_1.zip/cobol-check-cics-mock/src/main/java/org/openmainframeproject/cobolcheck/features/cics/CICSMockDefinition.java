package org.openmainframeproject.cobolcheck.features.cics;

import java.util.*;
import java.util.regex.Pattern;

/**
 * Represents a complete CICS mock definition parsed from a test suite.
 */
public class CICSMockDefinition {
    
    private final String id;
    private final CICSCommandType commandType;
    private final String rawCommand;
    private final Map<String, String> options;
    private final Set<String> flags;
    private final List<CICSMockDataRow> dataRows;
    
    private CICSResponseCode resp;
    private int resp2;
    private int returnLength;
    private int returnItem;
    private int invocationCount;
    private String sourceFile;
    private int sourceLine;
    
    public CICSMockDefinition(String id, String rawCommand) {
        if (id == null || id.trim().isEmpty()) {
            throw new IllegalArgumentException("Mock ID cannot be null or empty");
        }
        if (rawCommand == null || rawCommand.trim().isEmpty()) {
            throw new IllegalArgumentException("CICS command cannot be null or empty");
        }
        
        this.id = id;
        this.rawCommand = normalizeCommand(rawCommand);
        this.commandType = CICSCommandType.fromCommand(this.rawCommand);
        this.options = new LinkedHashMap<>();
        this.flags = new HashSet<>();
        this.dataRows = new ArrayList<>();
        this.resp = CICSResponseCode.NORMAL;
        this.resp2 = 0;
        this.returnLength = -1;
        this.returnItem = -1;
        this.invocationCount = 0;
        
        parseOptions(this.rawCommand);
    }
    
    public String getId() { return id; }
    public CICSCommandType getCommandType() { return commandType; }
    public String getRawCommand() { return rawCommand; }
    
    public String getOption(String optionName) {
        return options.get(optionName.toUpperCase());
    }
    public void setOption(String optionName, String optionValue) {
        options.put(optionName.toUpperCase(), optionValue);
    }
    public Map<String, String> getOptions() { return Collections.unmodifiableMap(options); }
    
    public boolean hasFlag(String flagName) { return flags.contains(flagName.toUpperCase()); }
    public void addFlag(String flagName) { flags.add(flagName.toUpperCase()); }
    public Set<String> getFlags() { return Collections.unmodifiableSet(flags); }
    
    public String getPrimaryIdentifier() {
        String primaryOption = commandType.getPrimaryOption();
        return primaryOption != null ? getOption(primaryOption) : null;
    }
    
    public CICSResponseCode getResp() { return resp; }
    public void setResp(CICSResponseCode resp) { this.resp = resp != null ? resp : CICSResponseCode.NORMAL; }
    public void setResp(String respValue) { this.resp = CICSResponseCode.parse(respValue); }
    
    public int getResp2() { return resp2; }
    public void setResp2(int resp2) { this.resp2 = resp2; }
    
    public int getReturnLength() { return returnLength; }
    public void setReturnLength(int length) { this.returnLength = length; }
    
    public int getReturnItem() { return returnItem; }
    public void setReturnItem(int item) { this.returnItem = item; }
    
    public void addDataRow(CICSMockDataRow row) { if (row != null) dataRows.add(row); }
    public List<CICSMockDataRow> getDataRows() { return new ArrayList<>(dataRows); }
    public CICSMockDataRow getDataRow(int index) {
        return (index >= 0 && index < dataRows.size()) ? dataRows.get(index) : null;
    }
    public int getRowCount() { return dataRows.size(); }
    
    public boolean matches(String actualCommand) {
        if (actualCommand == null || actualCommand.trim().isEmpty()) return false;
        
        String normalizedActual = normalizeCommand(actualCommand);
        CICSCommandType actualType = CICSCommandType.fromCommand(normalizedActual);
        
        if (actualType != commandType) return false;
        
        String primaryOption = commandType.getPrimaryOption();
        if (primaryOption != null) {
            String expectedValue = getOption(primaryOption);
            String actualValue = extractOptionValue(normalizedActual, primaryOption);
            if (expectedValue != null && !matchOptionValue(expectedValue, actualValue)) {
                return false;
            }
        }
        return true;
    }
    
    public void recordInvocation() { invocationCount++; }
    public int getInvocationCount() { return invocationCount; }
    public void resetInvocationCount() { invocationCount = 0; }
    
    public void setSourceFile(String sourceFile) { this.sourceFile = sourceFile; }
    public void setSourceLine(int sourceLine) { this.sourceLine = sourceLine; }
    public String getSourceLocation() {
        return sourceFile != null ? sourceFile + ":" + sourceLine : "line " + sourceLine;
    }
    
    private String normalizeCommand(String command) {
        String normalized = command.toUpperCase().replaceAll("\\s+", " ").trim();
        if (normalized.startsWith("EXEC CICS ")) normalized = normalized.substring(10);
        if (normalized.endsWith(" END-EXEC")) normalized = normalized.substring(0, normalized.length() - 9);
        if (normalized.endsWith("END-EXEC")) normalized = normalized.substring(0, normalized.length() - 8);
        return normalized.trim();
    }
    
    private void parseOptions(String command) {
        Pattern optionPattern = Pattern.compile("([A-Z][A-Z0-9]*)(?:\\(([^)]+)\\)|(?=\\s|$))");
        var matcher = optionPattern.matcher(command);
        boolean isFirst = true;
        
        while (matcher.find()) {
            String name = matcher.group(1);
            String value = matcher.group(2);
            if (isFirst) { isFirst = false; continue; }
            if (value != null) {
                options.put(name, value.replaceAll("^['\"]|['\"]$", ""));
            } else {
                flags.add(name);
            }
        }
    }
    
    private String extractOptionValue(String command, String optionName) {
        Pattern pattern = Pattern.compile(optionName + "\\s*\\(\\s*([^)]+)\\s*\\)", Pattern.CASE_INSENSITIVE);
        var matcher = pattern.matcher(command);
        if (matcher.find()) {
            return matcher.group(1).replaceAll("^['\"]|['\"]$", "").trim();
        }
        return null;
    }
    
    private boolean matchOptionValue(String expected, String actual) {
        if (expected == null && actual == null) return true;
        if (expected == null || actual == null) return false;
        return expected.replaceAll("^['\"]|['\"]$", "").equalsIgnoreCase(
               actual.replaceAll("^['\"]|['\"]$", ""));
    }
    
    @Override
    public String toString() {
        return String.format("CICSMockDefinition{id='%s', type=%s, primary='%s', resp=%s, rows=%d}",
            id, commandType, getPrimaryIdentifier(), resp.name(), dataRows.size());
    }
}
