package org.openmainframeproject.cobolcheck.features.cics;

/**
 * Enumeration of CICS command types that can be mocked.
 * Organized by functional category for clarity.
 */
public enum CICSCommandType {
    
    // FILE CONTROL
    READ("READ", CICSCategory.FILE_CONTROL, true),
    WRITE("WRITE", CICSCategory.FILE_CONTROL, false),
    REWRITE("REWRITE", CICSCategory.FILE_CONTROL, false),
    DELETE("DELETE", CICSCategory.FILE_CONTROL, false),
    UNLOCK("UNLOCK", CICSCategory.FILE_CONTROL, false),
    STARTBR("STARTBR", CICSCategory.FILE_CONTROL, false),
    READNEXT("READNEXT", CICSCategory.FILE_CONTROL, true),
    READPREV("READPREV", CICSCategory.FILE_CONTROL, true),
    RESETBR("RESETBR", CICSCategory.FILE_CONTROL, false),
    ENDBR("ENDBR", CICSCategory.FILE_CONTROL, false),
    
    // PROGRAM CONTROL
    LINK("LINK", CICSCategory.PROGRAM_CONTROL, true),
    XCTL("XCTL", CICSCategory.PROGRAM_CONTROL, false),
    RETURN("RETURN", CICSCategory.PROGRAM_CONTROL, false),
    LOAD("LOAD", CICSCategory.PROGRAM_CONTROL, true),
    RELEASE("RELEASE", CICSCategory.PROGRAM_CONTROL, false),
    
    // TERMINAL CONTROL
    SEND("SEND", CICSCategory.TERMINAL_CONTROL, false),
    RECEIVE("RECEIVE", CICSCategory.TERMINAL_CONTROL, true),
    SEND_MAP("SEND MAP", CICSCategory.TERMINAL_CONTROL, false),
    RECEIVE_MAP("RECEIVE MAP", CICSCategory.TERMINAL_CONTROL, true),
    SEND_CONTROL("SEND CONTROL", CICSCategory.TERMINAL_CONTROL, false),
    SEND_TEXT("SEND TEXT", CICSCategory.TERMINAL_CONTROL, false),
    CONVERSE("CONVERSE", CICSCategory.TERMINAL_CONTROL, true),
    
    // TEMPORARY STORAGE
    WRITEQ_TS("WRITEQ TS", CICSCategory.TEMPORARY_STORAGE, false),
    READQ_TS("READQ TS", CICSCategory.TEMPORARY_STORAGE, true),
    DELETEQ_TS("DELETEQ TS", CICSCategory.TEMPORARY_STORAGE, false),
    
    // TRANSIENT DATA
    WRITEQ_TD("WRITEQ TD", CICSCategory.TRANSIENT_DATA, false),
    READQ_TD("READQ TD", CICSCategory.TRANSIENT_DATA, true),
    DELETEQ_TD("DELETEQ TD", CICSCategory.TRANSIENT_DATA, false),
    
    // STORAGE CONTROL
    GETMAIN("GETMAIN", CICSCategory.STORAGE_CONTROL, true),
    FREEMAIN("FREEMAIN", CICSCategory.STORAGE_CONTROL, false),
    
    // INTERVAL CONTROL
    START("START", CICSCategory.INTERVAL_CONTROL, false),
    RETRIEVE("RETRIEVE", CICSCategory.INTERVAL_CONTROL, true),
    CANCEL("CANCEL", CICSCategory.INTERVAL_CONTROL, false),
    DELAY("DELAY", CICSCategory.INTERVAL_CONTROL, false),
    ASKTIME("ASKTIME", CICSCategory.INTERVAL_CONTROL, true),
    FORMATTIME("FORMATTIME", CICSCategory.INTERVAL_CONTROL, true),
    
    // CONTAINER/CHANNEL
    PUT_CONTAINER("PUT CONTAINER", CICSCategory.CONTAINER, false),
    GET_CONTAINER("GET CONTAINER", CICSCategory.CONTAINER, true),
    DELETE_CONTAINER("DELETE CONTAINER", CICSCategory.CONTAINER, false),
    MOVE_CONTAINER("MOVE CONTAINER", CICSCategory.CONTAINER, false),
    
    // SYNCPOINT
    SYNCPOINT("SYNCPOINT", CICSCategory.SYNCPOINT, false),
    SYNCPOINT_ROLLBACK("SYNCPOINT ROLLBACK", CICSCategory.SYNCPOINT, false),
    
    // EXCEPTION HANDLING
    HANDLE_CONDITION("HANDLE CONDITION", CICSCategory.EXCEPTION, false),
    HANDLE_ABEND("HANDLE ABEND", CICSCategory.EXCEPTION, false),
    IGNORE_CONDITION("IGNORE CONDITION", CICSCategory.EXCEPTION, false),
    ABEND("ABEND", CICSCategory.EXCEPTION, false),
    
    // INQUIRY
    ASSIGN("ASSIGN", CICSCategory.INQUIRY, true),
    ADDRESS("ADDRESS", CICSCategory.INQUIRY, true),
    INQUIRE("INQUIRE", CICSCategory.INQUIRY, true),
    
    // UNKNOWN
    UNKNOWN("UNKNOWN", CICSCategory.UNKNOWN, false);
    
    private final String keyword;
    private final CICSCategory category;
    private final boolean returnsData;
    
    CICSCommandType(String keyword, CICSCategory category, boolean returnsData) {
        this.keyword = keyword;
        this.category = category;
        this.returnsData = returnsData;
    }
    
    public String getKeyword() { return keyword; }
    public CICSCategory getCategory() { return category; }
    public boolean returnsData() { return returnsData; }
    
    public static CICSCommandType fromCommand(String command) {
        if (command == null || command.trim().isEmpty()) {
            return UNKNOWN;
        }
        
        String normalized = command.trim().toUpperCase();
        
        // Handle two-word commands first
        if (normalized.startsWith("SEND MAP")) return SEND_MAP;
        if (normalized.startsWith("RECEIVE MAP")) return RECEIVE_MAP;
        if (normalized.startsWith("SEND CONTROL")) return SEND_CONTROL;
        if (normalized.startsWith("SEND TEXT")) return SEND_TEXT;
        if (normalized.startsWith("WRITEQ TS")) return WRITEQ_TS;
        if (normalized.startsWith("READQ TS")) return READQ_TS;
        if (normalized.startsWith("DELETEQ TS")) return DELETEQ_TS;
        if (normalized.startsWith("WRITEQ TD")) return WRITEQ_TD;
        if (normalized.startsWith("READQ TD")) return READQ_TD;
        if (normalized.startsWith("DELETEQ TD")) return DELETEQ_TD;
        if (normalized.startsWith("PUT CONTAINER")) return PUT_CONTAINER;
        if (normalized.startsWith("GET CONTAINER")) return GET_CONTAINER;
        if (normalized.startsWith("DELETE CONTAINER")) return DELETE_CONTAINER;
        if (normalized.startsWith("MOVE CONTAINER")) return MOVE_CONTAINER;
        if (normalized.startsWith("SYNCPOINT ROLLBACK")) return SYNCPOINT_ROLLBACK;
        if (normalized.startsWith("HANDLE CONDITION")) return HANDLE_CONDITION;
        if (normalized.startsWith("HANDLE ABEND")) return HANDLE_ABEND;
        if (normalized.startsWith("IGNORE CONDITION")) return IGNORE_CONDITION;
        
        String firstWord = normalized.split("\\s+")[0];
        for (CICSCommandType type : values()) {
            if (type.keyword.equals(firstWord)) {
                return type;
            }
        }
        return UNKNOWN;
    }
    
    public String getPrimaryOption() {
        switch (this) {
            case READ: case WRITE: case REWRITE: case DELETE: case UNLOCK:
            case STARTBR: case READNEXT: case READPREV: case RESETBR: case ENDBR:
                return "FILE";
            case LINK: case XCTL: case LOAD: case RELEASE:
                return "PROGRAM";
            case WRITEQ_TS: case READQ_TS: case DELETEQ_TS:
            case WRITEQ_TD: case READQ_TD: case DELETEQ_TD:
                return "QUEUE";
            case SEND_MAP: case RECEIVE_MAP:
                return "MAP";
            case PUT_CONTAINER: case GET_CONTAINER: case DELETE_CONTAINER: case MOVE_CONTAINER:
                return "CONTAINER";
            case START: case CANCEL:
                return "TRANSID";
            default:
                return null;
        }
    }
    
    public boolean isBrowseOperation() {
        return this == STARTBR || this == READNEXT || this == READPREV ||
               this == RESETBR || this == ENDBR;
    }
    
    public boolean modifiesData() {
        return this == WRITE || this == REWRITE || this == DELETE ||
               this == WRITEQ_TS || this == WRITEQ_TD || this == PUT_CONTAINER;
    }
    
    public enum CICSCategory {
        FILE_CONTROL, PROGRAM_CONTROL, TERMINAL_CONTROL,
        TEMPORARY_STORAGE, TRANSIENT_DATA, STORAGE_CONTROL,
        INTERVAL_CONTROL, CONTAINER, SYNCPOINT, EXCEPTION,
        INQUIRY, UNKNOWN
    }
}
