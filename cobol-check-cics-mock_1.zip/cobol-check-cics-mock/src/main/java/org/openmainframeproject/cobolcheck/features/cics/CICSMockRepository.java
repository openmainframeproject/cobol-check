package org.openmainframeproject.cobolcheck.features.cics;

import java.util.*;

/**
 * Repository for managing CICS mock definitions.
 */
public class CICSMockRepository {
    
    private final List<CICSMockDefinition> mocks;
    private final Map<String, BrowseState> browseStates;
    private final Map<String, TSQueueState> tsQueueStates;
    private final Map<String, Integer> unmockedCommands;
    private int mockIdCounter;
    private boolean logUnmocked;
    
    public CICSMockRepository() {
        this.mocks = new ArrayList<>();
        this.browseStates = new HashMap<>();
        this.tsQueueStates = new HashMap<>();
        this.unmockedCommands = new LinkedHashMap<>();
        this.mockIdCounter = 0;
        this.logUnmocked = true;
    }
    
    public String generateMockId() {
        return String.format("CICS-MOCK-%03d", ++mockIdCounter);
    }
    
    public void addMock(CICSMockDefinition mock) {
        if (mock == null) return;
        mocks.add(mock);
        
        if (mock.getCommandType().isBrowseOperation()) {
            String fileName = mock.getOption("FILE");
            if (fileName != null && !browseStates.containsKey(fileName)) {
                browseStates.put(fileName, new BrowseState(fileName));
            }
        }
        if (mock.getCommandType() == CICSCommandType.WRITEQ_TS ||
            mock.getCommandType() == CICSCommandType.READQ_TS) {
            String queueName = mock.getOption("QUEUE");
            if (queueName != null && !tsQueueStates.containsKey(queueName)) {
                tsQueueStates.put(queueName, new TSQueueState(queueName));
            }
        }
    }
    
    public CICSMockDefinition findMock(String actualCommand) {
        if (actualCommand == null || actualCommand.trim().isEmpty()) return null;
        
        for (int i = mocks.size() - 1; i >= 0; i--) {
            if (mocks.get(i).matches(actualCommand)) return mocks.get(i);
        }
        
        if (logUnmocked) {
            String normalized = actualCommand.toUpperCase().replaceAll("\\s+", " ").trim();
            normalized = normalized.substring(0, Math.min(normalized.length(), 60));
            unmockedCommands.merge(normalized, 1, Integer::sum);
        }
        return null;
    }
    
    public List<CICSMockDefinition> getAllMocks() { return Collections.unmodifiableList(mocks); }
    public int getMockCount() { return mocks.size(); }
    
    public CICSMockDefinition findById(String id) {
        return mocks.stream().filter(m -> m.getId().equals(id)).findFirst().orElse(null);
    }
    
    // Browse state management
    public BrowseState getBrowseState(String fileName) {
        return browseStates.get(fileName.toUpperCase());
    }
    
    public void startBrowse(String fileName, int totalRows) {
        String name = fileName.toUpperCase();
        BrowseState state = browseStates.computeIfAbsent(name, BrowseState::new);
        state.start(totalRows);
    }
    
    public int browseNext(String fileName) {
        BrowseState state = browseStates.get(fileName.toUpperCase());
        return (state != null && state.isActive()) ? state.next() : -1;
    }
    
    public void endBrowse(String fileName) {
        BrowseState state = browseStates.get(fileName.toUpperCase());
        if (state != null) state.end();
    }
    
    // TS Queue management
    public int getNextTSQueueItem(String queueName) {
        String name = queueName.toUpperCase();
        TSQueueState state = tsQueueStates.computeIfAbsent(name, TSQueueState::new);
        return state.nextItem();
    }
    
    // Verification
    public VerificationResult verify(String commandPattern, int expectedCount, VerificationComparison comparison) {
        CICSMockDefinition mock = findMockByPattern(commandPattern);
        if (mock == null) {
            return new VerificationResult(false, "No mock found for pattern: " + commandPattern);
        }
        
        int actualCount = mock.getInvocationCount();
        boolean passed = switch (comparison) {
            case EXACTLY -> actualCount == expectedCount;
            case AT_LEAST -> actualCount >= expectedCount;
            case AT_MOST -> actualCount <= expectedCount;
            case NEVER -> actualCount == 0;
        };
        
        String message = passed
            ? String.format("PASS: CICS mock '%s' was invoked %d time(s)", mock.getId(), actualCount)
            : String.format("FAIL: CICS mock '%s' expected %s %d, actual %d",
                mock.getId(), comparison.getDescription(), expectedCount, actualCount);
        
        return new VerificationResult(passed, message);
    }
    
    private CICSMockDefinition findMockByPattern(String pattern) {
        String normalizedPattern = pattern.toUpperCase().trim();
        for (CICSMockDefinition mock : mocks) {
            if (mock.getRawCommand().contains(normalizedPattern)) return mock;
        }
        CICSCommandType type = CICSCommandType.fromCommand(normalizedPattern);
        for (CICSMockDefinition mock : mocks) {
            if (mock.getCommandType() == type) return mock;
        }
        return null;
    }
    
    public void resetInvocationCounts() { mocks.forEach(CICSMockDefinition::resetInvocationCount); }
    public void resetStates() {
        browseStates.values().forEach(BrowseState::reset);
        tsQueueStates.values().forEach(TSQueueState::reset);
    }
    public void clearAll() {
        mocks.clear();
        browseStates.clear();
        tsQueueStates.clear();
        unmockedCommands.clear();
        mockIdCounter = 0;
    }
    
    public Map<String, Integer> getUnmockedCommandsReport() { return Collections.unmodifiableMap(unmockedCommands); }
    public boolean hasUnmockedCommands() { return !unmockedCommands.isEmpty(); }
    public void setLogUnmocked(boolean log) { this.logUnmocked = log; }
    
    // Inner classes
    public static class BrowseState {
        private final String fileName;
        private boolean active;
        private int currentRow, totalRows;
        
        public BrowseState(String fileName) { this.fileName = fileName; reset(); }
        public void start(int rows) { active = true; currentRow = -1; totalRows = rows; }
        public void end() { active = false; }
        public void reset() { active = false; currentRow = -1; totalRows = 0; }
        public int next() { return active && ++currentRow < totalRows ? currentRow : -1; }
        public boolean isActive() { return active; }
        public int getCurrentRow() { return currentRow; }
        public String getFileName() { return fileName; }
    }
    
    public static class TSQueueState {
        private final String queueName;
        private int itemCount;
        
        public TSQueueState(String queueName) { this.queueName = queueName; }
        public int nextItem() { return ++itemCount; }
        public int getItemCount() { return itemCount; }
        public void reset() { itemCount = 0; }
    }
    
    public enum VerificationComparison {
        EXACTLY("exactly"), AT_LEAST("at least"), AT_MOST("at most"), NEVER("never");
        private final String description;
        VerificationComparison(String description) { this.description = description; }
        public String getDescription() { return description; }
    }
    
    public record VerificationResult(boolean passed, String message) {}
}
