package org.openmainframeproject.cobolcheck.features.cics;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

/**
 * Represents a single row of mock data for CICS command responses.
 */
public class CICSMockDataRow {
    
    private final Map<String, String> fieldValues;
    private CICSResponseCode rowResp;
    private int rowResp2;
    private boolean hasRowResp;
    private int returnLength;
    private boolean hasReturnLength;
    
    public CICSMockDataRow() {
        this.fieldValues = new LinkedHashMap<>();
        this.rowResp = CICSResponseCode.NORMAL;
        this.rowResp2 = 0;
        this.hasRowResp = false;
        this.returnLength = 0;
        this.hasReturnLength = false;
    }
    
    public CICSMockDataRow(CICSResponseCode resp) {
        this();
        this.rowResp = resp;
        this.hasRowResp = true;
    }
    
    public void setFieldValue(String fieldName, String fieldValue) {
        if (fieldName == null || fieldName.trim().isEmpty()) {
            throw new IllegalArgumentException("Field name cannot be null or empty");
        }
        fieldValues.put(fieldName.trim().toUpperCase(), fieldValue);
    }
    
    public String getFieldValue(String fieldName) {
        return fieldValues.get(fieldName.trim().toUpperCase());
    }
    
    public boolean hasField(String fieldName) {
        return fieldValues.containsKey(fieldName.trim().toUpperCase());
    }
    
    public Set<String> getFieldNames() { return fieldValues.keySet(); }
    public int getFieldCount() { return fieldValues.size(); }
    public Map<String, String> getAllFieldValues() { return Map.copyOf(fieldValues); }
    
    public CICSResponseCode getRowResp() { return rowResp; }
    public void setRowResp(CICSResponseCode resp) {
        this.rowResp = resp;
        this.hasRowResp = true;
    }
    public void setRowResp(String respValue) {
        this.rowResp = CICSResponseCode.parse(respValue);
        this.hasRowResp = true;
    }
    public boolean hasRowResp() { return hasRowResp; }
    
    public int getRowResp2() { return rowResp2; }
    public void setRowResp2(int resp2) { this.rowResp2 = resp2; }
    
    public int getReturnLength() { return returnLength; }
    public void setReturnLength(int length) {
        this.returnLength = length;
        this.hasReturnLength = true;
    }
    public boolean hasReturnLength() { return hasReturnLength; }
    
    public boolean isEndCondition() { return hasRowResp && rowResp.isNotFound(); }
    public boolean isError() { return hasRowResp && !rowResp.isSuccess() && !rowResp.isNotFound(); }
    
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("CICSMockDataRow{");
        if (hasRowResp) sb.append("resp=").append(rowResp.name()).append(", ");
        if (hasReturnLength) sb.append("length=").append(returnLength).append(", ");
        sb.append("fields=").append(fieldValues).append("}");
        return sb.toString();
    }
}
