package org.openmainframeproject.cobolcheck.features.cics;

import java.util.HashMap;
import java.util.Map;

/**
 * CICS response codes (DFHRESP values).
 */
public enum CICSResponseCode {
    
    NORMAL(0, "Normal completion"),
    ERROR(1, "General error condition"),
    RDATT(2, "Read attention identifier"),
    WRBRK(3, "Write break"),
    EOF(4, "End of file"),
    EODS(5, "End of data set"),
    EOC(6, "End of chain"),
    INBFMH(7, "Inbound FMH received"),
    ENDINPT(8, "End of input"),
    NONVAL(9, "Non-valid request"),
    NOSTART(10, "No start"),
    TERMIDERR(11, "Terminal ID error"),
    FILENOTFOUND(12, "File not found"),
    NOTFND(13, "Record not found"),
    DUPREC(14, "Duplicate record"),
    DUPKEY(15, "Duplicate key"),
    INVREQ(16, "Invalid request"),
    IOERR(17, "I/O error"),
    NOSPACE(18, "No space"),
    NOTOPEN(19, "File not open"),
    ENDFILE(20, "End of file during browse"),
    ILLOGIC(21, "VSAM logical error"),
    LENGERR(22, "Length error"),
    QZERO(23, "Queue is empty"),
    SIGNAL(24, "Signal received"),
    QBUSY(25, "Queue busy"),
    ITEMERR(26, "Item number error"),
    PGMIDERR(27, "Program not found"),
    TRANSIDERR(28, "Transaction ID error"),
    ENDDATA(29, "End of data"),
    INVTSREQ(30, "Invalid TS request"),
    EXPIRED(31, "Expired"),
    MAPFAIL(36, "Map failure"),
    NOSTG(42, "No storage"),
    JIDERR(43, "Journal ID error"),
    QIDERR(44, "Queue ID error"),
    SYSIDERR(53, "System ID error"),
    NOTAUTH(70, "Not authorized"),
    DISABLED(84, "Resource disabled"),
    ALLOCERR(85, "Allocation error"),
    ROLLEDBACK(100, "Transaction rolled back"),
    CHANNELERR(110, "Channel error"),
    CONTAINERERR(111, "Container error"),
    UNKNOWN(-1, "Unknown response code");
    
    private final int value;
    private final String description;
    
    private static final Map<Integer, CICSResponseCode> BY_VALUE = new HashMap<>();
    private static final Map<String, CICSResponseCode> BY_NAME = new HashMap<>();
    
    static {
        for (CICSResponseCode code : values()) {
            BY_VALUE.put(code.value, code);
            BY_NAME.put(code.name(), code);
        }
    }
    
    CICSResponseCode(int value, String description) {
        this.value = value;
        this.description = description;
    }
    
    public int getValue() { return value; }
    public String getDescription() { return description; }
    
    public static CICSResponseCode fromValue(int value) {
        return BY_VALUE.getOrDefault(value, UNKNOWN);
    }
    
    public static CICSResponseCode fromName(String name) {
        if (name == null || name.trim().isEmpty()) {
            return UNKNOWN;
        }
        String normalized = name.trim().toUpperCase();
        if (normalized.startsWith("DFHRESP(") && normalized.endsWith(")")) {
            normalized = normalized.substring(8, normalized.length() - 1);
        }
        return BY_NAME.getOrDefault(normalized, UNKNOWN);
    }
    
    public static CICSResponseCode parse(String value) {
        if (value == null || value.trim().isEmpty()) {
            return UNKNOWN;
        }
        String trimmed = value.trim();
        try {
            int numericValue = Integer.parseInt(trimmed);
            return fromValue(numericValue);
        } catch (NumberFormatException e) {
            return fromName(trimmed);
        }
    }
    
    public boolean isSuccess() { return this == NORMAL; }
    public boolean isNotFound() { return this == NOTFND || this == ENDFILE || this == QZERO; }
    public boolean isDuplicate() { return this == DUPREC || this == DUPKEY; }
    public boolean isAuthError() { return this == NOTAUTH; }
    
    @Override
    public String toString() {
        return String.format("DFHRESP(%s) [%d: %s]", name(), value, description);
    }
}
